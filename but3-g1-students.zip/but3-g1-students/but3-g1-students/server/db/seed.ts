import { connect } from 'node:http2'
import { genSaltSync, hashSync } from "bcrypt-ts";
import { PrismaClient, Prisma, AlertType, SurveyType } from './generated/client'
import { PrismaPg } from '@prisma/adapter-pg'

const pool = new PrismaPg({ connectionString: process.env.DATABASE_URL! })
const prisma = new PrismaClient({ adapter: pool })

// Fait
const userData: Prisma.UserCreateInput[] = [
  {
    first_name: 'Arthur',
    last_name: 'Fourel',
    username: 'Arthur.fourel', // à changer c'est faux
    personal_email: 'arthur.fourel@gmail.com',
    school_email: 'arthur.fourel@etu.univ-lyon1.fr',
    password: hashSync('password'),
    type: 'Student',
  },
  {
    first_name: 'Willy',
    last_name: 'Alaprod',
    username: 'w',
    personal_email: 'maire2paname@gmail.com',
    school_email: 'willy.alaprod@etu.univ-lyon1.fr',
    gitlab_id: 123456,
    avatar_url: 'https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%2Fid%2FOIP.vkEPdkt5oC7kjIQ5UzDveAHaHa%3Fpid%3DApi&f=1&ipt=f28eb8f5dea5bec00a252f8f78cd49fa230e9e1887302976cc1fb639b6d2f833&ipo=images',
    password: hashSync('password'),
    type: 'Student',
  },
  {
    first_name: 'Feyza',
    last_name: 'Tinasteppe',
    username: 'p2306987',
    personal_email: 'feyza.tinasteppe@gmail.com',
    gitlab_id: 654321,
    school_email: 'feyza.tinasteppe@etu.univ-smb.fr',
    password: hashSync('password'),
    type: 'Student',
  },
  {
    first_name: 'Alice',
    last_name: 'Berger',
    username: 'p2306988',
    personal_email: 'alice@prisma.io',
    school_email: 'alice.berger@etu.univ-lyon1.fr',
    gitlab_id: 111222,
    password: hashSync('password'),
    type: 'Student'
  },
  {
    first_name: 'Rayan',
    last_name: 'Cerfia',
    username: 'rayan.cerfia',
    personal_email: 'rayan@prisma.io',
    school_email: 'rayan.cerfia@etu.univ-lyon1.fr',
    gitlab_id: 333444,
    password: hashSync('password'),
    type: 'Teacher'
  },
  {
    first_name: 'Adrien',
    last_name: 'Peytavie',
    username: 'Adrien.peytavie',
    personal_email: 'adrien.peytavie@gmail.com',
    school_email: 'adrien.peytavie@univ-lyon1.fr',
    gitlab_id: 1547364,
    password: hashSync('password'),
    type: 'Teacher'
  },
  {
    first_name: 'Isabelle',
    last_name: 'Goncalves',
    personal_email: 'isabelle.goncalves@gmail.com',
    school_email: 'isabelle.goncalves@univ-lyon1.fr',
    username: 'isa',
    gitlab_id: 14324354,
    password: hashSync('password'),
    type: 'Teacher'
  },
  {
    first_name: 'Tanguy',
    last_name: 'Abdoulvaid',
    personal_email: 'tanguyabdoulvaid@gmail.com',
    school_email: 'tanguy.abdoulvaid@etu.univ-lyon1.fr',
    username: 'p2513320',
    password: hashSync('password'),
    type: 'Student'
  },
]

// Fait
const studentData: Prisma.StudentCreateInput[] = [
  {
    high_school: 'Lycée général Blaise Pascal',
    diploma: 'Baccalauréat Général | Spécialités : Mathématiques, NSI | Options : Mathématiques Expertes',
    is_representative: true,
    student_code: 'p2302844',
    user: {
      connect: {
        school_email:'arthur.fourel@etu.univ-lyon1.fr'
      }
    },
  },
  {
    high_school: 'Louis le grand',
    diploma: 'Baccalauréat Général, spécialités : Mathématiques, Physique-Chimie, options : Mathématiques Expertes',
    is_representative: true,
    student_code: 'p2302843',
    user: {
      connect: {
        school_email: 'willy.alaprod@etu.univ-lyon1.fr',
      }
    },
  },
   {
    
     student_code: 'p2306987',
     high_school: 'Colbert',
     diploma: 'Baccalauréat Général, spécialités : HGGSP, HLP, NSI',
     is_representative: true,
     user: {
       connect: {
         school_email: 'feyza.tinasteppe@etu.univ-smb.fr'
       }
     },
   },
  {
    student_code: 'p2306988',
    high_school: 'Henri IV',
    diploma: 'Baccalauréat Général, spécialités : Numérique et Sciences Informatiques, Mathématiques, options : Mathématiques Expertes',
    is_representative: false,
    user: {
      connect: {
        school_email: 'alice.berger@etu.univ-lyon1.fr'
      }
    },
  },
  {
    high_school: 'Lycée Colbert',
    diploma: 'Baccalauréat Général | Spécialités : Mathématiques, Physique-Chimie | Options : Mathématiques Expertes',
    is_representative: false,
    student_code: 'p2513320',
    user: {
      connect: {
        school_email:'tanguy.abdoulvaid@etu.univ-lyon1.fr'
      }
    },
  }
]

// Fait
const teacherData: Prisma.TeacherCreateInput[] = [
  {
    phone: '0669696969',
    user: {
      connect: {
        school_email:'rayan.cerfia@etu.univ-lyon1.fr'
      }
    }
  },
  {
    phone: '0669696969',
    user: {
      connect: {
        school_email:'adrien.peytavie@univ-lyon1.fr'
      }
    }
  },
  {
    phone: '0669696969',
    user: {
      connect: {
        school_email:'isabelle.goncalves@univ-lyon1.fr'
      }
    }
  },
]

// Fait
const annotationData: Prisma.AnnotationCreateInput[] = [
  {
    content: 'Maire de la ville de Paris',
    recipient:{
      connect:{
        student_code: 'p2302843'
      }
    },
    author:{
      connect:{
        id: 3
      }
    },
  },
  {
    content: 'la goat',
    recipient: {
      connect: {
        student_code: 'p2306987'
      }
    },
    author: {
      connect: {
        id: 1
      }
    }
  },
  {
    content: 'meow',
    recipient: {
      connect: {
        student_code: 'p2302844'
      }
    },
    author: {
      connect: {
        id: 1
      }
    }
  },
  {
    content: 'meow',
    recipient: {
      connect: {
        student_code: 'p2302844'
      }
    },
    author: {
      connect: {
        id: 1
      }
    }
  }
]

// Fait
const halfGroupData: Prisma.HalfGroupCreateInput [] = [
  {
    name: "INFO3 RA1 A",
    class:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "INFO3 RA1 B",
    class:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "INFO1 G1 A",
    class:{
      connect:{
        id:3
      }
    }
  },
  {
    name: "INFO1 G1 B",
    class:{
      connect:{
        id:3
      }
    }
  },
  {
    name: "INFO2 RA1 A",
    class:{
      connect:{
        id:4
      }
    }
  },
  {
    name: "INFO2 RA1 B",
    class:{
      connect:{
        id:4
      }
    }
  },
]

// Fait
const SemesterData: Prisma.SemesterCreateInput [] = [
  {
    name: "Semestre 1",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:2
      }
    }
  },
  {
    name: "Semestre 2",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:2
      }
    }
  },
  {
    name: "Semestre 3",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:2
      }
    }
  },
  {
    name: "Semestre 4",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:2
      }
    }
  },
  {
    name: "Semestre 5",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "Semestre 6",
    hourly_amount: 200,
    promotion:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "Semestre 1",
    hourly_amount: 298,
    promotion:{
      connect:{
        id:3
      }
    }
  },
  {
    name: "Semestre 2",
    hourly_amount: 297,
    promotion:{
      connect:{
        id:3
      }
    }
  },
  {
    name: "Semestre 3",
    hourly_amount: 289,
    promotion:{
      connect:{
        id:4
      }
    }
  },
  {
    name: "Semestre 4",
    hourly_amount: 181,
    promotion:{
      connect:{
        id:4
      }
    }
  },
  {
    name: "Semestre 5",
    hourly_amount: 208,
    promotion:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "Semestre 6",
    hourly_amount: 60,
    promotion:{
      connect:{
        id:1
      }
    }
  },
]

// Fait
const studentHalfGroupData: Prisma.StudentHalfGroupCreateInput[] = [
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:7
      }
    },
    halfGroup:{
      connect:{
        id:3
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:8
      }
    },
    halfGroup:{
      connect:{
        id:3
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:9
      }
    },
    halfGroup:{
      connect:{
        id:5
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:10
      }
    },
    halfGroup:{
      connect:{
        id:5
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:11
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:12
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        id:1
      }
    },
    semester:{
      connect:{
        id:5
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        id:2
      }
    },
    semester:{
      connect:{
        id:5
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        id:2
      }
    },
    semester:{
      connect:{
        id:6
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  
  {
    student:{
      connect:{
        id:3
      }
    },
    semester:{
      connect:{
        id:5
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        id:3
      }
    },
    semester:{
      connect:{
        id:6
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        student_code:"p2513320"
      }
    },
    semester:{
      connect:{
        id:5
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
  {
    student:{
      connect:{
        student_code:"p2513320"
      }
    },
    semester:{
      connect:{
        id:6
      }
    },
    halfGroup:{
      connect:{
        id:1
      }
    }
  },
]

// Fait
const classData: Prisma.ClassCreateInput [] = [
  {
    name: "INFO3 RA1",
    specialization: {
      connect: {
        code: "RA"
      }
    },
    promotion: {
      connect: {
        id:1
      }
    }
  },
  {
    name: "INFO1 G1",
    promotion: {
      connect: {
        id:2
      }
    }
  },
  {
    name: "INFO1 G1",
    promotion: {
      connect: {
        id:3
      }
    }
  },
  {
    name: "INFO2 RA1",
    specialization: {
      connect: {
        code: "RA"
      }
    },
    promotion: {
      connect: {
        id:4
      }
    }
  },
]

// Fait
const specializationData: Prisma.SpecializationCreateInput[] = [
  {
    name: "Réalisation d'applications",
    code: "RA",
    department:{
      connect:{
        code:"INFO"
      }
    }
  },
  {
    name: "Administration, gestion et exploitation des données ",
    code: "AGED",
    department:{
      connect:{
        code:"INFO"
      }
    }
  },
  {
    name: "Intégration d'applications et management du système d'information ",
    code: "IAMSI",
    department:{
      connect:{
        code:"INFO"
      }
    }
  },
  {
    name: "Déploiement d'applications communicantes et sécurisées ",
    code: "DACS",
    department:{
      connect:{
        code:"INFO"
      }
    }
  },
]

// Fait
const demartmentData: Prisma.DepartmentCreateInput[] = [
  {
    name: "Informatique",
    code: "INFO",
    address: "1 rue de la Technologie 69622 Villeurbanne Cedex"
  },
]

// Fait
const promotionData: Prisma.PromotionCreateInput[] = [
  {
    name: "INFO3 RA 2025-2026",
    diploma: "BUT Informatique",
    start_date: new Date('2025-09-01'),
    end_date: new Date('2026-08-31'),
    department:{
      connect:{
        code: "INFO"
      }
    }
  },
  {
    name: "INFO1 2025-2026",
    diploma: "BUT Informatique",
    start_date: new Date('2025-09-01'),
    end_date: new Date('2026-08-31'),
    department:{
      connect:{
        code: "INFO"
      }
    }
  },
  {
    name: "INFO1 2023-2024",
    diploma: "BUT Informatique",
    start_date: new Date('2023-09-01'),
    end_date: new Date('2024-08-31'),
    department:{
      connect:{
        code: "INFO"
      }
    }
  },
  {
    name: "INFO2 RA 2024-2025",
    diploma: "BUT Informatique",
    start_date: new Date('2024-09-01'),
    end_date: new Date('2025-08-31'),
    department:{
      connect:{
        code: "INFO"
      }
    }
  },
]

// Fait
const competencyData: Prisma.CompetencyCreateInput[] = [
  {
    name: "Réaliser",
    code: "C1",
    description: "Développer — c’est-à-dire concevoir, coder, tester et intégrer — une solution informatique pour un client.",
    specializations:{
      connect:{
        code:"RA"
      }
    }
  },
  {
    name: "Optimiser",
    code: "C2",
    description: "Proposer des applications informatiques optimisées en fonction de critères spécifiques : temps d’exécution, précision, consommation de ressources.",
    specializations:{
      connect:{
        code:"RA"
      }
    }
  },
  {
    name: "Administrer",
    code: "C3",
    description: "Installer, configurer, mettre à disposition, maintenir en conditions opérationnelles des infrastructures, des services et des réseaux et optimiser le système informatique d’une organisation"
  },
  {
    name: "Gérer",
    code: "C4",
    description: "Concevoir, gérer, administrer et exploiter les données de l’entreprise et mettre à disposition toutes les informations pour un bon pilotage de l’entreprise"
  },
  {
    name: "Conduire",
    code: "C5",
    description: "Satisfaire les besoins des utilisateurs au regard de la chaîne de valeur du client, organiser et piloter un projet informatique avec des méthodes classiques ou agiles"
  },
  {
    name: "Collaborer",
    code: "C6",
    description: "Acquérir, développer et exploiter les aptitudes nécessaires pour travailler efficacement dans une équipe informatique",
    specializations:{
      connect:{
        code:"RA"
      }
    }
  },
]

// const specializationCompetencyData: Prisma.SpecializationCompetencyCreateInput[] = [
//   {
//     specialization:{
//       connect:{
//         code: "RA"
//       }
//     },
//     competency: {
//       connect: {
//         id: 1
//       }
//     }
//   },
//   {
//     specialization:{
//       connect:{
//         code: "RA"
//       }
//     },
//     competency: {
//       connect: {
//         id: 2
//       }
//     }
//   },
// ]

// Fait
const classCompetencyData: Prisma.ClassCompetencyCreateInput[] = [
  // INFO1 S1
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:7}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:7}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 3}},
    semester:{connect:{id:7}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 4}},
    semester:{connect:{id:7}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 5}},
    semester:{connect:{id:7}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:7}}
  },
  // INFO1 S2
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:8}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:8}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 3}},
    semester:{connect:{id:8}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 4}},
    semester:{connect:{id:8}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 5}},
    semester:{connect:{id:8}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:8}}
  },
  // INFO2 S3
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:9}}
  },
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:9}}
  },
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 3}},
    semester:{connect:{id:9}}
  },
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 4}},
    semester:{connect:{id:9}}
  },
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 5}},
    semester:{connect:{id:9}}
  },
  {
    class:{connect:{id:4}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:9}}
  },
  // INFO2 S4
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:10}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:10}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 3}},
    semester:{connect:{id:10}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 4}},
    semester:{connect:{id:10}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 5}},
    semester:{connect:{id:10}}
  },
  {
    class:{connect:{id:3}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:10}}
  },
  // INFO3 S5
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:11}}
  },
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:11}}
  },
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:11}}
  },
  // INFO3 S6
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 1}},
    semester:{connect:{id:12}}
  },
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 2}},
    semester:{connect:{id:12}}
  },
  {
    class:{connect:{id:1}},
    competency:{connect:{id: 6}},
    semester:{connect:{id:12}}
  },
]

// Fait
const companyData: Prisma.CompanyCreateInput[] = [
  {
    name: "Lidl",
    siret: "553 279 879 00672" ,
    business_sector: "supermarket",
    email: "contact@lidl.de",
    phone: "04 69 69 69 69" ,
    adress: "22 rue Joseph Chapelle Lyon 69008 CEDEX" 
  },
  {
    name: "Domaine viticole Martin",
    siret: "327 360 772 00013" ,
    business_sector: "Culture de la vigne",
    email: "martin@domaine-martin.com",
    phone: "04 90 37 23 20" ,
    adress: "439 Rte de Vaison, 84850 Travaillan" 
  },
  {
    name: "Vulcania",
    siret: "423 556 356 00024" ,
    business_sector: "Gestion des sites et monuments historiques et des attractions touristiques similaires",
    email: "bienvenue@vulcania.com",
    phone: "04 73 19 70 00" ,
    adress: "2 route de Mazayes, 63230 Saint Ours Les Roches" 
  },
  {
    name: "Picard Surgelés",
    siret: "784 939 688 10915" ,
    business_sector: "Commerce de détail de produits surgelés",
    email: "publication@picard.fr",
    phone: "09 70 82 11 00" ,
    adress: "12 boulevard Garibaldi – 92130 Issy les Moulineaux" 
  },
  {
    name: "Hexatio",
    siret: "819 173 022 00016" ,
    business_sector: "Édition de logiciels applicatifs",
    email: "contact@hexatio.fr",
    phone: "09 70 46 60 00" ,
    adress: "15, place Jules Ferry, 69006 Lyon" 
  },
  {
    name: "Région Auvergne-Rhône-Alpes",
    siret: "200 053 767 00014" ,
    business_sector: "Administration publique générale",
    email: "contact@auvergnerhonealpes.fr",
    phone: "04 26 73 40 00" ,
    adress: "101 cours Charlemagne - CS 20033, 69269 LYON CEDEX 02, France" 
  },
]

// Fait
const workExperienceData: Prisma.WorkExperienceCreateInput[] = [
  {
    type: "Stage",
    professional_tutor: "Kirkor Albert",
    position: "Manager rayon bazar",
    mission: "adapter logiciel interne",
    start_date: new Date('2025-04-14'),
    end_date: new Date('2025-06-30'),
    company:{
      connect:{
        id: 1
      }
    },
    student:{
      connect:{
        id: 1
      }
    },
    academic_tutor:{
      connect:{
        id: 1
      }
    } 
  },
  {
    type: "Stage",
    professional_tutor: "Bernard LACOSTE",
    position: "Développeur",
    mission: "Développement en PHP/Symfony au sein de l'équipe de développement du service T.M.R. de la D.S.I.",
    start_date: new Date('2025-04-22'),
    end_date: new Date('2025-06-28'),
    company:{connect:{id: 6}},
    student:{connect:{id: 1}},
    academic_tutor:{connect:{id: 2}} 
  },
  {
    type: "Alternance",
    professional_tutor: "François RIVET",
    position: "Analyste/développeur",
    mission: "Développement en WLangage au sein de l'équipe de développement.",
    start_date: new Date('2025-09-01'),
    end_date: new Date('2026-08-31'),
    company:{connect:{id: 5}},
    student:{connect:{id: 1}},
    academic_tutor:{connect:{id: 3}} 
  },
  {
    type: "Alternance",
    professional_tutor: "François RIVET",
    position: "Analyste/développeur",
    mission: "Développement en WLangage au sein de l'équipe de développement.",
    start_date: new Date('2025-09-01'),
    end_date: new Date('2026-08-31'),
    company:{connect:{id: 5}},
    student:{connect:{id: 1}},
    academic_tutor:{connect:{id: 3}} 
  },
]

// Fait
const moduleTypeData: Prisma.ModuleTypeCreateInput[] = [
  {
    name:"Situation d'apprentissage et d'évaluation",
    diminutive: "S."
  },
  {
    name:"Portfolio",
  },
  {
    name:"Ressource",
    diminutive: "R."
  },
]

// Fait
const moduleData: Prisma.ModuleCreateInput[] = [
  // INFO1 S1
  {
    name:"Implémentation d'un besoin client",
    code: "S1.01",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Comparaison d'approches algorithmiques",
    code: "S1.02",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Installation d'un poste pour le développement",
    code: "S1.03",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Création d'une base de données",
    code: "S1.04",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Recueil des besoins",
    code: "S1.05",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Découverte de l'environnement économique et écologique",
    code: "S1.06",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Algorithmique",
    code: "R1.01-1",
    moduleType:{connect:{id:3}}
  },
  {
    name:"C et GIT (4h)",
    code: "R1.01-2",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Développement d'interfaces web",
    code: "R1.02",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Introduction à l'architecture des ordinateurs",
    code: "R1.03",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Introduction aux systèmes d'exploitation et à leur fonctionnement",
    code: "R1.04",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Conception BD",
    code: "R1.05-1",
    moduleType:{connect:{id:3}}
  },
  {
    name:"SQL",
    code: "R1.05-2",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Mathématiques discrètes",
    code: "R1.06",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Outils mathématiques fondamentaux",
    code: "R1.07",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Gestion des organisations",
    code: "R1.08",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Économie durable et numérique",
    code: "R1.09",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Anglais technique",
    code: "R1.10",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Bases de la communication",
    code: "R1.11",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Projet Professionnel et Personnel",
    code: "R1.12",
    moduleType:{connect:{id:3}}
  },

  // INFO3 S5 (id > 20)
  {
    name:"Développement avancé",
    code: "S5.A.01",
    moduleType:{connect:{id:1}}
  },
  {
    name:"Initiation au management",
    code: "R5.01",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Communication",
    code: "R5.03",
    moduleType:{connect:{id:3}}
  },
  {
    name:"PPP",
    code: "R5.A.02",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Qualité algorithmique",
    code: "R5.A.04",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Spring Boot",
    code: "R5.A.05.01",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Angular",
    code: "R5.A.05.02",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Programmation multimédia",
    code: "R5.A.06",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Automatisation",
    code: "R5.A.07",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Qualité de développement",
    code: "R5.A.08",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Virtualisation avancée",
    code: "R5.A.09",
    moduleType:{connect:{id:3}}
  },
  {
    name:"MongoDB",
    code: "R5.A.10.01",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Noe4J",
    code: "R5.A.10.02",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Aide à la décision",
    code: "R5.A.11",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Modélisations math.",
    code: "R5.A.12",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Éco. durable et num.",
    code: "R5.A.13",
    moduleType:{connect:{id:3}}
  },
  {
    name:"Anglais",
    code: "R5.A.14",
    moduleType:{connect:{id:3}}
  },
]

// Fait
const absenceData: Prisma.AbsenceCreateInput[] = [
  // INFO1 S1
  {
    date: new Date('2023-10-03T08:00Z'),
    is_justified: true,
    reason: "Grève SNCF",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:7}}
  },
  {
    date: new Date('2023-11-16T08:00Z'),
    is_justified: true,
    reason: "Perturbations TCL",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:7}}
  },
  {
    date: new Date('2023-10-19T08:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:7}}
  },
  {
    date: new Date('2023-12-01T08:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:7}}
  },
  // INFO1 S2
  {
    date: new Date('2024-04-12T08:00Z'),
    is_justified: true,
    reason: "Grève SNCF",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-06T08:00Z'),
    is_justified: true,
    reason: "Maladie",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-06T10:00Z'),
    is_justified: true,
    reason: "Maladie",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-06T14:00Z'),
    is_justified: true,
    reason: "Maladie",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-06T16:00Z'),
    is_justified: true,
    reason: "Maladie",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-22T08:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-05-22T10:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-06-04T08:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
  {
    date: new Date('2024-06-19T14:00Z'),
    is_justified: false,
    reason: "Injustifiée",
    student:{connect:{id:1}},
    module:{connect:{id:1}},
    semester:{connect:{id:8}}
  },
]

// Fait
const teachingUnitData: Prisma.TeachingUnitCreateInput[] = [
  {
    name: "Unité d'enseignement 11",
    code: "UE11",
    competency:{connect:{id:1}}
  },
  {
    name: "Unité d'enseignement 12",
    code: "UE12",
    competency:{connect:{id:2}}
  },
  {
    name: "Unité d'enseignement 13",
    code: "UE13",
    competency:{connect:{id:3}}
  },

  {
    name: "Unité d'enseignement 14",
    code: "UE14",
    competency:{connect:{id:4}}
  },

  {
    name: "Unité d'enseignement 15",
    code: "UE15",
    competency:{connect:{id:5}}
  },

  {
    name: "Unité d'enseignement 16",
    code: "UE16",
    competency:{connect:{id:6}}
  },

  {
    name: "Unité d'enseignement 21",
    code: "UE21",
    competency:{connect:{id:1}}
  },

  {
    name: "Unité d'enseignement 22",
    code: "UE22",
    competency:{connect:{id:2}}
  },

  {
    name: "Unité d'enseignement 23",
    code: "UE23",
    competency:{connect:{id:3}}
  },

  {
    name: "Unité d'enseignement 24",
    code: "UE24",
    competency:{connect:{id:4}}
  },

  {
    name: "Unité d'enseignement 25",
    code: "UE25",
    competency:{connect:{id:5}}
  },

  {
    name: "Unité d'enseignement 26",
    code: "UE26",
    competency:{connect:{id:6}}
  },

  {
    name: "Unité d'enseignement 31",
    code: "UE31",
    competency:{connect:{id:1}}
  },

  {
    name: "Unité d'enseignement 32",
    code: "UE32",
    competency:{connect:{id:2}}
  },

  {
    name: "Unité d'enseignement 33",
    code: "UE33",
    competency:{connect:{id:3}}
  },

  {
    name: "Unité d'enseignement 34",
    code: "UE34",
    competency:{connect:{id:4}}
  },

  {
    name: "Unité d'enseignement 35",
    code: "UE35",
    competency:{connect:{id:5}}
  },

  {
    name: "Unité d'enseignement 36",
    code: "UE36",
    competency:{connect:{id:6}}
  },

  {
    name: "Unité d'enseignement 41",
    code: "UE41",
    competency:{connect:{id:1}}
  },

  {
    name: "Unité d'enseignement 42",
    code: "UE42",
    competency:{connect:{id:2}}
  },

  {
    name: "Unité d'enseignement 43",
    code: "UE43",
    competency:{connect:{id:3}}
  },

  {
    name: "Unité d'enseignement 44",
    code: "UE44",
    competency:{connect:{id:4}}
  },

  {
    name: "Unité d'enseignement 45",
    code: "UE45",
    competency:{connect:{id:5}}
  },

  {
    name: "Unité d'enseignement 46",
    code: "UE46",
    competency:{connect:{id:6}}
  },

  {
    name: "Unité d'enseignement 51",
    code: "UE51",
    competency:{connect:{id:1}}
  },

  {
    name: "Unité d'enseignement 52",
    code: "UE52",
    competency:{connect:{id:2}}
  },

  {
    name: "Unité d'enseignement 56",
    code: "UE56",
    competency:{connect:{id:6}}
  },

  {
    name: "Unité d'enseignement 61",
    code: "UE61",
    competency:{connect:{id:1}}
  },

  {
    name: "Unité d'enseignement 62",
    code: "UE62",
    competency:{connect:{id:2}}
  },

  {
    name: "Unité d'enseignement 66",
    code: "UE66",
    competency:{connect:{id:6}}
  },
]

// Fait
const averageMarkData: Prisma.AverageMarkCreateInput[] = [
  // INFO1 S1
  {
    value: 12,
    module:{connect:{id:1}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 12,
    module:{connect:{id:2}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.9,
    module:{connect:{id:3}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.75,
    module:{connect:{id:4}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 11.481,
    module:{connect:{id:5}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 9.375,
    module:{connect:{id:6}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.43,
    module:{connect:{id:7}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 12.25,
    module:{connect:{id:8}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.75,
    module:{connect:{id:9}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.25,
    module:{connect:{id:10}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 7.5,
    module:{connect:{id:11}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 16.9,
    module:{connect:{id:12}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.5,
    module:{connect:{id:13}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 15.8,
    module:{connect:{id:14}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.6,
    module:{connect:{id:15}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.75,
    module:{connect:{id:16}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 11.375,
    module:{connect:{id:17}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.09,
    module:{connect:{id:18}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.766,
    module:{connect:{id:19}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 18.25,
    module:{connect:{id:20}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },

  // INFO3 S5
  {
    value: 14,
    module:{connect:{id:21}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 19,
    module:{connect:{id:22}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 16.25,
    module:{connect:{id:23}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 14.375,
    module:{connect:{id:24}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 12,
    module:{connect:{id:25}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 16.88,
    module:{connect:{id:26}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 10.85,
    module:{connect:{id:27}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.46,
    module:{connect:{id:28}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 9.75,
    module:{connect:{id:29}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 17.25,
    module:{connect:{id:30}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 13.8,
    module:{connect:{id:31}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 11.27,
    module:{connect:{id:32}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 15.125,
    module:{connect:{id:33}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 8.5,
    module:{connect:{id:34}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 10.8,
    module:{connect:{id:35}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 15,
    module:{connect:{id:36}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
  {
    value: 17,
    module:{connect:{id:37}},
    student:{connect:{id:1}},
    teacher:{connect:{id:1}},
  },
]

// Fait
const averageMarkTeachingUnitData: Prisma.AverageMarkTeachingUnitCreateInput[] = [
  // INFO1 S1
  {
    coefficient: 40,
    averageMark:{connect:{id:1}},
    teachingUnit:{connect:{id:1}}
  },
  {
    coefficient: 40,
    averageMark:{connect:{id:2}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 40,
    averageMark:{connect:{id:3}},
    teachingUnit:{connect:{id:3}}
  },
  {
    coefficient: 40,
    averageMark:{connect:{id:4}},
    teachingUnit:{connect:{id:4}}
  },
  {
    coefficient: 40,
    averageMark:{connect:{id:5}},
    teachingUnit:{connect:{id:5}}
  },
  {
    coefficient: 40,
    averageMark:{connect:{id:6}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 18,
    averageMark:{connect:{id:7}},
    teachingUnit:{connect:{id:1}}
  },
  {
    coefficient: 10,
    averageMark:{connect:{id:7}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 24,
    averageMark:{connect:{id:8}},
    teachingUnit:{connect:{id:1}}
  },
  {
    coefficient: 14,
    averageMark:{connect:{id:8}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 12,
    averageMark:{connect:{id:9}},
    teachingUnit:{connect:{id:1}}
  },
  {
    coefficient: 18,
    averageMark:{connect:{id:9}},
    teachingUnit:{connect:{id:5}}
  },
  {
    coefficient: 5,
    averageMark:{connect:{id:9}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 3,
    averageMark:{connect:{id:10}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 21,
    averageMark:{connect:{id:10}},
    teachingUnit:{connect:{id:3}}
  },
  {
    coefficient: 3,
    averageMark:{connect:{id:11}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 21,
    averageMark:{connect:{id:11}},
    teachingUnit:{connect:{id:3}}
  },
  {
    coefficient: 14,
    averageMark:{connect:{id:12}},
    teachingUnit:{connect:{id:4}}
  },
  {
    coefficient: 22,
    averageMark:{connect:{id:13}},
    teachingUnit:{connect:{id:4}}
  },
  {
    coefficient: 15,
    averageMark:{connect:{id:14}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 18,
    averageMark:{connect:{id:14}},
    teachingUnit:{connect:{id:4}}
  },
  {
    coefficient: 15,
    averageMark:{connect:{id:15}},
    teachingUnit:{connect:{id:2}}
  },
  {
    coefficient: 27,
    averageMark:{connect:{id:16}},
    teachingUnit:{connect:{id:5}}
  },
  {
    coefficient: 11,
    averageMark:{connect:{id:16}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:17}},
    teachingUnit:{connect:{id:5}}
  },
  {
    coefficient: 11,
    averageMark:{connect:{id:17}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:18}},
    teachingUnit:{connect:{id:1}}
  },
  {
    coefficient: 12,
    averageMark:{connect:{id:18}},
    teachingUnit:{connect:{id:3}}
  },
  {
    coefficient: 11,
    averageMark:{connect:{id:18}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:19}},
    teachingUnit:{connect:{id:3}}
  },
  {
    coefficient: 15,
    averageMark:{connect:{id:19}},
    teachingUnit:{connect:{id:5}}
  },
  {
    coefficient: 11,
    averageMark:{connect:{id:19}},
    teachingUnit:{connect:{id:6}}
  },
  {
    coefficient: 11,
    averageMark:{connect:{id:20}},
    teachingUnit:{connect:{id:6}}
  },

  //INFO3 S5
  {
    coefficient: 50,
    averageMark:{connect:{id:21}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 50,
    averageMark:{connect:{id:21}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 50,
    averageMark:{connect:{id:21}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 9,
    averageMark:{connect:{id:22}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 13,
    averageMark:{connect:{id:23}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:24}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:25}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:25}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 4,
    averageMark:{connect:{id:26}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 4,
    averageMark:{connect:{id:26}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 5,
    averageMark:{connect:{id:27}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 3,
    averageMark:{connect:{id:27}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:28}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:28}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:28}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:29}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:29}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 7,
    averageMark:{connect:{id:30}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 5,
    averageMark:{connect:{id:30}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 7,
    averageMark:{connect:{id:31}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:31}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:32}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:32}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 6,
    averageMark:{connect:{id:33}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:33}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 7,
    averageMark:{connect:{id:34}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 13,
    averageMark:{connect:{id:35}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 2,
    averageMark:{connect:{id:36}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 5,
    averageMark:{connect:{id:36}},
    teachingUnit:{connect:{id:27}}
  },
  {
    coefficient: 3,
    averageMark:{connect:{id:37}},
    teachingUnit:{connect:{id:25}}
  },
  {
    coefficient: 4,
    averageMark:{connect:{id:37}},
    teachingUnit:{connect:{id:26}}
  },
  {
    coefficient: 13,
    averageMark:{connect:{id:37}},
    teachingUnit:{connect:{id:27}}
  },
]

// Fait
const teacherClassModuleData: Prisma.TeacherClassModuleCreateInput[] = [
  {
    teacher:{
      connect:{
        id:1
      }
    },
    class:{
      connect:{
        id:1
      }
    },
    module:{
      connect:{
        id:1
      }
    }
  },
]

const roleData: Prisma.RoleCreateInput[] = [
  {
    name: "Responsable Pédagogique",
    users:{
      connect:{
        id:4
      }
    }
  },
  {
    name: "Secrétaire Pédagogique"
  },
]

const permissionData: Prisma.PermissionCreateInput[] = [
  {
    name: "Gestion campagnes",
    roles:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "Import données",
    roles:{
      connect:{
        id:2
      }
    },
    users:{
      connect:{
        id:4
      }
    }
  },
]

// const rolePermissionData: Prisma.RolePermissionCreateInput[] = [
//   {
//     role:{
//       connect:{
//         id: 1
//       }
//     },
//     permission:{
//       connect:{
//         id: 1
//       }
//     }
//   },
//   {
//     role:{
//       connect:{
//         id: 2
//       }
//     },
//     permission:{
//       connect:{
//         id: 2
//       }
//     }
//   },
// ]

// const userRoleData: Prisma.UserRoleCreateInput[] = [
//   {
//     user:{
//       connect:{
//         id: 3
//       }
//     },
//     role:{
//       connect:{
//         id: 1
//       }
//     }
//   },
// ]

// const userPermissionData: Prisma.UserPermissionCreateInput[] = [
//   {
//     user:{
//       connect:{
//         id: 3
//       }
//     },
//     permission:{
//       connect:{
//         id: 2
//       }
//     }
//   },
// ]

const alertData: Prisma.AlertCreateInput[] = [
  {
    message: "Concert de l2b à Chatelet",
    url: "https://l2b-concerts.fr",
    type: AlertType.Info,
    student:{
      connect:{
        id:1
      }
    }
  },
  {
    message: "Lock in !! 8 de moyenne t'abuses",
    url: "",
    type: AlertType.Warning,
    student:{
      connect:{
        id:1
      }
    }
  },
  {
    message: "Compétence C3 non validée, rendez-vous avec le responsable pédagogique obligatoire",
    url: "",
    type: AlertType.Critical,
    student:{
      connect:{
        id:1
      }
    },
  },
  {
    message: "Absence injustifiée",
    url: "",
    type: AlertType.Warning,
    student:{
      connect:{
        id:2
      }
    },
  }
]

const surveyData: Prisma.SurveyCreateInput[] = [
  {
    name: "Choix parcours",
    type: "Mandatory",
    limit_date: new Date("2026-06-30"),
    students:{
      connect: [{
        id:1
      },
      {
        id:2
      }]
    }
  },
  {
    name: "S4 à l'étranger",
    type: "Mandatory",
    limit_date: new Date("2026-06-30"),
    students:{
      connect:{
        id:1
      }
    }
  },
  {
    name: "Questionnaire confort salles de classe",
    type: SurveyType.Optional,
    limit_date: new Date("2026-06-30"),
    students:{
      connect:[{
        id:1
      },
      {
        id:2
      }]
    }
  },
]
// refactor many2many

// const surveyStudentData: Prisma.SurveyStudentCreateInput[] = [
//   {
//     survey:{
//       connect:{
//         id:1
//       }
//     },
//     student:{
//       connect:{
//         id:1
//       }
//     },
    
//   },
// ]

const questionData: Prisma.QuestionCreateInput[] = [
  {
    label: "Quel parcours choisissez vous ?",
    type: "SingleChoice",
    survey:{
      connect:{
        id:1
      }
    }
  },
  {
    label: "Quel Dans quelles salles avez vous étudié ?",
    type: "MultiChoices",
    survey:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "A combien estimez vous votre confort dans les salles ?",
    type: "SingleChoice",
    survey:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "Avez vous des suggestions ?",
    type: "Free",
    survey:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "Souhaitez vous effectuer votre S4 à l'étranger ?",
    type: "SingleChoice",
    survey:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "Si oui, quels pays envisagez vous ?",
    type: "MultiChoices",
    survey:{
      connect:{
        id:2
      }
    }
  },
]

const optionData: Prisma.OptionCreateInput[] = [
  {
    label: "Parcours RA",
    question:{
      connect:{
        id:1
      }
    }
  },
  {
    label: "Parcours AGED",
    question:{
      connect:{
        id:1
      }
    }
  },
  {
    label: "Parcours DACS",
    question:{
      connect:{
        id:1
      }
    }
  },
  {
    label: "S1",
    question:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "S2",
    question:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "S3",
    question:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "S4",
    question:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "S5",
    question:{
      connect:{
        id:2
      }
    }
  },
  {
    label: "1",
    question:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "2",
    question:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "3",
    question:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "4",
    question:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "5",
    question:{
      connect:{
        id:3
      }
    }
  },
  {
    label: "Oui",
    question:{
      connect:{
        id:5
      }
    }
  },
  {
    label: "Non",
    question:{
      connect:{
        id:5
      }
    }
  },
  {
    label: "Royaume-Uni",
    question:{
      connect:{
        id:6
      }
    }
  },
  {
    label: "Irlande",
    question:{
      connect:{
        id:6
      }
    }
  },
  {
    label: "Pays-Bas",
    question:{
      connect:{
        id:6
      }
    }
  },
  {
    label: "Etats-Unis",
    question:{
      connect:{
        id:6
      }
    }
  },
  {
    label: "Singapour",
    question:{
      connect:{
        id:6
      }
    }
  },
  {
    label: "Taiwan",
    question:{
      connect:{
        id:6
      }
    }
  },
]

const responseData: Prisma.ResponseCreateInput[] = [
  {
    option:{
      connect:{
        id:1
      }
    },
    question:{
      connect:{
        id:1
      }
    },
    student:{
      connect:{
        id:1
      }
    }
  },
]

async function main() {
  console.log(`Start seeding ...`)

  console.log(`-----------------------------------------------------`)

  console.log(`Users : `)
  for (const u of userData) {
    const user = await prisma.user.create({
      data: u,
    })
    console.log(`Created user with id: ${user.id}`)
  }

  console.log(`-----------------------------------------------------`)

  console.log(`ModuleTypes : `)
  for (const mt of moduleTypeData) {
    const moduleType = await prisma.moduleType.create({
      data: mt,
    })
    console.log(`Created moduleType with id: ${moduleType.id}`)
  }

  console.log(`-----------------------------------------------------`)

  console.log(`Modules : `)
  for (const m of moduleData) {
    const module = await prisma.module.create({
      data: m,
    })
    console.log(`Created module with id: ${module.id}`)
  }

  console.log(`-----------------------------------------------------`)

  console.log(`Companies : `)
  for (const c of companyData) {
    const company = await prisma.company.create({
      data: c,
    })
    console.log(`Created company with id: ${company.id}`)
  }

    console.log(`-----------------------------------------------------`)
  
  console.log(`Department : `)
  for (const d of demartmentData) {
    const department = await prisma.department.create({
      data: d,
    })
    console.log(`Created department with id: ${department.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Specializations : `)
  for (const s of specializationData) {
    const specialization = await prisma.specialization.create({
      data: s,
    })
    console.log(`Created specialization with id: ${specialization.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Competencies : `)
  for (const c of competencyData) {
    const competency = await prisma.competency.create({
      data: c,
    })
    console.log(`Created competency with id: ${competency.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`TeachingUnits : `)
  for (const tu of teachingUnitData) {
    const teachingUnit = await prisma.teachingUnit.create({
      data: tu,
    })
    console.log(`Created teachingUnit with id: ${teachingUnit.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Students : `)
  for (const s of studentData) {
    const student = await prisma.student.create({
      data: s,
    })
    console.log(`Created student with id: ${student.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Surveys : `)
  for (const s of surveyData) {
    const survey = await prisma.survey.create({
      data: s,
    })
    console.log(`Created survey with id: ${survey.id}`)
  }

  // refactor many2many

  // console.log(`-----------------------------------------------------`)
  
  // console.log(`SurveyStudents : `)
  // for (const ss of surveyStudentData) {
  //   const surveyStudent = await prisma.surveyStudent.create({
  //     data: ss,
  //   })
  //   console.log(`Created surveyStudent with id: ${surveyStudent.id}`)
  // }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Questions : `)
  for (const q of questionData) {
    const question = await prisma.question.create({
      data: q,
    })
    console.log(`Created question with id: ${question.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Options : `)
  for (const o of optionData) {
    const option = await prisma.option.create({
      data: o,
    })
    console.log(`Created option with id: ${option.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Response : `)
  for (const r of responseData) {
    const response = await prisma.response.create({
      data: r,
    })
    console.log(`Created response with id: ${response.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Alerts : `)
  for (const a of alertData) {
    const alert = await prisma.alert.create({
      data: a,
    })
    console.log(`Created alert with id: ${alert.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Teachers : `)
  for (const t of teacherData) {
    const teacher = await prisma.teacher.create({
      data: t,
    })
    console.log(`Created teacher with id: ${teacher.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Annotations : `)
  for (const a of annotationData) {
    const annotation = await prisma.annotation.create({
      data: a,
    })
    console.log(`Created annotation with id: ${annotation.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`WorkExperiences : `)
  for (const we of workExperienceData) {
    const workExperience = await prisma.workExperience.create({
      data: we,
    })
    console.log(`Created WorkExperience with id: ${workExperience.id}`)
  }



  // console.log(`-----------------------------------------------------`)
  
  // console.log(`SpecializationCompetencies : `)
  // for (const s of specializationCompetencyData) {
  //   const specializationCompetency = await prisma.specializationCompetency.create({
  //     data: s,
  //   })
  //   console.log(`Created specializationCompetency with id: ${specializationCompetency.id}`)
  // }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Promotions : `)
  for (const p of promotionData) {
    const promotion = await prisma.promotion.create({
      data: p,
    })
    console.log(`Created promotion with id: ${promotion.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Classes : `)
  for (const c of classData) {
    const classe = await prisma.class.create({
      data: c,
    })
    console.log(`Created class with id: ${classe.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`HalfGroups : `)
  for (const h of halfGroupData) {
    const halfGroup = await prisma.halfGroup.create({
      data: h,
    })
    console.log(`Created halfGroup with id: ${halfGroup.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Semesters : `)
  for (const s of SemesterData) {
    const semester = await prisma.semester.create({
      data: s,
    })
    console.log(`Created semester with id: ${semester.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`classCompetencies : `)
  for (const cc of classCompetencyData) {
    const classCompetency = await prisma.classCompetency.create({
      data: cc,
    })
    console.log(`Created classCompetency with id: ${classCompetency.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`studentHalfGroups : `)
  for (const s of studentHalfGroupData) {
    const studentHalfGroup = await prisma.studentHalfGroup.create({
      data: s,
    })
    console.log(`Created studentHalfGroup with id: ${studentHalfGroup.id}`)
  }

  console.log(`-----------------------------------------------------`)

  console.log(`AverageMarks : `)
  for (const am of averageMarkData) {
    const averageMark = await prisma.averageMark.create({
      data: am,
    })
    console.log(`Created averageMark with id: ${averageMark.id}`)
  }

  console.log(`-----------------------------------------------------`)

  console.log(`AverageMarkTeachingUnits : `)
  for (const amtu of averageMarkTeachingUnitData) {
    const averageMarkTeachingUnit = await prisma.averageMarkTeachingUnit.create({
      data: amtu,
    })
    console.log(`Created averageMarkTeachingUnit with id: ${averageMarkTeachingUnit.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Absences : `)
  for (const a of absenceData) {
    const absence = await prisma.absence.create({
      data: a,
    })
    console.log(`Created absence with id: ${absence.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`TeacherClassModules : `)
  for (const tcm of teacherClassModuleData) {
    const teacherClassModule = await prisma.teacherClassModule.create({
      data: tcm,
    })
    console.log(`Created teacherClassModule with id: ${teacherClassModule.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Roles : `)
  for (const r of roleData) {
    const role = await prisma.role.create({
      data: r,
    })
    console.log(`Created role with id: ${role.id}`)
  }

  console.log(`-----------------------------------------------------`)
  
  console.log(`Permissions : `)
  for (const p of permissionData) {
    const permission = await prisma.permission.create({
      data: p,
    })
    console.log(`Created permission with id: ${permission.id}`)
  }

  // console.log(`-----------------------------------------------------`)
  
  // console.log(`RolePermissions : `)
  // for (const rp of rolePermissionData) {
  //   const rolePermission = await prisma.rolePermission.create({
  //     data: rp,
  //   })
  //   console.log(`Created rolePermission with id: ${rolePermission.id}`)
  // }

  // console.log(`-----------------------------------------------------`)
  
  // console.log(`UserRoles : `)
  // for (const ur of userRoleData) {
  //   const userRole = await prisma.userRole.create({
  //     data: ur,
  //   })
  //   console.log(`Created userRole with id: ${userRole.id}`)
  // }

  // console.log(`-----------------------------------------------------`)
  
  // console.log(`UserPermissions : `)
  // for (const up of userPermissionData) {
  //   const userPermission = await prisma.userPermission.create({
  //     data: up,
  //   })
  //   console.log(`Created userPermission with id: ${userPermission.id}`)
  // }

  console.log(`Seeding finished.`)
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })