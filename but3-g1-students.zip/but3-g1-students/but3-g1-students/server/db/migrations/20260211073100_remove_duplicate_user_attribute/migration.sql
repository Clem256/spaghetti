-- DropForeignKey
ALTER TABLE "Annotation" DROP CONSTRAINT "Annotation_recipient_id_fkey";

-- AddForeignKey
ALTER TABLE "Annotation" ADD CONSTRAINT "Annotation_recipient_id_fkey" FOREIGN KEY ("recipient_id") REFERENCES "Student"("id") ON DELETE CASCADE ON UPDATE CASCADE;
