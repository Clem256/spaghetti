/*
  Warnings:

  - A unique constraint covering the columns `[gitlab_id]` on the table `User` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `gitlab_id` to the `User` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "User" ADD COLUMN     "gitlab_id" INTEGER NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "User_gitlab_id_key" ON "User"("gitlab_id");
