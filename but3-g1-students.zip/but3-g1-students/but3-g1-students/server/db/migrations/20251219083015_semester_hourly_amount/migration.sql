/*
  Warnings:

  - Added the required column `hourly_amount` to the `Semester` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Semester" ADD COLUMN     "hourly_amount" INTEGER NOT NULL,
ADD COLUMN     "promotion_id" INTEGER;

-- AddForeignKey
ALTER TABLE "Semester" ADD CONSTRAINT "Semester_promotion_id_fkey" FOREIGN KEY ("promotion_id") REFERENCES "Promotion"("id") ON DELETE CASCADE ON UPDATE CASCADE;
