/*
  Warnings:

  - Made the column `type` on table `User` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "User" ADD COLUMN     "avatar_url" TEXT,
ALTER COLUMN "type" SET NOT NULL;
