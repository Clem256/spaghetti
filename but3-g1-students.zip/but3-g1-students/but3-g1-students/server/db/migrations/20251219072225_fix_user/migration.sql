-- AlterTable
ALTER TABLE "User" ALTER COLUMN "type" DROP NOT NULL;
