-- AlterTable
ALTER TABLE "User" ALTER COLUMN "gitlab_id" DROP NOT NULL;
