/*
  Warnings:

  - You are about to drop the `SurveyStudent` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "SurveyStudent" DROP CONSTRAINT "SurveyStudent_student_id_fkey";

-- DropForeignKey
ALTER TABLE "SurveyStudent" DROP CONSTRAINT "SurveyStudent_survey_id_fkey";

-- DropTable
DROP TABLE "SurveyStudent";

-- CreateTable
CREATE TABLE "_StudentToSurvey" (
    "A" INTEGER NOT NULL,
    "B" INTEGER NOT NULL,

    CONSTRAINT "_StudentToSurvey_AB_pkey" PRIMARY KEY ("A","B")
);

-- CreateIndex
CREATE INDEX "_StudentToSurvey_B_index" ON "_StudentToSurvey"("B");

-- AddForeignKey
ALTER TABLE "_StudentToSurvey" ADD CONSTRAINT "_StudentToSurvey_A_fkey" FOREIGN KEY ("A") REFERENCES "Student"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_StudentToSurvey" ADD CONSTRAINT "_StudentToSurvey_B_fkey" FOREIGN KEY ("B") REFERENCES "Survey"("id") ON DELETE CASCADE ON UPDATE CASCADE;
