-- AlterTable
ALTER TABLE "User" ALTER COLUMN "personal_email" DROP NOT NULL;
