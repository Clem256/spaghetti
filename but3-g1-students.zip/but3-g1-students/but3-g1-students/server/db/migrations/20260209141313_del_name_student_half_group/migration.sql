/*
  Warnings:

  - You are about to drop the column `name` on the `StudentHalfGroup` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "StudentHalfGroup" DROP COLUMN "name";
