import { ClassWithHalfGroups } from "../../class/dto/class-with-half-groups-dto";

export type PromotionWithClasses = {
  classes: ClassWithHalfGroups[];
};