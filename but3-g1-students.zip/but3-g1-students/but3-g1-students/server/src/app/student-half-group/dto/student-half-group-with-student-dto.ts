import { StudentHalfGroup } from "../../../../db/generated/client";
import { StudentWithUser } from "../../student/dto/student-with-user-dto";

export type StudentHalfGroupWithStudent = StudentHalfGroup & { 
  student: StudentWithUser | null 
};