import { Option, Question, Survey } from "../../../db/generated/client";

export const surveyMapper = (survey: Survey, id?: number) => ({
  id: survey.id,
  name: survey.name,
  type: survey.type,
  limit_date: survey.limit_date,
  createdAt: survey.created_at,
  updatedAt: survey.updated_at,
});