import { NextFunction, Request, Response, Router } from 'express';
import {
  getAllSurveys,
  deleteSurvey,
  getSurveysByStudentId,
  getSurveyById,
  getOngoingSurveysByStudentId,
  getCompletedSurveysByStudentId,
  createSurvey,
  SearchSurveyGroups,
} from './survey.service';

const router = Router();

/**
 * Get surveys
 * @route {GET} /surveys
 * @returns list of surveys
 */
router.get('/surveys', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await getAllSurveys();
    res.json(result);
  } catch (error) {
    next(error);
  }
});



/**
 * Get surveys by student id
 * @route {GET} /survey/:id
 * @param id id of the student
 * @returns list of surveys
 */
router.get(
  '/surveys/student/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getSurveysByStudentId(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Get ongoing surveys by student id
 * @route {GET} /survey/ongoing/student/:id
 * @param id id of the student
 * @returns list of surveys
 */
router.get(
  '/surveys/ongoing/student/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getOngoingSurveysByStudentId(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Get completed surveys by student id
 * @route {GET} /surveys/completed/student/:id
 * @param id id of the student
 * @returns list of surveys
 */
router.get(
  '/surveys/completed/student/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getCompletedSurveysByStudentId(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Get survey
 * @route {GET} /survey/:id
 * @param id id of the survey
 */
router.get('/survey/:id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getSurveyById(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);


/**
 * Create survey
 * @route {POST} /survey
 * @returns survey :  created survey
 */
router.post('/survey', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const survey = await createSurvey(req.body);
    res.status(201).json(survey);
  } catch (err) {
    next(err);
  }
});

/**
 * Search groups of student
 * @route {GET} /surveys/groups/search
 * @returns list of surveys
 * exemple : http://localhost:3000/api/surveys/groups/search?search=RA1?semester=5
 */
router.get('/surveys/groups/search', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const search = String(req.query.search ?? '')
      const semester = Number(req.query.semester ?? false)
      const result = await SearchSurveyGroups(search,semester)
      res.json(result)
    } catch (error) {
      next(error)
    }
  },
)


/**
 * Update survey
 * @route {PUT} /survey/:id
 * @param id id of the survey
 * @bodyparam first_name new first_name
 * @bodyparam last_name new last_name
 * @bodyparam personal_email new personal_email
 * @bodyparam school_email new school_email
 * @bodyparam password new password
 * @bodyparam personal_email new personal_email
 * @bodyparam type new type
 * @returns survey updated survey
 */
// router.put('/survey/:id', async (req: Request, res: Response, next: NextFunction) => {
//     try {
//       const survey = await updateSurvey(req.body.survey, +req.params.id);
//       res.json({ survey });
//     } catch (error) {
//       next(error);
//     }
//   },
// );

/**
 * Delete survey
 * @route {DELETE} /survey/:id
 * @param id id of the survey
 */
router.delete(
  '/survey/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await deleteSurvey(+req.params.id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  },
);

export default router;