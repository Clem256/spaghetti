import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Option, Question, Student, Survey } from "../../../db/generated/client";
import { surveyMapper } from './survey.mapper';
import { studentMapper } from '../student/student.mapper';
import { HalfGroupWithStudents } from '../half-group/dto/half-group-with-students-dto';

export const getAllSurveys = async () => {
  const surveys = await prisma.survey.findMany({
    orderBy: {
      created_at: 'desc',
    },
  });
  return surveys.map((survey: Survey) => surveyMapper(survey));
};

export const getSurveysByStudentId = async (id: number) => {
  const existingSurveys = await prisma.survey.findMany({
    where: {
      students:{
        some:{
          id:id
        }
      }
    }
  });

  if (!existingSurveys) {
    throw new HttpException(404, {});
  }

  return existingSurveys.map((survey: Survey) => surveyMapper(survey));
};

export const getOngoingSurveysByStudentId = async (studentId: number) => {
  const surveys = await prisma.survey.findMany({
    where: {
      students: {
        some: { id: studentId },
      },
      questions: {
        none: {
          responses: {
            some: {
              student_id: studentId,
            },
          },
        },
      },
    },
  });

  return surveys.map(surveyMapper);
};


export const getCompletedSurveysByStudentId = async (studentId: number) => {
  const surveys = await prisma.survey.findMany({
    where: {
      students: {
        some: { id: studentId },
      },
      questions: {
        some: {
          responses: {
            some: {
              student_id: studentId,
            },
          },
        },
      },
    },
  });

  return surveys.map(surveyMapper);
};


export const getSurveyById = async (id: number) => {
  const existingSurvey = await prisma.survey.findFirst({
    where: {
      id,
    },
  });

  if (!existingSurvey) {
    throw new HttpException(404, {});
  }

  return existingSurvey;
};

export const deleteSurvey = async (id: number) => {
  const existingSurvey = await prisma.survey.findFirst({
    where: {
      id,
    },
  });

  if (!existingSurvey) {
    throw new HttpException(404, {});
  }

  await prisma.survey.delete({
    where: {
      id,
    },
  });
};

export const createSurvey = async (data: any) => {
  if (!data.studentIds || data.studentIds.length == 0) {
    throw new HttpException(400, { message: 'Aucun étudiant sélectionné' });
  }

  // un set est une collection sans doublons en typescript
  const uniqueStudentIds: number[] = Array.from(new Set(data.studentIds));


  // transaction sert à requêter la bdd uniquement si toutes les opérations passent pour éviter d'avoir des donnnées incohérentes
  const survey = await prisma.$transaction(async (transaction) => {
    return await transaction.survey.create({
      data: {
        name: data.name,
        type: data.type,
        limit_date: new Date(data.limit_date),

        students: {
          connect: uniqueStudentIds.map((id) => ({ id })),
        },

        questions: {
          create: data.questions.map((question: any) => ({
            label: question.label,
            type: question.type,
            ...(question.options?.length ? {
                  options: {
                    create: question.options.map((o: any) => ({
                      label: o.label,
                    })),
                  },
                } : {}),
          })),
        },
      },
      include: {
        students: true,
        questions: {
          include: { options: true },
        },
      },
    });
  });

  return surveyMapper(survey);
};

export const SearchSurveyGroups = async (query: string, semesterId?: number) => {
  // au moins 2 caractères dans la recherche
  if (!query || query.trim().length < 2) return [];

  const [classes, promotions, specializations, departments, halfGroups] = await prisma.$transaction([

    //classes
    prisma.class.findMany({
      where: { name: { contains: query, mode: "insensitive" } },
      take: 5,
      include: {
        HalfGroups: {
          include: {
            studentHalfGroups: {
              where: semesterId ? { semester_id: semesterId } : {},
              include: { student: { include: { user: true } } },
            },
          },
        },
      },
    }),

    //promos
    prisma.promotion.findMany({
      where: { name: { contains: query, mode: "insensitive" } },
      take: 5,
      include: {
        classes: {
          include: {
            HalfGroups: {
              include: {
                studentHalfGroups: {
                  where: semesterId ? { semester_id: semesterId } : {},
                  include: { student: { include: { user: true } } },
                },
              },
            },
          },
        },
      },
    }),

    //parcours
    prisma.specialization.findMany({
      where: {
        OR: [
          { name: { contains: query, mode: "insensitive" } },
          { code: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 5,
      include: {
        classes: {
          include: {
            HalfGroups: {
              include: {
                studentHalfGroups: {
                  where: semesterId ? { semester_id: semesterId } : {},
                  include: { student: { include: { user: true } } },
                },
              },
            },
          },
        },
      },
    }),

    //départements
    prisma.department.findMany({
      where: {
        OR: [
          { name: { contains: query, mode: "insensitive" } },
          { code: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 5,
      include: {
        promotions: {
          include: {
            classes: {
              include: {
                HalfGroups: {
                  include: {
                    studentHalfGroups: {
                      where: semesterId ? { semester_id: semesterId } : {},
                      include: {
                        student: { include: { user: true } },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    }),

    // demi groupes
    prisma.halfGroup.findMany({
      where: { name: { contains: query, mode: "insensitive" } },
      take: 5,
      include: {
        studentHalfGroups: {
          where: semesterId ? { semester_id: semesterId } : {},
          include: { student: { include: { user: true } } },
        },
      },
    }),
  ]);

  const extractStudents = (halfGroups: HalfGroupWithStudents[]) =>
    halfGroups.flatMap(hg =>
      hg.studentHalfGroups.map(shg => studentMapper(shg.student!))
    );

  const extractStudentsFromDepartment = (department: typeof departments[number]) =>
    department.promotions.flatMap(p =>
      p.classes.flatMap(c =>
        extractStudents(c.HalfGroups)
      )
    );


  return [
    ...classes.map(c => ({
      type: "class" as const,
      id: c.id,
      label: `${c.name}`,
      students: extractStudents(c.HalfGroups),
    })),

    ...promotions.map(p => ({
      type: "promotion" as const,
      id: p.id,
      label: `${p.name}`,
      students: p.classes.flatMap(c => extractStudents(c.HalfGroups)),
    })),

    ...specializations.map(s => ({
      type: "specialization" as const,
      id: s.id,
      label: `${s.name} (${s.code})`,
      students: s.classes.flatMap(c => extractStudents(c.HalfGroups)),
    })),

    ...departments.map(d => ({
      type: "department" as const,
      id: d.id,
      label: `${d.name}`,
      students: extractStudentsFromDepartment(d),
    })),

    ...halfGroups.map(h => ({
      type: "halfGroup" as const,
      id: h.id,
      label: `${h.name}`,
      students: extractStudents([h]),
    })),
  ];
};
