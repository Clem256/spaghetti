import { Teacher, User } from "../../../db/generated/client";
import userMapper from "../user/user.mapper";

export const teacherMapper = (teacher: Teacher & { user?: User }) => ({
  id: teacher.id,
  phone: teacher.phone,
  user_id: teacher.user_id,
  user: teacher.user ? userMapper(teacher.user) : undefined,
});
