import { NextFunction, Request, Response, Router } from 'express';
import { getCompileCacheDir } from 'module';
import { SearchTeacherGroups } from './teacher.service';

const router = Router();

/**
 * Search groups of student
 * @route {GET} /teacher/groups/search
 * @returns list of students
 * exemple : http://localhost:3000/api/teacher/groups/search?search=RA1?semester=5
 */
router.get('/teacher/groups/search', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const search = String(req.query.search ?? '')
      const semester = Number(req.query.semester ?? false)
      const result = await SearchTeacherGroups(search,semester)
      res.json(result)
    } catch (error) {
      next(error)
    }
  },
)

export default router;