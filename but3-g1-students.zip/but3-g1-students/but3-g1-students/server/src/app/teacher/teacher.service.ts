import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Option, Question, Student, Survey } from "../../../db/generated/client";
import { studentMapper } from '../student/student.mapper';
import { HalfGroupWithStudents } from '../half-group/dto/half-group-with-students-dto';

export const SearchTeacherGroups = async (query: string, semesterId?: number) => {
  // au moins 2 caractères dans la recherche
  if (!query || query.trim().length < 2) return [];

  const [classes, halfGroups] = await prisma.$transaction([

    //classes
    prisma.class.findMany({
      where: { name: { contains: query, mode: "insensitive" } },
      take: 5,
      include: {
        HalfGroups: {
          include: {
            studentHalfGroups: {
              where: semesterId ? { semester_id: semesterId } : {},
              include: { student: { include: { user: true } } },
            },
          },
        },
      },
    }),

    // demi groupes
    prisma.halfGroup.findMany({
      where: { name: { contains: query, mode: "insensitive" } },
      take: 5,
      include: {
        studentHalfGroups: {
          where: semesterId ? { semester_id: semesterId } : {},
          include: { student: { include: { user: true } } },
        },
      },
    }),
  ]);

  const extractStudents = (halfGroups: HalfGroupWithStudents[]) =>
    halfGroups.flatMap(hg =>
      hg.studentHalfGroups.map(shg => studentMapper(shg.student!))
    );

  return [
    ...classes.map(c => ({
      type: "class" as const,
      id: c.id,
      label: `${c.name}`,
      students: extractStudents(c.HalfGroups),
    })),

    ...halfGroups.map(h => ({
      type: "halfGroup" as const,
      id: h.id,
      label: `${h.name}`,
      students: extractStudents([h]),
    })),
  ];
};
