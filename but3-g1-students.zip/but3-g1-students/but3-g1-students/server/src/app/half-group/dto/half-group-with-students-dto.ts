import { HalfGroup } from "../../../../db/generated/client";
import { StudentHalfGroupWithStudent } from "../../student-half-group/dto/student-half-group-with-student-dto";

export type HalfGroupWithStudents = HalfGroup & {
  studentHalfGroups: StudentHalfGroupWithStudent[];
};