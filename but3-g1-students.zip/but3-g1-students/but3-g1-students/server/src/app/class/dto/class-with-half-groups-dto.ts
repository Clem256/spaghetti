import { HalfGroupWithStudents } from "../../half-group/dto/half-group-with-students-dto";

export type ClassWithHalfGroups = {
  HalfGroups: HalfGroupWithStudents[];
};