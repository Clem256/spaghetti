import { Class, HalfGroup, Student, StudentHalfGroup } from "../../../db/generated/client";
import userMapper from "../user/user.mapper";

export const classMapper = (prismaClass: Class & { halfGroup?: HalfGroup & {studentHalfGroup: StudentHalfGroup & {student: Student}}}) => ({
  id: prismaClass.id,
  name: prismaClass.name,
  created_at: prismaClass.created_at,
  updated_at: prismaClass.updated_at,
  specialization_id: prismaClass.specialization_id,
  promotion_id: prismaClass.promotion_id,
});

export default classMapper