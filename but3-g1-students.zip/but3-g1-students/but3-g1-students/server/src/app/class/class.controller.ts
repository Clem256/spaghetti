import { NextFunction, Request, Response, Router } from 'express';
import { getClassByStudentId } from './class.service';

const router = Router();

/**
 * Search a class by student id
 * @route {GET} /class/student
 * @returns class
 * exemple : http://localhost:3000/api/class/student?student_id=1
 */
router.get('/class/student', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const student_id = Number(req.query.student_id)
      const result = await getClassByStudentId(student_id, 5)
      res.json(result)
    } catch (error) {
      next(error)
    }
  },
)

export default router;