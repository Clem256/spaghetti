import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import classMapper from './class.mapper';

export const getClassByStudentId = async (studentId: number, semesterId: number) => {
  const studentHalfGroup = await prisma.studentHalfGroup.findFirst({
    where: {
      student_id: studentId,
      semester_id: semesterId,
    },
    include: {
      halfGroup: {
        include: {
          class: true,
        },
      },
    },
  });

  const studentClass = studentHalfGroup?.halfGroup?.class;

  if (!studentClass) {
    throw new HttpException(404, { message: 'class not found' });
  }


  return classMapper(studentClass);
};

