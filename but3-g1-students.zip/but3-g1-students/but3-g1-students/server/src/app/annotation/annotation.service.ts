import { Student, Teacher } from "../../../db/generated/client";
import prisma from "../../client";
import HttpException from "../http_exception/http-exception.model";
import { annotationMapper } from "./annotation.mapper";

export const getAllAnnotations = async () => {
    const annotations = await prisma.annotation.findMany();
    return annotations.map(annotationMapper);
}

export const getAnnotationsByStudentCode = async (student_code: string) => {
    const annotations = await prisma.annotation.findMany({
        where: {
            recipient: {
                student_code: student_code
            }
        }
    });
    return annotations.map(annotationMapper);
}

export const getAnnotationsByRecipientId = async (id: number) => {
    const annotations = await prisma.annotation.findMany({
        where: {
            recipient_id: id
        }
    });
    return annotations.map(annotationMapper);
}

export const getAnnotationCountByRecipientId = async (id: number) => {
    const count = await prisma.annotation.count({
        where: {
            recipient_id: id
        }
    });
    return count;
}

export const createAnnotation = async (author_id: number, recipient_id: number, content: string) => {

    const author = await prisma.teacher.findFirst({
        where:{
            id : author_id
        }
    });

    if (!author){
        throw new HttpException(404,"author not found");
    }

    const recipient = await prisma.student.findFirst({
        where:{
            id : recipient_id
        }
    });

    if (!recipient){
        throw new HttpException(404,"student not found");
    }

    if (!content || content.trim() == ""){
        throw new HttpException(404,"you must specify a content for the annotation");
    }

    const createdAnnotation = await prisma.annotation.create({
        data: {
        author_id: author.id,
        recipient_id: recipient.id,
        content: content,
        },
    });
    return annotationMapper(createdAnnotation);
};