import { NextFunction, Request, Response, Router } from "express";
import { getAllAnnotations, getAnnotationCountByRecipientId, getAnnotationsByRecipientId, getAnnotationsByStudentCode, createAnnotation } from "./annotation.service";

const router = Router();

/**
 * 
 */
router.get('/annotations', (req: Request, res: Response, next: NextFunction) => {
    try {
        const result = getAllAnnotations();
        res.json(result);
    } catch (error) {
        next(error);
    }
});

/**
 * Get annotations by student_code
 * @route {GET} /annotations/:student_code
 * @param student_code code of the student
 * @returns list of annotations
 */
router.get('/annotations/student/:student_code', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const result = await getAnnotationsByStudentCode(req.params.student_code);
        res.json(result);
    } catch (error) {
        next(error);
    }
});

/**
 * Get annotations by recipient id
 * @route {GET} /annotations/:recipientId
 * @param recipientId id of the recipient
 * @returns list of annotations
 */
router.get('/annotations/:recipientId', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const result = await getAnnotationsByRecipientId(+req.params.recipientId);
        res.json(result);
    } catch (error) {
        next(error);
    }
});

router.get('/annotations/count/:recipientId', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const result = await getAnnotationCountByRecipientId(+req.params.recipientId);
        res.json(result);
    } catch (error) {
        next(error);
    }
});

/**
 * Create annotation
 * @route {POST} /annotation
 * @returns annotation :  created annotation
 */
router.post('/annotation', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const annotation = await createAnnotation(data.author_id, data.recipient_id, data.content);
    res.status(201).json({ annotation });
  } catch (error) {
    next(error);
  }
});

export default router;