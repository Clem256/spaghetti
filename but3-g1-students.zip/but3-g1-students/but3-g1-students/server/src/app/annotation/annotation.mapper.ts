import { Annotation } from "../../../db/generated/client";

export const annotationMapper = (annotation: Annotation) => ({
    id: annotation.id,
    author_id: annotation.author_id,
    recipient_id: annotation.recipient_id,
    content: annotation.content,
    created_at: annotation.created_at,
    updated_at: annotation.updated_at,

})