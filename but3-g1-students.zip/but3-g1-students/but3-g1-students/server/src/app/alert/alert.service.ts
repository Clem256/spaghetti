import prisma from "../../client";
import alertMapper from "./alert.mapper";
import { Alert } from "../../../db/generated/client";

export const getAllAlerts = async (): Promise<{ alerts: Alert[] }> => {
  const alerts = await prisma.alert.findMany({
    orderBy: {
      created_at: 'desc',
    },
  });
  return {
    alerts: alerts.map((alert: Alert) => alertMapper(alert))
  };
}

export const getAlertsByStudentId = async (studentId: number | null) => {
  const alerts = await prisma.alert.findMany({
    where: { student_id: studentId },
    orderBy: {
      created_at: 'desc',
    },
  });
  return alerts.map((alert: Alert) => alertMapper(alert));
}