import { NextFunction, Router, Request, Response } from "express";
import { getAlertsByStudentId, getAllAlerts } from "./alert.service";

const router = Router();

/**
 * Get all alerts
 * @route {GET} /alerts
 * @returns alerts: list of alerts
 */
router.get('/alerts', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const result = await getAllAlerts();
        res.json(result);
    } catch (error) {
        next(error);
    }
});

/**
 * Get alerts by student ID
 * @route {GET} /alerts/student/:studentId
 * @param studentId - ID of the student
 * @returns list of alerts for the specified student
 */
router.get('/alerts/student/:studentId', async (req: Request, res: Response, next: NextFunction) => {
    try {
        const studentId = parseInt(req.params.studentId, 10);
        const alerts = await getAlertsByStudentId(studentId);
        res.json({ alerts });
    } catch (error) {
        next(error);
    }
});

export default router;