

import { Alert, AlertType } from "../../../db/generated/client"

const toAlertType = (type: string): AlertType => {
  switch (type.toUpperCase()) {
    case 'INFO':
      return AlertType.Info;
    case 'WARNING':
      return AlertType.Warning;
    case 'CRITICAL':
      return AlertType.Critical;
    default:
      console.warn(`Unknown alert type: ${type}, defaulting to Info`);
      return AlertType.Info;
  }
};

const alertMapper = (prismaAlert: Alert): Alert => ({
  id: prismaAlert.id,
  message: prismaAlert.message,
  url: prismaAlert.url,
  type: toAlertType(prismaAlert.type),
  created_at: prismaAlert.created_at,
  updated_at: prismaAlert.updated_at,
  student_id: prismaAlert.student_id || null,
});

export default alertMapper;