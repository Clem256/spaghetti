import { Router } from 'express';
import userController from './user/user.controller';
import surveyController from './survey/survey.controller';
import alertController from './alert/alert.controller';
import questionController from './question/question.controller';
import optionController from './option/option.controller';
import responseController from './response/response.controller';
import annotationController from './annotation/annotation.controller';
import competencyController from './competency/competency.controller';
import studentController from './student/student.controller';
import authController from './auth/auth.controller';
import teacherController from './teacher/teacher.controller';
import classController from './class/class.controller';

const api = Router()
  .use(userController)
  .use(alertController)
  .use(surveyController)
  .use(questionController)
  .use(optionController)
  .use(responseController)
  .use(competencyController)
  .use(annotationController)
  .use(studentController)
  .use(teacherController)
  .use(classController)
  .use(authController);

export default Router().use('/api', api);