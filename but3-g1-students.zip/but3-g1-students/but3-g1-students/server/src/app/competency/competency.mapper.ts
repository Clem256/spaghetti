const competencyMapper = (competency: any, id?: number) => ({
  id: competency.id,
  name: competency.name,
  code: competency.code,
  description: competency.description,
  created_at: competency.created_at,
  updated_at: competency.updated_at,
});

export default competencyMapper