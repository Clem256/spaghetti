import { NextFunction, Request, Response, Router } from 'express';
import {
  createCompetency,
  getAllCompetencies,
  getCompetencyById,
  getCompetenciesByStudentId,
  updateCompetency,
  deleteCompetency,
} from './competency.service';

const router = Router();

/**
 * Get competencies
 * @route {GET} /competencies
 * @returns competencies: list of competencies
 * @returns competenciesCount: number of competencies
 */
router.get('/competencies', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await getAllCompetencies();
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * Get competency
 * @route {GET} /competencies/:id
 * @param id id of the competency
 * @returns competency
 */
router.get(
  '/competencies/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getCompetencyById(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Get student competencies
 * @route {GET} /competencies/student/:studentId
 * @param studentId id of the student
 * @returns competencies: list of competencies
 * @returns competenciesCount: number of competencies
 */
router.get('/competencies/student/:studentId', async (req, res, next) => {
  try {
    const studentId = parseInt(req.params.studentId);
    const result = await getCompetenciesByStudentId(studentId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});


/**
 * Create competency
 * @route {POST} /competencies
 * @returns competency:  created competency
 */
router.post('/competencies', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const competency = await createCompetency(req.body.competency);
    res.status(201).json({ competency });
  } catch (error) {
    next(error);
  }
});

/**
 * Update competency
 * @route {PUT} /competencies/:id
 * @param id id of the competency
 * @bodyparam name new name
 * @bodyparam code new code
 * @bodyparam description new description
 * @returns competency updated competency
 */
router.put('/competencies/:id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const competency = await updateCompetency(req.body.competency, +req.params.id);
      res.json({ competency });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Delete competency
 * @route {DELETE} /competencies/:id
 * @param id id of the competency
 */
router.delete(
  '/competencies/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await deleteCompetency(+req.params.id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  },
);

export default router;