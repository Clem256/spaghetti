import prisma from '../../client';
import competencyMapper from './competency.mapper';
import HttpException from '../http_exception/http-exception.model';
import { Competency } from '../../../db/generated/client';

export const getAllCompetencies = async () => {
    console.log("recherche des compétences");
    const competencies = await prisma.competency.findMany({
        orderBy: {
            created_at: 'desc',
        },
    });
    console.log(competencies)
    return competencies.map((competency: Competency) => competencyMapper(competency));
};

export const getCompetencyById = async (id: number) => {
    const existingCompetency = await prisma.competency.findUnique({
        where: { id },
        include: {
            specializations: true,
            classCompetencies: true,
            teachingUnit: true
        }
    });

    if (!existingCompetency) {
        throw new HttpException(404, {});
    }

    return {
        competency: existingCompetency
    };
};

export const getCompetenciesByStudentId = async (studentId: number) => {
    const student = await prisma.student.findUnique({
        where: { id: studentId },
        include: {
            user: true
        }
    });

    if (!student) {
        throw new HttpException(404, { errors: { student: ["not found"] } });
    }
    const competencies = await prisma.competency.findMany({
        where: {
            classCompetencies: {
                some: {
                    semester: {
                        studentHalfGroups: {
                            some: {
                                student_id: studentId
                            }
                        }
                    }
                }
            }
        },
        distinct: ['id'],
        orderBy: {
            code: 'asc',
        },
        include: {
            teachingUnit: true,
            specializations: true,
            classCompetencies: {
                where: {
                    semester: {
                        studentHalfGroups: {
                            some: {
                                student_id: studentId
                            }
                        }
                    }
                },
                include: {
                    class: true,
                    semester: true
                }
            }
        }
    });

    return {
        competencies: competencies.map((competency: any) => competencyMapper(competency)),
        competenciesCount: competencies.length,
    };
};

export const createCompetency = async (competency: any) => {
    const { name, code, description } = competency;

    if (!name) {
        throw new HttpException(422, { errors: { first_name: ["can't be blank"] } });
    }

    if (!code) {
        throw new HttpException(422, { errors: { last_name: ["can't be blank"] } });
    }

    if (!description) {
        throw new HttpException(422, { errors: { personal_email: ["can't be blank"] } });
    }

    const existingCode = await prisma.competency.findUnique({
        where: {
            code,
        }
    });

    if (existingCode) {
        throw new HttpException(422, { errors: { code: ['must be unique'] } });
    }

    const {
        ...createdCompetency
    } = await prisma.competency.create({
        data: {
            name,
            code,
            description
        }
    });

    return competencyMapper(createdCompetency);
};

export const deleteCompetency = async (id: number) => {
    const existingCompetency = await prisma.competency.findFirst({
        where: {
            id,
        },
    });

    if (!existingCompetency) {
        throw new HttpException(404, {});
    }

    await prisma.competency.delete({
        where: {
            id,
        },
    });
};

export const updateCompetency = async (competency: any, id: number) => {

    const existingCompetency = await prisma.competency.findFirst({
        where: {
            id,
        },
    });

    if (!existingCompetency) {
        console.log('pas de compétence')
        throw new HttpException(404, {});
    }
    console.log(existingCompetency)
    const updatedCompetency = await prisma.competency.update({
        where: {
            id,
        },
        data: {
            ...(competency.name ? { name: competency.name } : {}),
            ...(competency.code ? { code: competency.code } : {}),
            ...(competency.description ? { description: competency.description } : {}),
            updated_at: new Date(),
        },
    });

    return competencyMapper(updatedCompetency, id);
};