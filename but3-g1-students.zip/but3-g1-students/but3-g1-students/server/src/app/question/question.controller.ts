import { NextFunction, Request, Response, Router } from 'express';
import {
  getQuestionsBySurveyId,
} from './question.service';

const router = Router();

/**
 * Get questions by survey id
 * @route {GET} /survey/questions/:id
 * @param id id of the survey
 * @returns list of questions
 */
router.get(
  '/survey/questions/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getQuestionsBySurveyId(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

export default router;
