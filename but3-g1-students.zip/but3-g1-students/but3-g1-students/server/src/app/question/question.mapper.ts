import { Option, Question, Survey } from "../../../db/generated/client";

export const questionMapper = (question: Question, id?: number) => ({
  id: question.id,
  label: question.label,
  type: question.type,
  createdAt: question.created_at,
  updatedAt: question.updated_at,
});
