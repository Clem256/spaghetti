import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Option, Question, Survey } from "../../../db/generated/client";
import { questionMapper } from './question.mapper';

export const getQuestionsBySurveyId = async (id: number) => {
  const existingQuestions = await prisma.question.findMany({
    where: {
      survey:{
          id:id
      }
    }
  });

  if (!existingQuestions) {
    throw new HttpException(404, {});
  }

  return existingQuestions.map((question: Question) => questionMapper(question));
};
