import { Department, Prisma, Student } from "../../../../db/generated/client";
import { PromotionWithClasses } from "../../promotion/dto/promotion-with-classes-dto";

export type DepartmentWithStudents = Department & {
  promotions: PromotionWithClasses[];
};