import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import jwt from 'jsonwebtoken';
import axios from 'axios';
import { compareSync } from "bcrypt-ts";
import { GITLAB_CONFIG } from "../../config/gitlab.config"
import { UserType } from '../../../db/generated/enums';
import { GitLabTokenResponse, GitLabUser } from './gitlab.types';

const JWT_SECRET: string = process.env.JWT_SECRET || 'undefined_secret_key';
const JWT_EXPIRES_IN: string = process.env.JWT_EXPIRES_IN || '7d';



export const generateToken = (userId: number): string => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
};

export const verifyToken = (token: string): { userId: number } => {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
    return decoded;
  } catch (error) {
    throw new HttpException(401, { message: 'Invalid or expired token' });
  }
};

export const getGitLabAuthUrl = (): string => {
  const params = new URLSearchParams({
    client_id: GITLAB_CONFIG.clientId,
    redirect_uri: GITLAB_CONFIG.redirectUri,
    response_type: 'code',
    scope: 'read_user',
  });

  return `${GITLAB_CONFIG.baseUrl}/oauth/authorize?${params.toString()}`;
};

const getGitLabAccessToken = async (code: string): Promise<string> => {
  try {
    const response = await axios.post<GitLabTokenResponse>(
      `${GITLAB_CONFIG.baseUrl}/oauth/token`,
      {
        client_id: GITLAB_CONFIG.clientId,
        client_secret: GITLAB_CONFIG.clientSecret,
        code,
        grant_type: 'authorization_code',
        redirect_uri: GITLAB_CONFIG.redirectUri,
      }
    );

    return response.data.access_token;
  } catch (error) {
    console.error('Error getting GitLab access token:', error);
    throw new HttpException(400, { message: 'Failed to get access token from GitLab' });
  }
};
  
const getGitLabUser = async (accessToken: string): Promise<GitLabUser> => {
  try {
    const response = await axios.get<GitLabUser>(
      `${GITLAB_CONFIG.baseUrl}/api/v4/user`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error('Error fetching GitLab user:', error);
    throw new HttpException(400, { message: 'Failed to fetch user from GitLab' });
  }
};

/**
 * Syntaxe name gitlab : "LastName FirstName username"
 * Parse le nom complet pour extraire le prénom et le nom de famille
 */
const parseName = (fullName: string): { first_name: string; last_name: string } => {
  const parts = fullName.trim().split(/\s+/);
  
  if (parts.length == 2) {
    return { first_name: parts[1], last_name: parts[0] };
  }
  
  const last_name = parts[0];
  const first_name = parts[1];
  
  return { first_name, last_name };
};


const determineUserType = (email: string): UserType => {

  if (email.includes('@etu.')) {
    return UserType.Student;
  }
  return UserType.Teacher;
};


export const handleGitLabCallback = async (code: string) => {

  const accessToken = await getGitLabAccessToken(code);

  const gitlabUser = await getGitLabUser(accessToken);

  const { first_name, last_name } = parseName(gitlabUser.name);

  // cas si le user s'est déjà connecté avec gitlab
  let user = await prisma.user.findUnique({
    where: { gitlab_id: gitlabUser.id },
    include: {
      student: true,
      teacher: true,
    },
  });

  if (!user) {
    // cas si le user a déjà un compte qui n'est pas connecté à son gitlab
    const existingUser = await prisma.user.findFirst({
      where: {
        OR: [
          { student: { student_code: gitlabUser.username } },
          { school_email: gitlabUser.email },
        ],
      },
      include: {
        student: true,
        teacher: true,
      },
    });

    if (existingUser) {
      if (existingUser.gitlab_id && existingUser.gitlab_id != gitlabUser.id) {
        throw new HttpException(409, { message: 'GitLab account already linked to another user' });
      }

      const updateData: any = {
        gitlab_id: gitlabUser.id,
        first_name,
        last_name,
        avatar_url: gitlabUser.avatar_url,
        updated_at: new Date(),
      };

      if (existingUser.type == UserType.Student && !existingUser.student) {
        updateData.student = {
          create: {
            is_representative: false,
            student_code: gitlabUser.username,
          },
        };
      }

      if (existingUser.type == UserType.Teacher && !existingUser.teacher) {
        updateData.teacher = {
          create: {},
        };
      }

      user = await prisma.user.update({
        where: { id: existingUser.id },
        data: updateData,
        include: {
          student: true,
          teacher: true,
        },
      });
    } else {
      const userType = determineUserType(gitlabUser.email);

      user = await prisma.user.create({
        data: {
          gitlab_id: gitlabUser.id,
          first_name,
          last_name,
          username: gitlabUser.username,
          personal_email: gitlabUser.email,
          school_email: gitlabUser.email, 
          avatar_url: gitlabUser.avatar_url,
          type: userType,
          ...(userType == UserType.Student && {
            student: {
              create: {
                is_representative: false,
                student_code: gitlabUser.username,
              },
            },
          }),
          ...(userType == UserType.Teacher && {
            teacher: {
              create: {},
            },
          }),
        },
        include: {
          student: true,
          teacher: true,
        },
      });
    }
  } else {
    user = await prisma.user.update({
      where: { id: user.id },
      data: {
        first_name,
        last_name,
        avatar_url: gitlabUser.avatar_url,
        updated_at: new Date(),
      },
      include: {
        student: true,
        teacher: true,
      },
    });
  }

  if (!user) {
    throw new HttpException(500, { message: 'Failed to create or update user' });
  }
  const token = generateToken(user.id);

  return {
    token,
    user: {
      id: user.id,
      gitlab_id: user.gitlab_id,
      first_name: user.first_name,
      last_name: user.last_name,
      personal_email: user.personal_email,
      school_email: user.school_email,
      avatar_url: user.avatar_url,
      type: user.type,
      created_at: user.created_at,
      updated_at: user.updated_at,
    },
  };
};


export const getUserByIdForAuth = async (userId: number) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      student: true,
      teacher: true,
      roles: {
        include: {
          permissions: true,
        },
      },
      permissions: true,
    },
  });

  if (!user) {
    throw new HttpException(404, { message: 'User not found' });
  }

  return user;
};

export const login = async (identifier: string, password: string) => {
  const user = await prisma.user.findFirst({
    where: {
    OR: [
      { username: identifier },
      { school_email: identifier }
    ],
  },
    include: {
      student: true,
      teacher: true,
      roles: {
        include: {
          permissions: true,
        },
      },
      permissions: true,
    },
  });

  if (!user) {
    throw new HttpException(404, { message: 'Identifiant ou mot de passe incorrect' });
  }

  //TODO retoucher pour gérer le cas où un utilisateur veut se connecter à un compte qui n'a pas de mot de passe (compte créé avec gitlab)
  if (user.password && compareSync(password,user.password)){
    const token = generateToken(user.id)
    return {
      token,
      user
    };
  }
  else{
    throw new HttpException(404, { message: 'Identifiant ou mot de passe incorrect' });
  }
}