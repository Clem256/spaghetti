import { User } from "../../../db/generated/client";

const authMapper = (prismaUser: User) => ({
  id: prismaUser.id,
  gitlabId: prismaUser.gitlab_id,
  first_name: prismaUser.first_name,
  last_name: prismaUser.last_name,
  personal_email: prismaUser.personal_email,
  school_email: prismaUser.school_email,
  avatar_url: prismaUser.avatar_url ?? null,
  created_at: prismaUser.created_at,
  updated_at: prismaUser.updated_at,
  type: prismaUser.type,
});

export default authMapper;
