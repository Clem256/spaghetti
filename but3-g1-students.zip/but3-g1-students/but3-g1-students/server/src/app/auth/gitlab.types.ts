export interface GitLabUser {
  id: number;
  username: string;
  name: string;
  email: string;
  avatar_url?: string;
}

export interface GitLabTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token: string;
}