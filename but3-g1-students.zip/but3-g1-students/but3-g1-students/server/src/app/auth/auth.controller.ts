import { NextFunction, Request, Response, Router } from 'express';
import {
  getGitLabAuthUrl,
  handleGitLabCallback,
  verifyToken,
  getUserByIdForAuth,
  login,
} from './auth.service';

const router = Router();

/**
 * Initiate GitLab OAuth flow
 * @route {GET} /auth/gitlab
 * @returns Redirect to GitLab authorization page
 */
router.get('/auth/gitlab', (req: Request, res: Response) => {
  const authUrl = getGitLabAuthUrl();
  res.redirect(authUrl);
});

/**
 * GitLab OAuth callback
 * @route {GET} /auth/gitlab/callback
 * @queryparam code - Authorization code from GitLab
 * @returns token and user information
 */
router.get(
  '/auth/gitlab/callback',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { code } = req.query;

      if (!code || typeof code !== 'string') {
        return res.status(400).json({ 
          error: 'Missing authorization code' 
        });
      }

      const result = await handleGitLabCallback(code);

      const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:4200';
      res.redirect(`${frontendUrl}/auth/callback?token=${result.token}`);
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Get current authenticated user
 * @route {GET} /auth/me
 * @header Authorization Bearer token
 * @returns user information
 */
router.get(
  '/auth/me',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const authHeader = req.headers.authorization;

      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ 
          error: 'Missing or invalid authorization header' 
        });
      }

      const token = authHeader.substring(7);
      const { userId } = verifyToken(token);
      const user = await getUserByIdForAuth(userId);

      res.json({ user });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Logout (client-side token removal)
 * @route {POST} /auth/logout
 * @returns success message
 */
router.post('/auth/logout', (req: Request, res: Response) => {
  // With JWT, logout is handled client-side by removing the token
  // This endpoint exists for consistency and future server-side logout logic
  res.json({ message: 'Logged out successfully' });
});


router.post('/auth/login',async (req: Request, res: Response, next: NextFunction) => {
    try {

      const { identifier, password  } = req.body;

      const result = await login(identifier, password);

      res.status(200).json({ response: result });

    } catch (error) {
      next(error);
    }
  }
);

export default router;
