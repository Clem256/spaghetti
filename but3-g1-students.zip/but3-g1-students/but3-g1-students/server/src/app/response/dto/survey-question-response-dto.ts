export interface SurveyQuestionResponseDto {
  question_id: number;
  student_id: number;
  option_id?: number;
  option_ids?: number[];
  content?: string;
}