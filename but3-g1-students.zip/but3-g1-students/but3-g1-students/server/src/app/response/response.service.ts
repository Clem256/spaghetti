import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Option, Question, Response } from "../../../db/generated/client";
import { responseMapper } from './response.mapper';
import { SurveyQuestionResponseDto } from './dto/survey-question-response-dto';

export const createResponse = async (response: Response) => {
  const { content,
      question_id,
      option_id,
      student_id } = response;

  if ((content && option_id) || (!content && !option_id)) {
    throw new HttpException(422, { errors: "response must either contain text content or an option id" });
  }

  if (!question_id) {
    throw new HttpException(422, { errors: { question_id: ["can't be blank"] } });
  }

  if (!student_id) {
    throw new HttpException(422, { errors: { student_id: ["can't be blank"] } });
  }

  const question = await prisma.question.findFirst({
    where: {
      id:+question_id,
    }
  });

  
  if (question?.type == "SingleChoice") {
    const existingResponse = await prisma.response.findFirst({
      where: {
        question_id:+question_id,
        student_id:+student_id!,
      }
    });
    if (existingResponse) {
      throw new HttpException(422, { errors: "the question is single choice there can only be one answer" });
    }
  }

  const {
    ...createdResponse
  } = await prisma.response.create({
    data: {
      content,
      question_id,
      option_id,
      student_id
    }
  });

  return responseMapper(createdResponse);
};

export const getResponsesByStudentAndSurvey = async (
  surveyId: number,
  studentId: number
) => {
  const responses = await prisma.response.findMany({
    where: {
      student_id: studentId,
      question: {
        survey_id: surveyId,
      },
    },
    include: {
      question: {
        include: {
          options: true,
        },
      },
      option: true,
    },
    orderBy: {
      created_at: 'asc',
    },
  });


  return responses.map(responseMapper);
};

export const getResponsesByStudentAndQuestion = async (
  quesionId: number,
  studentId: number
) => {
  const responses = await prisma.response.findMany({
    where: {
      student_id: studentId,
      question_id: quesionId
    },
    orderBy: {
      created_at: 'asc',
    },
  });


  return responses.map(responseMapper);
};

export const saveResponse = async (payload: {
  question_id: number;
  student_id: number;
  option_id?: number;
  option_ids?: number[];
  content?: string;
}) => {

  const { question_id, student_id } = payload;

  if (!question_id || !student_id) {
    throw new HttpException(422, {errors: "question_id and student_id are required"});
  }

  const question = await prisma.question.findUnique({
    where: { id: question_id }
  });

  if (!question) {
    throw new HttpException(404, { errors: "question not found" });
  }

  switch (question.type) {

    case "SingleChoice":
      return handleSingleChoice(payload);

    case "MultiChoices":
      return handleMultiChoices(payload);

    case "Free":
      return handleFreeText(payload);

    default:
      throw new HttpException(400, { errors: "invalid question type" });
  }
};

const handleSingleChoice = async ({question_id,student_id,option_id}: SurveyQuestionResponseDto) => {

  if (!option_id) {
    throw new HttpException(422, {errors: "option_id is required for SingleChoice"});
  }

  return prisma.$transaction(async (transaction) => {

    const existingResponse = await transaction.response.findFirst({
      where: { question_id, student_id }
    });

    if (existingResponse) {
      return transaction.response.update({
        where: { id: existingResponse.id },
        data: { option_id, content: null }
      });
    }

    return transaction.response.create({
      data: {
        question_id,
        student_id,
        option_id
      }
    });

  });
};

const handleMultiChoices = async ({question_id, student_id, option_ids}: SurveyQuestionResponseDto) => {

  if (!Array.isArray(option_ids)) {
    throw new HttpException(422, {errors: "option_ids must be an array"});
  }

  return prisma.$transaction(async (transaction) => {

    const existingResponses = await transaction.response.findMany({
      where: { question_id, student_id }
    });

    const existingOptionIds = existingResponses.map(r => r.option_id);

    await transaction.response.deleteMany({
      where: {
        question_id,
        student_id,
        option_id: {
          notIn: option_ids
        }
      }
    });

    const toCreate = option_ids.filter(id => !existingOptionIds.includes(id));

    if (toCreate.length > 0) {
      await transaction.response.createMany({
        data: toCreate.map(option_id => ({
          question_id,
          student_id,
          option_id
        }))
      });
    }

    return transaction.response.findMany({
      where: { question_id, student_id }
    });

  });
};

const handleFreeText = async ({question_id, student_id, content}: SurveyQuestionResponseDto) => {

  if (!content) {
    throw new HttpException(422, {errors: "content is required for Free question"});
  }

  return prisma.$transaction(async (transaction) => {

    const existing = await transaction.response.findFirst({
      where: { question_id, student_id }
    });

    if (existing) {
      return transaction.response.update({
        where: { id: existing.id },
        data: {
          content,
          option_id: null
        }
      });
    }

    return transaction.response.create({
      data: {
        question_id,
        student_id,
        content
      }
    });

  });
};