import { NextFunction, Request, Response, Router } from 'express';
import { createResponse, getResponsesByStudentAndQuestion, getResponsesByStudentAndSurvey, saveResponse } from './response.service';


const router = Router();

/**
 * Create response
 * @route {POST} /survey/quesion/response
 * @returns response :  created response
 */
router.post('/survey/question/response',async (req: Request, res: Response, next: NextFunction) => {
    try {

      const { question_id, student_id, option_id, option_ids, content } = req.body;

      const result = await saveResponse({
        question_id: +question_id,
        student_id: +student_id,
        option_id: option_id ? +option_id : undefined,
        option_ids: option_ids ?? undefined,
        content: content ?? undefined
      });

      res.status(200).json({ response: result });

    } catch (error) {
      next(error);
    }
  }
);

/**
 * Get responses of a student for a survey
 * @route {GET} /survey/:idSurvey/responses/student/:idStudent
 * @param idSurvey id of the survey
 * @param idStudent id of the student
 * @returns list of responses
 */
router.get(
  '/survey/:idSurvey/responses/student/:idStudent',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getResponsesByStudentAndSurvey(+req.params.idSurvey,+req.params.idStudent);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Get responses of a student for a question
 * @route {GET} /survey/question/:idQuestion/responses/student/:idStudent
 * @param idQuestion id of the question
 * @param idStudent id of the student
 * @returns list of responses
 */
router.get(
  '/survey/question/:idQuestion/responses/student/:idStudent',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getResponsesByStudentAndQuestion(+req.params.idQuestion,+req.params.idStudent);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

export default router;