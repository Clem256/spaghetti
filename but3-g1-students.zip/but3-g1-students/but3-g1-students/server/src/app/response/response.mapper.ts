import { Option, Question, Survey, Response } from "../../../db/generated/client";

export const responseMapper = (response: Response, id?: number) => ({
  id: response.id,
  content: response.content,
  questionId: response.question_id,
  optionId: response.option_id,
  studentId: response.student_id,
});