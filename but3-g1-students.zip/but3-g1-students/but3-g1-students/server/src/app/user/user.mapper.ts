import { User } from "../../../db/generated/client";

const userMapper = (prismaUser: any, id?: number) => ({
  id: prismaUser.id,
  first_name: prismaUser.first_name,
  last_name: prismaUser.last_name,
  username: prismaUser.username,
  personal_email: prismaUser.personal_email,
  school_email: prismaUser.school_email,
  avatar_url: prismaUser.avatar_url,
  created_at: prismaUser.created_at,
  updated_at: prismaUser.updated_at,
  type: prismaUser.type,
  student: prismaUser.student ?? null,
  teacher: prismaUser.teacher ?? null,
});

export default userMapper