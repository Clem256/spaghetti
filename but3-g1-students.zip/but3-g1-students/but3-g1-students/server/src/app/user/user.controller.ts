import { NextFunction, Request, Response, Router } from 'express';
import {
  createUser,
  getAllUsers,
  getUserById,
  updateUser,
  deleteUser,
} from './user.service';

const router = Router();

/**
 * Get users
 * @route {GET} /users
 * @returns users: list of users
 * @returns userCount: number of users
 */
router.get('/users', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await getAllUsers();
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * Get user
 * @route {GET} /users/:id
 * @param id id of the user
 */
router.get(
  '/users/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getUserById(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);


/**
 * Create user
 * @route {POST} /users
 * @returns user :  created user
 */
router.post('/users', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = await createUser(req.body.user);
    res.status(201).json({ user });
  } catch (error) {
    next(error);
  }
});

/**
 * Update user
 * @route {PUT} /user/:id
 * @param id id of the user
 * @bodyparam first_name new first_name
 * @bodyparam last_name new last_name
 * @bodyparam personal_email new personal_email
 * @bodyparam school_email new school_email
 * @bodyparam password new password
 * @bodyparam personal_email new personal_email
 * @bodyparam type new type
 * @returns user updated user
 */
router.put('/users/:id', async (req: Request, res: Response, next: NextFunction) => {
    try {
      const user = await updateUser(req.body.user, +req.params.id);
      res.json({ user });
    } catch (error) {
      next(error);
    }
  },
);

/**
 * Delete user
 * @route {DELETE} /user/:id
 * @param id id of the user
 */
router.delete(
  '/users/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      await deleteUser(+req.params.id);
      res.sendStatus(204);
    } catch (error) {
      next(error);
    }
  },
);

export default router;