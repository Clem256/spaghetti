import prisma from '../../client';
import userMapper from './user.mapper';
import HttpException from '../http_exception/http-exception.model';
import { User, UserType } from '../../../db/generated/client';

export const getAllUsers = async () => {
  const usersCount = await prisma.user.count();

  const users = await prisma.user.findMany({
    orderBy: {
      created_at: 'desc',
    },
    include: {
      student: true,
      teacher: true,
      roles: {
        include: {
          permissions: true,
        },
      },
    },
  });

  return {
    users: users.map((user: User) => userMapper(user)),
    usersCount,
  };
};

export const getUserById = async (id: number) => {
  const existingUser = await prisma.user.findUnique({
    where: { id },
    include: {
      student: true,
      teacher: true,
      roles: {
        include: {
          permissions: true,
        },
      },
      permissions: true,
    },
  });

  if (!existingUser) {
    throw new HttpException(404, { message: 'User not found' });
  }

  return userMapper(existingUser);
};

/**
 * Créer user manuellement (non-OAuth), pour resp pedagogique ou admin etc
 * Users OAuth créés via auth.service.ts
 */
export const createUser = async (user: User & { student_code?: string }) => {
  const {
    first_name,
    last_name,
    personal_email,
    school_email,
    type,
    gitlab_id
  } = user;

  if (!first_name) {
    throw new HttpException(422, { errors: { first_name: ["can't be blank"] } });
  }

  if (!last_name) {
    throw new HttpException(422, { errors: { last_name: ["can't be blank"] } });
  }

  if (!school_email) {
    throw new HttpException(422, { errors: { school_email: ["can't be blank"] } });
  }

  const existingPersonalEmail = await prisma.user.findUnique({
    where: {
      personal_email: personal_email ?? undefined,
    },
  });

  if (existingPersonalEmail) {
    throw new HttpException(422, { errors: { personal_email: ['must be unique'] } });
  }

  const existingSchoolEmail = await prisma.user.findUnique({
    where: {
      school_email,
    },
  });

  if (existingSchoolEmail) {
    throw new HttpException(422, { errors: { school_email: ['must be unique'] } });
  }

  if (gitlab_id) {
    const existingGitLabId = await prisma.user.findUnique({
      where: {
        gitlab_id,
      },
    });

    if (existingGitLabId) {
      throw new HttpException(422, { errors: { gitlab_id: ['must be unique'] } });
    }
  }

  const createdUser = await prisma.user.create({
    data: {
      gitlab_id: gitlab_id,
      first_name,
      last_name,
      username: user.username,
      personal_email,
      school_email,
      type: type || UserType.Student,
      ...(type == UserType.Student && user.student_code && {
        student: {
          create: {
            student_code: user.student_code,
            is_representative: false,
          },
        },
      }),
      ...(type == UserType.Teacher && {
        teacher: {
          create: {},
        },
      }),
    },
    include: {
      student: true,
      teacher: true,
    },
  });

  return userMapper(createdUser);
};

export const deleteUser = async (id: number) => {
  const existingUser = await prisma.user.findFirst({
    where: {
      id,
    },
  });

  if (!existingUser) {
    throw new HttpException(404, { message: 'User not found' });
  }

  await prisma.user.delete({
    where: {
      id,
    },
  });
};

export const updateUser = async (user: User, id: number) => {
  const existingUser = await prisma.user.findFirst({
    where: {
      id,
    },
  });

  if (!existingUser) {
    throw new HttpException(404, { message: 'User not found' });
  }

  if (user.personal_email && user.personal_email != existingUser.personal_email) {
    const emailExists = await prisma.user.findUnique({
      where: { personal_email: user.personal_email },
    });

    if (emailExists) {
      throw new HttpException(422, { errors: { personal_email: ['must be unique'] } });
    }
  }

  if (user.school_email && user.school_email != existingUser.school_email) {
    const emailExists = await prisma.user.findUnique({
      where: { school_email: user.school_email },
    });

    if (emailExists) {
      throw new HttpException(422, { errors: { school_email: ['must be unique'] } });
    }
  }

  const updatedUser = await prisma.user.update({
    where: {
      id,
    },
    data: {
      ...(user.first_name && { first_name: user.first_name }),
      ...(user.last_name && { last_name: user.last_name }),
      ...(user.personal_email && { personal_email: user.personal_email }),
      ...(user.school_email && { school_email: user.school_email }),
      ...(user.avatar_url != undefined && { avatar_url: user.avatar_url }),
      ...(user.type && { type: user.type }),
      updated_at: new Date(),
    },
    include: {
      student: true,
      teacher: true,
    },
  });

  return userMapper(updatedUser);
};
