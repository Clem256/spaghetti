import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Student } from '../../../db/generated/client';
import { studentMapper } from './student.mapper';

// Helper pour arrondir à 3 décimales
const round = (value: number | null): number | null => {
    if (value === null) return null;
    return Math.round(value * 1000) / 1000;
};

export const getAllStudents = async () => {
    console.log("recherche des étudiants");
    const students = await prisma.student.findMany();
    console.log(students)
    return students.map((student: Student) => studentMapper(student));
};

export const getEvaluationPeriodResultsById = async (id: number) => {
    console.log(`Recherche des résultats par période d'évaluation pour l'étudiant ${id}`);

    // Vérifier que l'étudiant existe
    const student = await prisma.student.findUnique({
        where: { id: id },
        include: {
            user: true,
            studentHalfGroups: {
                include: {
                    semester: {
                        include: {
                            promotion: true,
                            classCompetencies: {
                                include: {
                                    competency: {
                                        include: {
                                            teachingUnit: true
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    });

    if (!student) {
        throw new HttpException(404, { errors: { student: ["not found"] } });
    }

    // Récupérer toutes les notes de l'étudiant avec leurs relations complètes
    const averageMarks = await prisma.averageMark.findMany({
        where: {
            student_id: id
        },
        include: {
            module: true,
            averageMarkTeachingUnits: {
                include: {
                    teachingUnit: true
                }
            }
        }
    });

    // Grouper par semester et construire la structure EvaluationPeriodDetailsModel
    const semesterMap = new Map();

    for (const shg of student.studentHalfGroups) {
        const semester = shg.semester;
        
        if (!semester || semesterMap.has(semester.id)) continue;

        // Récupérer le year et order du semester à partir de la promotion
        const promotion = semester.promotion;
        const semesterNumber = parseInt(semester.name.match(/(\d+)(?!.*\d)/)?.[0] || '1');
        const year = Math.ceil(semesterNumber / 2);
        const order = semesterNumber;

        // Récupérer les unités d'enseignement pour ce semester
        // Les teachingUnits sont filtrées selon leur code qui commence par le numéro du semestre
        const teachingUnitsSet = new Map();
        const semesterPrefix = `UE${semesterNumber}`;
        
        // D'abord, chercher dans les classCompetencies du semester
        for (const cc of semester.classCompetencies) {
            if (cc.competency?.teachingUnit) {
                for (const tu of cc.competency.teachingUnit) {
                    if (tu.code.startsWith(semesterPrefix)) {
                        if (!teachingUnitsSet.has(tu.id)) {
                            teachingUnitsSet.set(tu.id, {
                                id: tu.id,
                                label: tu.code,
                                order: parseInt(tu.code.substring(4)) || tu.id
                            });
                        }
                    }
                }
            }
        }
        
        // Ensuite, compléter avec les teachingUnits présentes dans les averageMarks si nécessaire
        for (const am of averageMarks) {
            for (const amtu of am.averageMarkTeachingUnits) {
                if (amtu.teachingUnit && amtu.teachingUnit.code.startsWith(semesterPrefix)) {
                    if (!teachingUnitsSet.has(amtu.teachingUnit.id)) {
                        teachingUnitsSet.set(amtu.teachingUnit.id, {
                            id: amtu.teachingUnit.id,
                            label: amtu.teachingUnit.code,
                            order: parseInt(amtu.teachingUnit.code.substring(4)) || amtu.teachingUnit.id
                        });
                    }
                }
            }
        }
        
        const teachingUnits = Array.from(teachingUnitsSet.values())
            .sort((a, b) => a.order - b.order);

        // Construire les rows avec les modules et leurs coefficients
        const rows: any[] = [];
        const moduleMap = new Map();

        for (const am of averageMarks) {
            if (!am.module) continue;

            // Vérifier que le module appartient à ce semestre
            // Le numéro du semestre est le chiffre après la première lettre du code
            const moduleCode = am.module.code;
            const moduleSemesterNumber = parseInt(moduleCode.substring(1, 2));
            
            if (moduleSemesterNumber !== semesterNumber) continue;

            const moduleKey = am.module.id;

            // Récupérer les coefficients pour ce module
            const coefficients = am.averageMarkTeachingUnits
                .filter(amtu => amtu.teachingUnit)
                .map(amtu => ({
                    teachingUnitId: amtu.teachingUnit!.id,
                    value: amtu.coefficient
                }));

            // Si des coefficients existent et sont pertinents pour ce semester, ajouter le module
            if (coefficients.length > 0) {
                if (!moduleMap.has(moduleKey)) {
                    moduleMap.set(moduleKey, {
                        id: am.module.id,
                        label: `${am.module.code} ${am.module.name}`,
                        order: am.module.id,
                        value: round(am.value),
                        coefficients: coefficients
                    });
                } else {
                    // Fusionner les coefficients s'il y a plusieurs entrées
                    moduleMap.get(moduleKey).coefficients.push(...coefficients);
                }
            }
        }

        // Convertir la map en array trié
        const sortedRows = Array.from(moduleMap.values())
            .sort((a, b) => a.order - b.order);

        semesterMap.set(semester.id, {
            name: semester.name,
            year: year,
            order: order,
            teachingUnits: teachingUnits,
            rows: sortedRows
        });
    }

    // Convertir le map en array trié par order
    const evaluationPeriods = Array.from(semesterMap.values())
        .sort((a, b) => a.order - b.order);

    console.log(evaluationPeriods)
    return evaluationPeriods;
};

export const getCompetenciesResultsById = async (id: number, semesterName?: string) => {
    console.log(`Recherche des résultats de compétences pour l'étudiant ${id}`);

    // Vérifier que l'étudiant existe
    const student = await prisma.student.findUnique({
        where: { id: id },
        include: {
            studentHalfGroups: {
                include: {
                    halfGroup: true,
                    semester: {
                        include: {
                            promotion: true,
                            classCompetencies: {
                                include: {
                                    competency: {
                                        include: {
                                            teachingUnit: true
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    });

    if (!student) {
        throw new HttpException(404, { errors: { student: ["not found"] } });
    }

    // Récupérer toutes les notes de l'étudiant avec leurs relations complètes
    const averageMarks = await prisma.averageMark.findMany({
        where: {
            student_id: id
        },
        include: {
            module: true,
            averageMarkTeachingUnits: {
                include: {
                    teachingUnit: {
                        include: {
                            competency: true
                        }
                    }
                }
            }
        }
    });

    // Structure pour stocker les résultats par semestre et par année
    const semesterResults: any[] = [];
    const yearCompetencyValues = new Map<number, Map<number, { sum: number; coefficientSum: number }>>();
    const yearHalfGroupNames = new Map<number, string>();
    
    // Récupérer toutes les compétences uniques de tous les semestres
    const allCompetenciesSet = new Map<number, any>();
    for (const shg of student.studentHalfGroups) {
        const semester = shg.semester;
        if (!semester) continue;
        
        for (const cc of semester.classCompetencies) {
            if (cc.competency) {
                allCompetenciesSet.set(cc.competency.id, cc.competency);
            }
        }
    }

    for (const shg of student.studentHalfGroups) {
        const semester = shg.semester;
        if (semesterName && semester?.name != semesterName) continue;
        if (!semester) continue;

        const semesterNumber = parseInt(semester.name.match(/(\d+)(?!.*\d)/)?.[0] || '1');
        const year = Math.ceil(semesterNumber / 2);

        // Initialiser la map pour cette année si nécessaire
        if (!yearCompetencyValues.has(year)) {
            yearCompetencyValues.set(year, new Map());
        }

        // Stocker le nom du halfGroup pour cette année
        if (shg.halfGroup?.name && !yearHalfGroupNames.has(year)) {
            yearHalfGroupNames.set(year, shg.halfGroup.name);
        }

        // Calculer les résultats pour chaque compétence (toutes les compétences, pas seulement celles du semestre)
        const competencyValues = new Map<number, { sum: number; coefficientSum: number }>();

        // Initialiser avec toutes les compétences
        for (const competency of allCompetenciesSet.values()) {
            competencyValues.set(competency.id, { sum: 0, coefficientSum: 0 });
        }

        // Parcourir les notes et les associer aux compétences via les TeachingUnits
        for (const am of averageMarks) {
            if (!am.module) continue;

            // Vérifier que le module appartient à ce semestre
            const moduleCode = am.module.code;
            const moduleSemesterNumber = parseInt(moduleCode.substring(1, 2));
            
            if (moduleSemesterNumber !== semesterNumber) continue;

            // Pour chaque TeachingUnit lié à cette note
            for (const amtu of am.averageMarkTeachingUnits) {
                if (amtu.teachingUnit?.competency) {
                    const competencyId = amtu.teachingUnit.competency.id;
                    if (competencyValues.has(competencyId)) {
                        const current = competencyValues.get(competencyId)!;
                        // Ajouter la note pondérée par le coefficient
                        current.sum += am.value * (amtu.coefficient || 0);
                        // Ajouter le coefficient à la somme totale des coefficients
                        current.coefficientSum += (amtu.coefficient || 0);

                        // Accumuler pour l'année
                        const yearCompetencies = yearCompetencyValues.get(year)!;
                        if (!yearCompetencies.has(competencyId)) {
                            yearCompetencies.set(competencyId, { sum: 0, coefficientSum: 0 });
                        }
                        const yearCurrent = yearCompetencies.get(competencyId)!;
                        yearCurrent.sum += am.value * (amtu.coefficient || 0);
                        yearCurrent.coefficientSum += (amtu.coefficient || 0);
                    }
                }
            }
        }

        // Convertir en format final pour ce semestre
        const values = Array.from(competencyValues.entries()).map(([competencyId, data]) => ({
            competencyId: competencyId,
            value: round(data.coefficientSum > 0 ? data.sum / data.coefficientSum : null)
        }));

        semesterResults.push({
            type: 'SEMESTER',
            label: semester.name,
            year: year,
            semester: semesterNumber,
            values: values
        });
    }

    // Créer les résultats agrégés par année
    const aggregateResults: any[] = [];
    for (const [year, competencyData] of yearCompetencyValues.entries()) {
        // Inclure toutes les compétences pour cette année, avec null si aucune donnée
        const aggregateValues = Array.from(allCompetenciesSet.keys()).map(competencyId => ({
            competencyId: competencyId,
            value: competencyData.has(competencyId) 
                ? round(competencyData.get(competencyId)!.coefficientSum > 0 
                    ? competencyData.get(competencyId)!.sum / competencyData.get(competencyId)!.coefficientSum 
                    : null)
                : null
        }));

        const halfGroupName = yearHalfGroupNames.get(year) || `BUT${year}`;

        aggregateResults.push({
            type: 'AGGREGATE',
            label: halfGroupName,
            year: year,
            values: aggregateValues
        });
    }

    // Trier les résultats: d'abord les semestres par ordre, puis les agrégats par année
    const sortedResults = semesterResults.sort((a, b) => a.semester - b.semester);
    const sortedAggregates = aggregateResults.sort((a, b) => a.year - b.year);
    
    const finalResults = [...sortedResults, ...sortedAggregates];

    console.log("competenciesResults : " + JSON.stringify(finalResults));
    return finalResults;
};

export const getAbsencesResultsById = async (id: number, semesterName?: string) => {
    console.log(`Recherche des résultats d'absences pour l'étudiant ${id}`);

    // vérifier existence de l'étudiant
    const student = await prisma.student.findUnique({
        where: { id },
        include: {
            studentHalfGroups: {
                include: { semester: true, halfGroup: true }
            }
        }
    });

    if (!student) {
        throw new HttpException(404, { errors: { student: ["not found"] } });
    }

    // récupérer toutes les absences (avec semestre associé)
    const absences = await prisma.absence.findMany({
        where: { student_id: id },
        include: { semester: true }
    });

    // constantes de calcul
    const HOURS_PER_ABSENCE = 2;

    type Stat = {
        type: 'SEMESTER' | 'AGGREGATE';
        label: string;
        year: number;
        semester?: number;
        totalHours: number;
        absenceHours: number;
        absenceCount: number;
        unjustifiedAbsenceCount: number;
        absenceRate: number;
    };

    const semesterMap = new Map<number, Stat>();
    const yearMap = new Map<number, Stat>();

    // collecte des noms de half‑group par année pour les libellés d'agrégat
    const yearHalfGroupNames = new Map<number, string>();
    for (const shg of student.studentHalfGroups) {
        const sem = shg.semester;
        if (!sem) continue;
        const semNumber = parseInt(sem.name.match(/(\d+)(?!.*\d)/)?.[0] || '1');
        const year = Math.ceil(semNumber / 2);
        if (shg.halfGroup?.name && !yearHalfGroupNames.has(year)) {
            yearHalfGroupNames.set(year, shg.halfGroup.name);
        }
    }

    // calcul par semestre
    for (const a of absences) {
        const sem = a.semester;
        if (!sem) continue;
        if (semesterName && sem.name !== semesterName) continue;

        const semId = sem.id;
        let entry = semesterMap.get(semId);
        if (!entry) {
            const semNumber = parseInt(sem.name.match(/(\d+)(?!.*\d)/)?.[0] || '1');
            const year = Math.ceil(semNumber / 2);
            entry = {
                type: 'SEMESTER',
                label: sem.name,
                year,
                semester: semNumber,
                totalHours: sem.hourly_amount,
                absenceHours: 0,
                absenceCount: 0,
                unjustifiedAbsenceCount: 0,
                absenceRate: 0
            };
            semesterMap.set(semId, entry);
        }

        entry.absenceCount += 1;
        entry.absenceHours += HOURS_PER_ABSENCE;
        if (!a.is_justified) entry.unjustifiedAbsenceCount += 1;
    }

    // taux pour chaque semestre
    semesterMap.forEach(e => {
        e.absenceRate = e.totalHours > 0 ? Math.round((e.absenceHours / e.totalHours) * 10000) / 100 : 0;
    });

    // agrégats par année
    semesterMap.forEach(e => {
        const year = e.year;
        let agg = yearMap.get(year);
        if (!agg) {
            agg = {
                type: 'AGGREGATE',
                label: '',
                year,
                totalHours: 0,
                absenceHours: 0,
                absenceCount: 0,
                unjustifiedAbsenceCount: 0,
                absenceRate: 0
            } as Stat;
            yearMap.set(year, agg);
        }
        agg.totalHours += e.totalHours;
        agg.absenceHours += e.absenceHours;
        agg.absenceCount += e.absenceCount;
        agg.unjustifiedAbsenceCount += e.unjustifiedAbsenceCount;
    });

    // déterminer les libellés finaux des agrégats
    yearMap.forEach((e, year) => {
        e.label = yearHalfGroupNames.get(year) || `B.U.T. ${year}`;
    });

    yearMap.forEach(e => {
        e.absenceRate = e.totalHours > 0 ? Math.round((e.absenceHours / e.totalHours) * 10000) / 100 : 0;
    });

    const results: Stat[] = [...semesterMap.values(), ...yearMap.values()];

    console.log("absencesResults : " + JSON.stringify(results));
    return results;
}