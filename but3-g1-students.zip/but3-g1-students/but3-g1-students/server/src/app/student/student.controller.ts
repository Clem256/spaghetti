import { NextFunction, Request, Response, Router } from 'express';
import {
    getAllStudents,
    getEvaluationPeriodResultsById,
    getCompetenciesResultsById,
    getAbsencesResultsById
} from './student.service';

const router = Router();

/**
 * Get students
 * @route {GET} /students
 * @returns students: list of students
 * @returns studentsCount: number of students
 */
router.get('/students', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const result = await getAllStudents();
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * Get evaluation period results by student ID
 * @route {GET} /students/:id/evaluation-period-results
 * @param {number} id - Student ID
 * @returns evaluationPeriodDetails: evaluation period details with teaching units and modules
 */
router.get('/students/:id/evaluation-period-results', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const studentId = parseInt(req.params.id);
    const result = await getEvaluationPeriodResultsById(studentId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * Get competencies results by student ID
 * @route {GET} /students/:id/competencies-results
 * @param {number} id - Student ID
 * @param {string} semester - Semester (optional)
 * @returns competenciesResults: competency results for each semester and aggregate
 */
router.get('/students/:id/competencies-results', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const studentId = parseInt(req.params.id);
    const semester = req.query.semester as string | undefined;
    const result = await getCompetenciesResultsById(studentId, semester);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * Get absences results by student ID
 * @route {GET} /students/:id/absences-results
 * @param {number} id - Student ID
 * @param {string} semester - Semester (optional)
 * @returns absencesResults: absences results for each semester and aggregate
 */
router.get('/students/:id/absences-results', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const studentId = parseInt(req.params.id);
    const semester = req.query.semester as string | undefined;
    const result = await getAbsencesResultsById(studentId, semester);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

export default router;