import { Student, User } from "../../../../db/generated/client";

export type StudentWithUser = Student & { user: User };
