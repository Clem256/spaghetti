import { Student } from "../../../db/generated/client";
import userMapper from "../user/user.mapper";

export const studentMapper = (student: Student & { user?: any }) => ({
  id: student.id,
  user_id: student.user_id,
  high_school: student.high_school ?? null,
  diploma: student.diploma ?? null,
  is_representative: student.is_representative ?? false,
  user: student.user ? userMapper(student.user) : undefined,
  student_code: student.student_code,
});