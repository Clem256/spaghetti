import { NextFunction, Request, Response, Router } from 'express';
import {
  getOptionsByQuestionId,
} from './option.service';

const router = Router();

/**
 * Get options by question id
 * @route {GET} /survey/question/options/:id
 * @param id id of the question
 * @returns list of options
 */
router.get(
  '/survey/question/options/:id',
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await getOptionsByQuestionId(+req.params.id);
      res.json(result);
    } catch (error) {
      next(error);
    }
  },
);

export default router;
