import prisma from '../../client';
import HttpException from '../http_exception/http-exception.model';
import { Option, Question, Survey } from "../../../db/generated/client";
import { optionMapper } from './option.mapper';

export const getOptionsByQuestionId = async (id: number) => {
  const existingOptions = await prisma.option.findMany({
    where: {
      question:{
          id:id
      }
    }
  });

  if (!existingOptions) {
    throw new HttpException(404, {});
  }

  return existingOptions.map((option: Option) => optionMapper(option));
};
