import { Option, Question, Survey } from "../../../db/generated/client";

export const optionMapper = (option: Option, id?: number) => ({
  id: option.id,
  label: option.label,
  createdAt: option.created_at,
  updatedAt: option.updated_at,
});