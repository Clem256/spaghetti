export const GITLAB_CONFIG = {
  baseUrl: 'https://forge.univ-lyon1.fr',
  clientId: process.env.GITLAB_APPLICATION_ID!,
  clientSecret: process.env.GITLAB_SECRET!,
  redirectUri: `${process.env.API_URL}/auth/gitlab/callback`,
} as const;
