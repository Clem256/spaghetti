import 'dotenv/config'
import { Prisma, PrismaClient } from '../db/generated/client'
import { PrismaPg } from '@prisma/adapter-pg'

import dotenv from "dotenv";
dotenv.config({ path: "../.env" });
console.log("DATABASE_URL =", process.env.DATABASE_URL);

console.log('CLIENT_ID', process.env.GITLAB_APPLICATION_ID);
console.log('CLIENT_SECRET defined ?', !!process.env.GITLAB_SECRET);

const pool = new PrismaPg({ connectionString: process.env.DATABASE_URL! })
const prisma = new PrismaClient({ adapter: pool })

export default prisma