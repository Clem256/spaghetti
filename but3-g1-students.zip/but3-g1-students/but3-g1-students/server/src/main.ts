import "dotenv/config";
import express from "express";
import routes from "./app/routes";
import cors from "cors";
import axios from "axios";
import authController from "./app/auth/auth.controller";

const app = express();

app.use(
    cors({
        origin: (origin, callback) => {
            if (!origin || origin.startsWith("http://localhost:4200")) {
                callback(null, true);
            } else {
                callback(new Error("Not allowed by CORS"));
            }
        },
        credentials: true,
    }),
);

app.use(express.json());

app.get("/", (req: express.Request, res: express.Response) => {
    res.json({ status: "API is running on /api" });
});

app.use(authController);

app.use(routes);

app.use(
    (
        err: any,
        req: express.Request,
        res: express.Response,
        next: express.NextFunction,
    ) => {
        const status = err.status || 500;
        const message = err.message || "Internal server error";

        console.error("Error:", {
            status,
            message,
            stack: err.stack,
            path: req.path,
            method: req.method,
        });

        res.status(status).json({
            error: message,
            ...(err.body || {}),
        });
    },
);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.info(`server up on port ${PORT}`);
});
