import { Request, Response, NextFunction } from 'express';
import { verifyToken, getUserByIdForAuth } from '../app/auth/auth.service';
import HttpException from '../app/http_exception/http-exception.model';

export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new HttpException(401, { message: 'No token provided' });
    }

    const token = authHeader.substring(7);
    const { userId } = verifyToken(token);

    const user = await getUserByIdForAuth(userId);

    req.user = user;

    next();
  } catch (error) {
    next(error);
  }
};