import { prismaMock } from '../mockito-prisma';
import { createUser, deleteUser, updateUser } from '../../app/user/user.service';
import HttpException from '../../app/http_exception/http-exception.model';

describe('UserService', () => {
  describe('createUser', () => {
    test('should create an user', async () => {
      // Given
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      const prismaResponse = {
        id: 1,
        ...userInput,
        updatedAt: new Date(),
        createdAt: new Date(),
      };

      prismaMock.user.findUnique.mockResolvedValue(null);
      // @ts-ignore
      prismaMock.user.create.mockResolvedValue(prismaResponse);

      // When
      await createUser(userInput);

      // Then
      expect(prismaMock.user.findUnique).toHaveBeenCalledWith({
        where: { personal_email: userInput.personal_email },
      });

      expect(prismaMock.user.create).toHaveBeenCalledWith({
        data: userInput,
      });
    });

    test('should throw 422 error because first_name is missing', async () => {
      const userInput = {
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      // pas nécessaire vu que comme la db est down on ne trouvera aucun email dans tous les cas
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);
      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

    });

    test('should throw 422 error because last_name is missing', async () => {
      const userInput = {
        first_name: 'gaston',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      // pas nécessaire vu que comme la db est down on ne trouvera aucun email dans tous les cas
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);
      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

    });

    test('should throw 422 error because personnal_email is missing', async () => {
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      // pas nécessaire vu que comme la db est down on ne trouvera aucun email dans tous les cas
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);
      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

    });

    test('should throw 422 error because school_email is missing', async () => {
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        password: '1234',
        type: 'Student',
      };

      // pas nécessaire vu que comme la db est down on ne trouvera aucun email dans tous les cas
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);
      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

    });

    test('should throw 422 error because password is missing', async () => {
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        type: 'Student',
      };

      // pas nécessaire vu que comme la db est down on ne trouvera aucun email dans tous les cas
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);
      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

    });
    
    test('should throw 422 error when personal_email already exists', async () => {
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      // on dit que pour ce test lors qu'on fait findUnique, au lieu d'appeler la db, 
      // on renvoie toujours un objet
      prismaMock.user.findUnique.mockResolvedValue({ id: 1 } as any);

      await expect(createUser(userInput)).rejects.toThrow(HttpException);

      await expect(createUser(userInput)).rejects.toMatchObject({
        errorCode: 422,
      });

      expect(prismaMock.user.create).not.toHaveBeenCalled();
    });
  });

  describe('updateUser', () => {
    test('should throw 404 error when user is not found', async () => {
      const userInput = {
        first_name: 'gaston',
        last_name: 'berger',
        personal_email: 'gaston.berger@gmail.com',
        school_email: 'gaston.berger@etu.univ-lyon1.fr',
        password: '1234',
        type: 'Student',
      };

      // on dit que pour ce test lors qu'on fait findUnique, au lieu d'appeler la db, 
      // on renvoie toujours rien, 
      // on imite le fait de ne pas trouver de user dans la db
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(updateUser(userInput, 1)).rejects.toThrow(HttpException);

      await expect(updateUser(userInput, 1)).rejects.toMatchObject({
        errorCode: 404,
      });

      expect(prismaMock.user.update).not.toHaveBeenCalled();
    });
  });

  describe('deleteUser', () => {
    test('should throw 404 error when user is not found', async () => {
      // on dit que pour ce test lors qu'on fait findUnique, au lieu d'appeler la db, 
      // on renvoie toujours rien, 
      // on imite le fait de ne pas trouver de user dans la db
      prismaMock.user.findUnique.mockResolvedValue(null);

      await expect(deleteUser(1)).rejects.toThrow(HttpException);

      await expect(deleteUser(1)).rejects.toMatchObject({
        errorCode: 404,
      });

      expect(prismaMock.user.delete).not.toHaveBeenCalled();
    });
  });


});