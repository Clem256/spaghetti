import { User } from "../../db/generated/client";

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

export {};
