import { defineConfig, env } from 'prisma/config'
import 'dotenv/config'
import dotenv from 'dotenv'


dotenv.config({ path: '../.env' })

export default defineConfig({
    schema: 'db/schema.prisma',
    migrations: {
        path: 'db/migrations',
        seed: 'tsx db/seed.ts',
    },
    datasource: {
        url: env('DATABASE_URL'),
    },
})

