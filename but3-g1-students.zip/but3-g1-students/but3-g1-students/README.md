# Sommaire #

- [I. Présentation du projet](#i-présentation-du-projet)
  - [I.A. Contexte](#ia-contexte)
  - [I.B. Objectifs du projet](#ib-objectifs-du-projet)
  - [I.C. Acteurs du projet](#ic-acteurs-du-projet)
  - [I.D. Contraintes de réalisation](#id-contraintes-de-réalisation)
- [II. Technologies utilisées](#ii-technologies-utilisées)
- [III. Cahier des règles](#iii-cahier-des-règles)
  - [III.A. Règles de nommage](#iiia-règles-de-nommage)
  - [III.B. Nommage des fonctions](#iiib-nommage-des-fonctions)
  - [III.C. Nommage des commits](#iiic-nommage-des-commits)
  - [III.D. Règles d'écriture](#iiid-règles-décriture)
- [IV. Mise en place du projet](#iv-mise-en-place-du-projet)
  - [IV.A. Prérequis](#iva-prérequis)
  - [IV.B. Cloner le dépôt](#ivb-cloner-le-dépôt)
  - [IV.C. Configurer l'environnement](#ivc-configurer-lenvironnement)
  - [IV.D. Lancer la base de données](#ivd-lancer-la-base-de-données)
  - [IV.E. Initialiser le Backend](#ive-initialiser-le-backend)
  - [IV.F. Initialiser le Frontend](#ivf-initialiser-le-frontend)




# I. Présentation du projet #

## I.A. Contexte ##

Dans le cadre de la S.A.E. du parcours R.A. (réalisation d'applications) en troisième année de B.U.T. informatique, il a été demandé aux étudiants de réaliser un projet pour le département informatique de l’I.U.T. afin de simplifier, centraliser et automatiser la gestion de diverses tâches liées à la vie du département. Il s’agit du projet NEXUS Portal.

Ce projet d’envergure comporte plusieurs modules devant permettre la gestion des absences, de l’emploi du temps, des ressources, le suivi de projets, le suivi des étudiants et alumnis, la gestion des stages/alternances ainsi que le lien avec les entreprises.

Ces modules sont répartis en plusieurs équipes de réalisation, et devront à terme pouvoir communiquer entre eux pour permettre l’échange d’informations et les interactions inter modules, le tout afin de maximiser l’efficacité via cette application centralisée.

Dans ce contexte, notre groupe est chargé de la réalisation du module de suivi du cursus étudiant.

## I.B. Objectifs du projet ##

L’objectif principal de ce projet est de concevoir une application Web centralisée permettant le suivi longitudinal des étudiants, depuis leur arrivée à l’I.U.T., tout au long du B.U.T. et après leur sortie.

L’application doit permettre de centraliser les informations académiques, administratives et professionnelles des étudiants, offrir une vue globale et historique du parcours de chaque étudiant, permettre un suivi individuel, automatiser les campagnes de recueil d’informations, fournir des outils d’aide à la décision pour les responsables et directions, faciliter le lien avec les entreprises et les autres applications, et intégrer le suivi Alumni après le B.U.T. Elle doit également permettre, pour un administrateur, la gestion des utilisateurs : création/suppression de profils, assignation de rôles ainsi que leur paramétrage, et toute autre action nécessaire à la bonne administration de l’application.

L’application doit finalement permettre aux utilisateurs de gagner en temps et en efficacité en réalisant les actions liées au suivi du cursus, en les automatisant et centralisant toutes au même endroit.

## I.C. Acteurs du projet ##

Les acteurs de notre projet sont les suivants :

**Équipe de réalisation :**
- Mayssa LAKHAL
- Tanguy ABDOULVAID
- Arthur FOUREL

**Tuteurs du projet :**
- Adrien PEYTAVIE
- Samba Ndojh NDIAYE

**Utilisateurs finaux :**
- Etudiants et anciens étudiants du département informatique
- Enseignants
- Responsables pédagogiques
- Secrétariat pédagogique
- Direction d’études
- Direction de l’I.U.T.
- Administrateurs

## I.D. Contraintes de réalisation ##

Pour la réalisation de ce projet, l’équipe devra prendre en compte plusieurs contraintes importantes :

- **Respect des délais :** le projet devra être entièrement fonctionnel et prêt pour une mise en production prévue début avril 2026.
- **Normes de conception :** le style de l’application sera défini en utilisant Tailwind CSS, afin de garantir une interface moderne et cohérente avec les autres applications.
- **Travail collaboratif :** les membres de l’équipe travailleront sur leurs postes personnels. Il sera donc essentiel de veiller à la compatibilité entre les différents environnements de développement et systèmes d’exploitation.
- **Accessibilité et déploiement :** l’application finale devra être hébergée sur un serveur afin d’être accessible aux utilisateurs finaux.

# II. Technologies utilisées #

**Technologies Web :**
- HTML
- CSS
- JavaScript
- Typescript
- Angular
- Node.js
- Express.js

**Gestion de la base de données :**
- SQL
- PostgreSQL
- pgAdmin4
- Prisma

**Conception et développement :**
- Visual Paradigm
- Figma
- Visual Studio Code

**Gestion de projet :**
- Discord
- Git
- GitLab
- Google Drive

# III. Cahier des règles #

> L'ensemble du code sera écrit en Anglais.

## III.A. Règles de nommage ##

Les classes, les fonctions et les variables ne contiendront pas d'accents.

Les caractères autorisés seront les lettres, les chiffres et les tirets.

**Nommage des classes :**
- Lettres minuscules avec majuscules en début de mots
- Style PascalCase
- Nom significatif

**Nommage des variables :**
- Lettres minuscules avec majuscules en début de mots
- Style camelCase

**Nommages des constantes :**
- Lettres capitales et tiret bas uniquement

## III.B. Nommage des fonctions ##

**Règles générales :**
- Lettres minuscules avec majuscules en début de mots
- Style camelCase
- Verbes ou groupes verbaux à l'infinitif
- Getters et setters nommés d'après leur valeur, préfixés par `get` ou `set`

## III.C. Nommage des commits ##
> Tous les caractères sont autorisés
 
**Format des messages :** \<type\>\[(portée)\]: \<description\>

**Type du commit :**
- **feat :** Ajout d'une nouvelle fonctionnalité
- **fix :** Correction d'un bug
- **perf :** Amélioration des performances
- **refactor :** Modification qui n’apporte ni nouvelle fonctionalité ni amélioration de performances
- **doc :** Rédaction ou mise à jour de documentation
- **test :** Ajout ou modification de test(s)
- **style :** Modification du style du code (à ne pas confondre avec le style CSS)
- **chore :** Tâche sans impact direct sur le code fonctionnel, comme la mise à jour des dépendances

**Portée du commit (facultatif) :** Indique quelle partie du projet est affectée

**Description du commit :** Description des changements effectués

## III.D. Règles d'écriture ##

**Généralités :**
- Les espaces suivent la syntaxe anglo-saxonne et non française. Ainsi les caractères `;`, `:` et `,` s'écrivent avec un espace après mais pas d'espace avant.
- Toujours entourer d'un espace avant et d'un espace après les opérateurs suivants `+`, `-`, `*`, `/`, `=`, `+=`, `-=`, `*=`, `/=`, `==`, `!=`, `>=`, `not`, `in`, `and`, `or`.

**Fonctions :**
- Idéalement moins de 20 lignes
- Au maximum 100 lignes
- Idéalement 3 paramètres au maximum

# IV. Mise en place du projet

## IV.A. Prérequis

Avant de commencer, vous devez vous assurer que les outils suivants sont bien installés sur votre machine :
- **Docker :** Guide d'installation sur https://docs.docker.com/get-started/get-docker/
- **Docker Compose :** Guide d'installation sur https://docs.docker.com/compose/install/

**Vérifications :**
```bash
docker -v
docker compose version
```
Si chaque commande retourne une version, votre environnement est prêt pour le développement.

## IV.B. Cloner le dépôt

Depuis un terminal de commande, clonez le dépôt du projet sur votre machine locale.

**Via HTTPS :**
```bash
git clone https://forge.univ-lyon1.fr/p2513320/sae_cursus_etudiant.git
```
**Via SSH :**
```bash
git clone git@forge.univ-lyon1.fr:p2513320/sae_cursus_etudiant.git
```

Une fois le dépôt cloné, accédez au répertoire du projet :
```bash
cd sae_cursus_etudiant
```

## IV.C. Configurer l'environnement

Créez un fichier `environment.develop.ts` dans client/src/environments avec le contenu suivant :
```dotenv
export const environment = {
    production: false,
    apiUrl: 'http://localhost:3000/api'
};
```

Créez un fichier `.env`à la racine du projet avec le contenu suivant :
```dotenv
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
DATABASE_URL="postgresql://postgres:postgres@database:5432/suivi_etudiant"

GITLAB_APPLICATION_ID="votre_gitlab_application_id"
GITLAB_SECRET="votre_gitlab_secret"

JWT_SECRET="votre_jwt_secret"
JWT_EXPIRES_IN=7d

FRONTEND_URL="http://localhost:4200"
API_URL="http://localhost:3000"
```

Pour remplacer les valeurs factices ("votre_xxx"), veuillez suivre la procédure suivante :

### Credentials GitLab
* Depuis votre compte GitLab, se rendre sur la page **Préférences** (paramètres)
* Se rendre dans l'onglet **Applications** et cliquer sur **Add new application**
* Entrer un **nom** et une **redirect URI**. Par exemple, *Nexus Portal* et `http://localhost:3000/auth/gitlab/callback`
* Décocher la case *Confidential*
* Cocher les scopes `read_user`, `profile` et `email`
* Cliquer sur **Save application**
* Accéder aux credentials et les stocker respectivement dans les variables `GITLAB_APPLICATION_ID` et `GITLAB_SECRET` de votre `.env`

### Variables JWT
* `JWT_SECRET` : Générer une chaîne de chiffres et lettres miniscules d'au moins 32 caractères manuellement ou via un générateur de mot de passe
* `JWT_EXPIRES_IN`: dans notre cas, `7d`

## IV.D. Lancer le projet

Depuis la racine du projet, exécutez la commande suivante :
```bash
docker compose up --build
```

la bd tourne sur localhost:55432
le back tourne sur localhost:3000
le front tourne sur localhost:4200

## IV.E. Seed la bd

Toujours depuis la racine du projet, exécutez les commandes suivantes :
```bash
# générer prisma
docker compose exec server npx prisma generate

# appliquer les migrations à la bdd
docker compose exec server npx prisma migrate dev

# appliquer la seed avec les données de base
docker compose exec server npx prisma db seed
```

vous pouvez maintenant vous connecter en tant que willy,
identifiant : w
mot de passe : password
