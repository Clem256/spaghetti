import { ApplicationConfig, importProvidersFrom, LOCALE_ID, provideBrowserGlobalErrorListeners, provideZonelessChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';

import { routes } from './app.routes';
import { House, File, LucideAngularModule, LogOut, Menu, ChevronDown, ChevronRight, NotebookPen, Pencil, CircleAlert, Settings, Bell, Briefcase, ScrollText, TriangleAlert, Eye, Workflow, UserRoundX, Cog, AlarmClockOff, ExternalLink, Gitlab, BriefcaseBusiness, UserRound, GraduationCap, Reply, Search, Plus, CopyCheck, CircleCheck, PenLine  } from 'lucide-angular';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './core/interceptors/auth.interceptor';

registerLocaleData(localeFr);

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZonelessChangeDetection(),
    provideRouter(routes),
    provideHttpClient(
      withInterceptors([authInterceptor])
    ),
    { provide: LOCALE_ID, useValue: 'fr-FR' },
    importProvidersFrom(LucideAngularModule.pick({House, LogOut, Menu, File, ChevronDown, ChevronRight, NotebookPen, Pencil, CircleAlert, Settings, Bell, Briefcase, ScrollText, TriangleAlert, Eye, Workflow, Cog, AlarmClockOff, ExternalLink, Gitlab, BriefcaseBusiness, UserRound, GraduationCap, Reply, Search, Plus, CopyCheck, CircleCheck, PenLine }))
  ]
};
