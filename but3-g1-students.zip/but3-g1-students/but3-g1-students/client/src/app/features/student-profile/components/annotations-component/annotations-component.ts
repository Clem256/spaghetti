import { Component, effect, inject, input } from '@angular/core';
import { AsyncPipe, DatePipe } from '@angular/common';
import { LucideAngularModule } from "lucide-angular";
import { AnnotationService } from '../../../../core/services/annotation/annotation-service';
import { Observable } from 'rxjs';
import { AnnotationModel } from '../../../../models/annotation-model';
import { AnnotationItem } from "../annotation-item/annotation-item";

@Component({
  selector: 'app-annotations-component',
  imports: [LucideAngularModule, AsyncPipe, AnnotationItem],
  templateUrl: './annotations-component.html',
  styleUrl: './annotations-component.css',
})
export class AnnotationsComponent {

  userId = input<number | null>(null);
  studentCode = input.required<string>();

  private readonly annotationService = inject(AnnotationService);
  annotations$: Observable<AnnotationModel[]> | undefined;

  constructor() {
      effect(() => {
        this.annotations$ = this.annotationService.getAnnotationsByStudentCode(this.studentCode());
      });
  }


}
