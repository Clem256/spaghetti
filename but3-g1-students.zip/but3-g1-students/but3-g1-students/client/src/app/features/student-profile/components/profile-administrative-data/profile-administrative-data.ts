import { Component, effect, input, signal } from '@angular/core';
import { LucideAngularModule } from "lucide-angular";
import { TitleCasePipe } from '@angular/common';
import { UserModel } from '../../../../models/user-model';

@Component({
  selector: 'app-profile-administrative-data',
  imports: [LucideAngularModule, TitleCasePipe],
  templateUrl: './profile-administrative-data.html',
  styleUrl: './profile-administrative-data.css',
})
export class ProfileAdministrativeData {

  user = input<UserModel | null>(null);

  firstName = signal('');
  lastName = signal('');
  schoolEmail = signal('');
  alumniEmail = signal('');
  studentCode = signal('');
  avatarUrl = signal('');

  constructor() {
    effect(() => {
      const u = this.user();
      console.log(u)
      this.firstName.set(u?.first_name || '');
      this.lastName.set(u?.last_name || '');
      this.schoolEmail.set(u?.school_email || '');
      this.alumniEmail.set(u && 'alumniEmail' in u ? (u as any).alumniEmail : '');
      this.studentCode.set(u?.username || '');
      this.avatarUrl.set(u?.avatar_url || '');
    });
  }
}
