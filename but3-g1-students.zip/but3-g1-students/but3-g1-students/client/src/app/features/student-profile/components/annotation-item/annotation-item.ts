import { Component, computed, input } from '@angular/core';
import { COLOR_MAP } from '../../../../shared/utils/color-map';
import { AnnotationModel } from '../../../../models/annotation-model';

@Component({
  selector: 'app-annotation-item',
  imports: [],
  templateUrl: './annotation-item.html',
})
export class AnnotationItem {
  color: string = '';
  annotation = input.required<AnnotationModel>();
  colors = ['red', 'orange', 'green', 'blue', 'purple', 'yellow'];

  constructor() {
    this.color = this.colors[Math.floor(Math.random() * this.colors.length)];
  }

  readonly textColor = computed(
    () => COLOR_MAP[this.color]?.text ?? 'text-black'
  );

  readonly backgroundColor = computed(
    () => COLOR_MAP[this.color]?.bg ?? 'bg-white'
  );

  readonly borderColor = computed(
    () => COLOR_MAP[this.color]?.border ?? 'border-black'
  );
}
