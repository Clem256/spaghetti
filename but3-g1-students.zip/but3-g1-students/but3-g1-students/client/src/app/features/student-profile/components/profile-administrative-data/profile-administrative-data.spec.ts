import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileAdministrativeData } from './profile-administrative-data';

describe('ProfileAdministrativeData', () => {
  let component: ProfileAdministrativeData;
  let fixture: ComponentFixture<ProfileAdministrativeData>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProfileAdministrativeData]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfileAdministrativeData);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
