import { Component, effect, inject, input, signal } from '@angular/core';
import { ProfileAdministrativeData } from "../components/profile-administrative-data/profile-administrative-data";
import { LucideAngularModule } from "lucide-angular";
import { AnnotationsComponent } from "../components/annotations-component/annotations-component";
import { AuthService } from '../../../core/auth-service';
import { TitleCasePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { UserModel } from '../../../models/user-model';
import { UserService } from '../../../core/services/user/user-service';
import { ClassService } from '../../../core/services/class-service';
import { ClassModel } from '../../../models/class-model';

@Component({
  selector: 'app-student-profile',
  imports: [ProfileAdministrativeData, LucideAngularModule, AnnotationsComponent, TitleCasePipe],
  templateUrl: './student-profile.html',
  styleUrl: './student-profile.css',
})
export class StudentProfile {
  private router = inject(Router);
  private activatedRoute = inject(ActivatedRoute);

  private readonly authService = inject(AuthService);
  private readonly userService = inject(UserService);
  private readonly classService = inject(ClassService);

  user = signal<UserModel | null>(null)
  userId = signal<number>(0);
  firstName = signal('');
  lastName = signal('');
  avatarUrl = signal('');
  studentCode = signal('');
  studentClass = signal<ClassModel | null>(null);

  constructor() {
    this.activatedRoute.paramMap.subscribe(params => {
      const id = +params.get('id')!;
      this.userId.set(id);

      this.userService.getUserById(id).subscribe(user => this.user.set(user) );
      this.classService.GetClassByStudentId(id).subscribe(studentClass => this.studentClass.set(studentClass));
    });

    effect(() => {
      console.log(this.user())
      this.firstName.set(this.user()?.first_name!);
      this.lastName.set(this.user()?.last_name!);
      this.avatarUrl.set(this.user()?.avatar_url!);
      this.studentCode.set(this.user()?.student?.student_code!);
      this.studentClass.set(this.studentClass());
    });
  }

}
