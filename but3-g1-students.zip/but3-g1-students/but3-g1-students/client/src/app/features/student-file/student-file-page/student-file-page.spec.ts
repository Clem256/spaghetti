import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentFilePage } from './student-file-page';

describe('StudentFilePage', () => {
  let component: StudentFilePage;
  let fixture: ComponentFixture<StudentFilePage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentFilePage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentFilePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
