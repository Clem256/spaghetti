import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Internships } from '../internships/internships';
import { Apprenticeships } from '../apprenticeships/apprenticeships';
import { Projects } from '../projects/projects';
import { Jobs } from '../jobs/jobs';

@Component({
  selector: 'app-professional-background',
  imports: [LucideAngularModule, CommonModule, Internships, Apprenticeships, Projects, Jobs],
  templateUrl: './professional-background.html',
  styleUrl: './professional-background.css',
})
export class ProfessionalBackground {
  isCollapsed = false;

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
