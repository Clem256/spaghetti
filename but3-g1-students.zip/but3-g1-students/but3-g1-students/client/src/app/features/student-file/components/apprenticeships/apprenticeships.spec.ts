import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Apprenticeships } from './apprenticeships';

describe('Apprenticeships', () => {
  let component: Apprenticeships;
  let fixture: ComponentFixture<Apprenticeships>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Apprenticeships]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Apprenticeships);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
