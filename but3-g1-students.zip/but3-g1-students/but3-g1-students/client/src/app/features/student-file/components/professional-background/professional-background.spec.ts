import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessionalBackground } from './professional-background';

describe('ProfessionalBackground', () => {
  let component: ProfessionalBackground;
  let fixture: ComponentFixture<ProfessionalBackground>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProfessionalBackground]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfessionalBackground);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
