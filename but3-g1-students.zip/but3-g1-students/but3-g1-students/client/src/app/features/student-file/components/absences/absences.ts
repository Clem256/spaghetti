import { Component, inject } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { map, Observable, of, tap } from 'rxjs';
import { AbsenceStatsModel } from '../../../../models/absence-stats-model';
import { CommonModule } from '@angular/common';
import { EvaluationPeriodAbsences } from '../evaluation-period-absences/evaluation-period-absences';
import { AuthService } from '../../../../core/auth-service';
import { StudentService } from '../../../../core/services/student/student-service';

@Component({
  selector: 'app-absences',
  imports: [LucideAngularModule, CommonModule, EvaluationPeriodAbsences],
  templateUrl: './absences.html',
  styleUrl: './absences.css',
})
export class Absences {
  isCollapsed = false;

  private readonly authService = inject(AuthService);
  private readonly studentService = inject(StudentService);

  userId: number | undefined = this.authService.getCurrentUser()?.id;
  absenceStats$!: Observable<AbsenceStatsModel[]>;
  // results: AbsenceStatsModel[][] = [];
  results$!: Observable<AbsenceStatsModel[][]>;

  ngOnInit(): void {

    this.absenceStats$ = this.studentService.getAbsencesResultsById(this.userId).pipe(
      map(stats =>
        [...stats].sort((a, b) => {
          if (a.year != b.year) {
            return b.year - a.year;
          }

          if (a.type != b.type) {
            return a.type == 'AGGREGATE' ? -1 : 1;
          }

          if (a.type == 'SEMESTER' && b.type == 'SEMESTER') {
            return (b.semester ?? 0) - (a.semester ?? 0);
          }

          return 0;
        })
      )
    );

    // this.absenceStats$ = of<AbsenceStatsModel[]>([
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 1',
    //     year: 1,
    //     semester: 1,
    //     totalHours: 298,
    //     absenceHours: 8,
    //     absenceCount: 4,
    //     unjustifiedAbsenceCount: 2,
    //     absenceRate: 2.68
    //   },
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 2',
    //     year: 1,
    //     semester: 2,
    //     totalHours: 297,
    //     absenceHours: 18,
    //     absenceCount: 9,
    //     unjustifiedAbsenceCount: 4,
    //     absenceRate: 6.06
    //   },
    //   {
    //     type: 'AGGREGATE',
    //     label: 'B.U.T. 1',
    //     year: 1,
    //     totalHours: 595,
    //     absenceHours: 26,
    //     absenceCount: 13,
    //     unjustifiedAbsenceCount: 6,
    //     absenceRate: 4.37
    //   },
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 3',
    //     year: 2,
    //     semester: 3,
    //     totalHours: 298,
    //     absenceHours: 8,
    //     absenceCount: 4,
    //     unjustifiedAbsenceCount: 2,
    //     absenceRate: 2.68
    //   },
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 4',
    //     year: 2,
    //     semester: 4,
    //     totalHours: 297,
    //     absenceHours: 18,
    //     absenceCount: 9,
    //     unjustifiedAbsenceCount: 4,
    //     absenceRate: 6.06
    //   },
    //   {
    //     type: 'AGGREGATE',
    //     label: 'B.U.T. 2 R.A.',
    //     year: 2,
    //     totalHours: 595,
    //     absenceHours: 26,
    //     absenceCount: 13,
    //     unjustifiedAbsenceCount: 6,
    //     absenceRate: 4.37
    //   },
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 5',
    //     year: 3,
    //     semester: 5,
    //     totalHours: 298,
    //     absenceHours: 8,
    //     absenceCount: 4,
    //     unjustifiedAbsenceCount: 2,
    //     absenceRate: 2.68
    //   },
    //   {
    //     type: 'SEMESTER',
    //     label: 'Semestre 6',
    //     year: 3,
    //     semester: 6,
    //     totalHours: 297,
    //     absenceHours: 18,
    //     absenceCount: 9,
    //     unjustifiedAbsenceCount: 4,
    //     absenceRate: 6.06
    //   },
    //   {
    //     type: 'AGGREGATE',
    //     label: 'B.U.T. 3 R.A.',
    //     year: 3,
    //     totalHours: 595,
    //     absenceHours: 26,
    //     absenceCount: 13,
    //     unjustifiedAbsenceCount: 6,
    //     absenceRate: 4.37
    //   }
    // ]).pipe(
    //   map(stats =>
    //     [...stats].sort((a, b) => {
    //       if (a.year != b.year) {
    //         return b.year - a.year;
    //       }

    //       if (a.type != b.type) {
    //         return a.type == 'AGGREGATE' ? -1 : 1;
    //       }

    //       if (a.type == 'SEMESTER' && b.type == 'SEMESTER') {
    //         return (b.semester ?? 0) - (a.semester ?? 0);
    //       }

    //       return 0;
    //     })
    //   )
    // );

    // this.absenceStats$.subscribe(stats => {
    //   stats.forEach(c => {
    //     console.log('Absence stats received :', c);
    //     if (c.type == 'AGGREGATE') {
    //       var tmp: AbsenceStatsModel[] = [];
    //       tmp.push(c);
    //       stats.forEach(s => {
    //         if (s.type == 'SEMESTER' && s.year == c.year) {
    //           tmp.push(s);
    //         }
    //       });
    //       this.results.push(tmp);
    //     }
    //   });
    // });

    this.results$ = this.absenceStats$.pipe(
      map(results => {
        const groupedResults: AbsenceStatsModel[][] = [];

        results.forEach(c => {
          if (c.type === 'AGGREGATE') {
            const tmp: AbsenceStatsModel[] = [c];
            results.forEach(s => {
              if (s.type === 'SEMESTER' && s.year === c.year) {
                tmp.push(s);
              }
            });

            groupedResults.push(tmp);
          }
        });

        return groupedResults;
      })
    );
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  unjustifiedAbsenceCountColor(label: string, count: number): string {
    if (label.startsWith('Semestre')) {
      if (count >= 5) return 'bg-light-red text-red';
      if (count >= 3 && count < 5) return 'bg-light-orange text-orange';
      return 'bg-light-green text-green';
    } else {
      return 'bg-border-grey text-grey';
    }
  }

  absenceRateColor(label: string, rate: number): string {
    if (!label.startsWith('Semestre')) {
      if (rate >= 10) return 'bg-light-red text-red';
      if (rate >= 5 && rate < 10) return 'bg-light-orange text-orange';
      return 'bg-light-green text-green';
    } else {
      return 'bg-light-grey text-grey';
    }
  }
}
