import { Component, effect, Input } from '@angular/core';
import { CompetencyResultsModel } from '../../../../models/competency-results-model';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';
import { CompetencyModel } from '../../../../models/competency-model';

@Component({
  selector: 'app-evaluation-period-competencies',
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './evaluation-period-competencies.html',
  styleUrl: './evaluation-period-competencies.css',
})
export class EvaluationPeriodCompetencies {
  isCollapsed = false;
  @Input() period: CompetencyResultsModel[] = [];
  @Input() competencies: CompetencyModel[] | null = [];
  @Input() nbCompetencies: number = 0;

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  lineTextStyle(type: string): string {
    if (type === 'AGGREGATE') {
      return 'border-b border-border-grey font-bold text-black';
    } else {
      return 'border-b border-border-grey'; 
    }
  }

  cellStyle(type: 'SEMESTER' | 'AGGREGATE'): string {
    if (type === 'SEMESTER') {
      return 'p-4 border-l border-r border-border-grey';
    } else {
      return 'border-l border-r border-border-grey';
    }
  }

  valueStyle(type: 'SEMESTER' | 'AGGREGATE', value: number | null): string {
    if (type === 'AGGREGATE') {
      if (value !== null && value >= 10) {
        return 'p-4 border-l border-r border-border-grey bg-light-green text-green';
      } else if (value !== null && value >= 8) {
        return 'p-4 border-l border-r border-border-grey bg-light-orange text-orange';
      } else if (value !== null && value < 8) {
        return 'p-4 border-l border-r border-border-grey bg-light-red text-red';
      } else {
        return 'p-4 border-l border-r border-border-grey bg-border-grey text-grey';
      }
    } else {
      if (value !== null && value >= 10) {
        return 'inline-block px-2 rounded-2xl bg-light-green text-green';
      } else if (value !== null && value >= 8) {
        return 'inline-block px-2 rounded-2xl bg-light-orange text-orange';
      } else if (value !== null && value < 8) {
        return 'inline-block px-2 rounded-2xl bg-light-red text-red';
      } else {
        return 'inline-block px-2 rounded-2xl bg-border-grey text-grey';
      }
    }
  }
}
