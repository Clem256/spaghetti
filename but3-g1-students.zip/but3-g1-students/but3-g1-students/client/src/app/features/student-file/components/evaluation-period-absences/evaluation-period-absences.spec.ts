import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationPeriodAbsences } from './evaluation-period-absences';

describe('EvaluationPeriodAbsences', () => {
  let component: EvaluationPeriodAbsences;
  let fixture: ComponentFixture<EvaluationPeriodAbsences>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationPeriodAbsences]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EvaluationPeriodAbsences);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
