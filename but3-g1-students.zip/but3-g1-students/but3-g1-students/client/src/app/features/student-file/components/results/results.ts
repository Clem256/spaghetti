import { Component, inject } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Absences } from '../absences/absences';
import { Competencies } from "../competencies/competencies";
import { map, Observable, of } from 'rxjs';
import { EvaluationPeriodDetailsModel } from '../../../../models/evaluation-period-details-model';
import { EvaluationPeriodResults } from '../evaluation-period-results/evaluation-period-results';
import { CommonModule } from '@angular/common';
import { StudentService } from '../../../../core/services/student/student-service';
import { AuthService } from '../../../../core/auth-service';

@Component({
  selector: 'app-results',
  imports: [LucideAngularModule, CommonModule, EvaluationPeriodResults],
  templateUrl: './results.html',
  styleUrl: './results.css',
})
export class Results {
  private readonly studentService = inject(StudentService);
  private readonly authService = inject(AuthService);

  userId: number | undefined = this.authService.getCurrentUser()?.id;
  isCollapsed = false;
  evaluationPeriodDetails$!: Observable<EvaluationPeriodDetailsModel[]>;

  ngOnInit(): void {
    this.evaluationPeriodDetails$ = this.studentService.getEvaluationPeriodResultsById(this.userId).pipe(
      map(periods => [...periods].sort((a, b) => b.order - a.order))
    );
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
