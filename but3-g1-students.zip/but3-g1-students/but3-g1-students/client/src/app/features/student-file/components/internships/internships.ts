import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Observable, of } from 'rxjs';
import { InternshipApprenticeshipModel } from '../../../../models/internship-apprenticeship-model';

@Component({
  selector: 'app-internships',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './internships.html',
  styleUrl: './internships.css',
})
export class Internships {
  isCollapsed = false;

  internships$!: Observable<InternshipApprenticeshipModel[]>;
  
  ngOnInit(): void {
    this.internships$ = of([
      { 
        company: 'Région Auvergne-Rhône-Alpes',
        academicTutor: 'Adrien PEYTAVIE',
        professionalTutor: 'Bernard LACOSTE',
        startDate: '22/04/2025',
        endDate: '28/06/2025'
      }
    ]);
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
