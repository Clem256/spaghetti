import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationPeriodResults } from './evaluation-period-results';

describe('EvaluationPeriod', () => {
  let component: EvaluationPeriodResults;
  let fixture: ComponentFixture<EvaluationPeriodResults>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationPeriodResults]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EvaluationPeriodResults);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
