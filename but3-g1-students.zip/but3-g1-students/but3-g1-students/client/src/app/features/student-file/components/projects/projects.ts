import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Observable, of } from 'rxjs';
import { ProjectModel } from '../../../../models/project-model';

@Component({
  selector: 'app-projects',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './projects.html',
  styleUrl: './projects.css',
})
export class Projects {
  isCollapsed = false;
  
  projects$!: Observable<ProjectModel[]>;
  
  ngOnInit(): void {
    this.projects$ = of([
      { 
        name: 'SAE Cursus Étudiant',
        role: 'Développeur',
        createdAt: '20/11/2025',
        private: false,
        link: 'https://forge.univ-lyon1.fr/p2513320/sae_cursus_etudiant.git'
      },
      { 
        name: 'E-Portofolio',
        role: 'Propriétaire',
        createdAt: '19/02/2025',
        private: false,
        link: 'https://forge.univ-lyon1.fr/p2302844/portfolio.git'
      }
    ]);
  }

  isPrivateColor(isPrivate: boolean): string {
    if (isPrivate === false) {
      return 'bg-light-green text-green';
    } else {
      return 'bg-border-red text-red'; 
    }
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
