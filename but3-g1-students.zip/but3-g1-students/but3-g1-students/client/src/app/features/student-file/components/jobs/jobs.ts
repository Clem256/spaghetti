import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { map, Observable, of } from 'rxjs';
import { JobModel } from '../../../../models/job-model';

@Component({
  selector: 'app-jobs',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './jobs.html',
  styleUrl: './jobs.css',
})
export class Jobs {
  isCollapsed = false;

  jobs$!: Observable<JobModel[]>;

  ngOnInit(): void {
    this.jobs$ = of<JobModel[]>([
      {
        company: 'Domaine viticole Martin',
        post: 'Ouvrier vitivole saisonnier',
        contract: 'CDD',
        startDate: '22/08/2022',
        endDate: '26/08/2022',
      },
      {
        company: 'Picard Surgelés',
        post: 'Vendeur assistant',
        contract: 'CDD',
        startDate: '16/04/2025',
        endDate: null,
      },
      {
        company: 'Vulcania',
        post: 'Agent polyvalent de production',
        contract: 'CDD',
        startDate: '01/07/2024',
        endDate: '20/08/2024',
      },
    ]).pipe(
      map(results =>
        [...results].sort((a, b) => {
          const dateA = this.formatYear(a.startDate);
          const dateB = this.formatYear(b.startDate);
          if (dateA !== dateB) {
            return dateA - dateB;
          }
          return 0;
        })
      )
    );
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  formatYear(dateStr: string): number {
    console.log(dateStr);
    const [day, month, year] = dateStr.split('/');
    const date: number = parseInt(`${year}${month.padStart(2, '0')}${day.padStart(2, '0')}`);
    console.log(date);
    return date;
  }
}
