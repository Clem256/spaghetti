import { Component, inject } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Observable } from 'rxjs';
import { UserModel } from '../../../../models/user-model';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../core/auth-service';

@Component({
  selector: 'app-administrative-data',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './administrative-data.html',
  styleUrl: './administrative-data.css',
})
export class AdministrativeData {
  private readonly authService = inject(AuthService);
  user$!: Observable<UserModel | null >;
  isCollapsed = false;

  ngOnInit(): void {
    this.user$ = this.authService.currentUser$;
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
