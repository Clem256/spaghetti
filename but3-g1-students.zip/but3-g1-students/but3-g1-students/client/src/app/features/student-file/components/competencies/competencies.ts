import { Component, inject, signal } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { map, Observable, of, tap } from 'rxjs';
import { CommonModule } from '@angular/common';
import { CompetencyResultsModel } from '../../../../models/competency-results-model';
import { CompetencyModel } from '../../../../models/competency-model';
import { EvaluationPeriodCompetencies } from '../evaluation-period-competencies/evaluation-period-competencies';
import { CompetencyService } from '../../../../core/services/competency/competency-service';
import { StudentService } from '../../../../core/services/student/student-service';
import { AuthService } from '../../../../core/auth-service';
import { UserModel } from '../../../../models/user-model';

@Component({
  selector: 'app-competencies',
  imports: [LucideAngularModule, CommonModule, EvaluationPeriodCompetencies],
  templateUrl: './competencies.html',
  styleUrl: './competencies.css',
})
export class Competencies {

  private readonly competencyService = inject(CompetencyService);
  private readonly studentService = inject(StudentService);
  private readonly authService = inject(AuthService);

  userId: number | undefined = this.authService.getCurrentUser()?.id;
  competencies$!: Observable<CompetencyModel[]>;
  competencyResults$!: Observable<CompetencyResultsModel[]>;
  results$!: Observable<CompetencyResultsModel[][]>;
  nbCompetencies = signal<number>(0);
  
  ngOnInit(): void {
    this.competencies$ = this.competencyService.getCompetenciesByStudentId(this.userId);
    this.competencies$.subscribe((competency) => {
      console.log('Competencies received :', competency);
    });

    this.competencyResults$ = this.studentService.getCompetenciesResultsById(this.userId).pipe(
      map(results =>
        [...results].sort((a, b) => {
          if (a.year !== b.year) {
            return b.year - a.year;
          }

          if (a.type !== b.type) {
            return a.type === 'AGGREGATE' ? -1 : 1;
          }

          if (a.type === 'SEMESTER' && b.type === 'SEMESTER') {
            return (b.semester ?? 0) - (a.semester ?? 0);
          }

          return 0;
        })
      ),
      tap(results => this.nbCompetencies.set(results[0]?.values.length ?? 0))
    );

    this.results$ = this.competencyResults$.pipe(
      map(results => {
        const groupedResults: CompetencyResultsModel[][] = [];
        
        results.forEach(c => {
          if (c.type === 'AGGREGATE') {
            const tmp: CompetencyResultsModel[] = [c];
            
            results.forEach(s => {
              if (s.type === 'SEMESTER' && s.year === c.year) {
                tmp.push(s);
              }
            });
            
            groupedResults.push(tmp);
          }
        });
        
        return groupedResults;
      })
    );
  }
}
