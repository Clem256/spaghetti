import { Component } from '@angular/core';
import { AdministrativeData } from '../components/administrative-data/administrative-data';
import { ProfessionalBackground } from '../components/professional-background/professional-background';
import { Absences } from '../components/absences/absences';
import { Competencies } from '../components/competencies/competencies';
import { LucideAngularModule, UserRoundX } from 'lucide-angular';
import { Results } from '../components/results/results';

@Component({
  selector: 'app-student-file-page',
  imports: [LucideAngularModule, AdministrativeData, Results, ProfessionalBackground, Absences, Competencies],
  templateUrl: './student-file-page.html',
  styleUrl: './student-file-page.css',
})
export class StudentFilePage {
  activeTab: 'absences' | 'competencies' | 'results' | 'professional-background' = 'competencies';
}
