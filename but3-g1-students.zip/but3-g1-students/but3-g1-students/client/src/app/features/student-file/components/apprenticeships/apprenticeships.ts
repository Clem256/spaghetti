import { Component } from '@angular/core';
import { Observable, of } from 'rxjs';
import { InternshipApprenticeshipModel } from '../../../../models/internship-apprenticeship-model';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-apprenticeships',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './apprenticeships.html',
  styleUrl: './apprenticeships.css',
})
export class Apprenticeships {
  isCollapsed = false;
  
  apprenticeships$!: Observable<InternshipApprenticeshipModel[]>;
  
  ngOnInit(): void {
    this.apprenticeships$ = of([
      { 
        company: 'HEXATIO',
        academicTutor: 'Isabelle GONCALVES',
        professionalTutor: 'François RIVET',
        startDate: '01/09/2025',
        endDate: '31/08/2026'
      }
    ]);
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }
}
