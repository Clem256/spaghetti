import { Component, input, signal, effect, Input } from '@angular/core';
import { EvaluationPeriodDetailsModel } from '../../../../models/evaluation-period-details-model';
import { LucideAngularModule } from 'lucide-angular';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-evaluation-period-results',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './evaluation-period-results.html',
  styleUrl: './evaluation-period-results.css',
})
export class EvaluationPeriodResults {
  isCollapsed = false;
  @Input() period?: EvaluationPeriodDetailsModel;
  nbTeachingUnits = signal<number>(0);

  constructor() {
    effect(() => {
      const periodData = this.period;
      if (periodData) {
        this.nbTeachingUnits.set(periodData.teachingUnits.length);
      }
    });
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  getValue(
    row: { coefficients: { teachingUnitId: number; value: number | null }[] },
    teachingUnitId: number
  ): number | null {
    return row.coefficients.find(v => v.teachingUnitId === teachingUnitId)?.value ?? null;
  }

  cellColor(value: number | null): string {
    if (value !== null && value >= 10) {
      return 'bg-light-green text-green';
    } else if (value !== null && value >= 8) {
      return 'bg-light-orange text-orange';
    } else if (value !== null) {
      return 'bg-light-red text-red';
    } else {
      return 'bg-border-grey text-grey';
    }
  }
}