import { Component, Input } from '@angular/core';
import { AbsenceStatsModel } from '../../../../models/absence-stats-model';
import { CommonModule } from '@angular/common';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-evaluation-period-absences',
  imports: [CommonModule, LucideAngularModule],
  templateUrl: './evaluation-period-absences.html',
  styleUrl: './evaluation-period-absences.css',
})
export class EvaluationPeriodAbsences {

  isCollapsed = false;
  @Input() period: AbsenceStatsModel[] = [];

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  unjustifiedAbsenceCountColor(label: string, count: number): string {
    if (label.startsWith('Semestre')) {
      if (count >= 5) return 'bg-light-red text-red';
      if (count >= 3 && count < 5) return 'bg-light-orange text-orange';
      return 'bg-light-green text-green';
    } else {
      return 'bg-border-grey text-grey';
    }
  }

  absenceRateColor(label: string, rate: number): string {
    if (!label.startsWith('Semestre')) {
      if (rate >= 10) return 'bg-light-red text-red';
      if (rate >= 5 && rate < 10) return 'bg-light-orange text-orange';
      return 'bg-light-green text-green';
    } else {
      return 'bg-light-grey text-grey';
    }
  }
}
