import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluationPeriodCompetencies } from './evaluation-period-competencies';

describe('EvaluationPeriodCompetencies', () => {
  let component: EvaluationPeriodCompetencies;
  let fixture: ComponentFixture<EvaluationPeriodCompetencies>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EvaluationPeriodCompetencies]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EvaluationPeriodCompetencies);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
