import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministrativeData } from './administrative-data';

describe('AdministrativeData', () => {
  let component: AdministrativeData;
  let fixture: ComponentFixture<AdministrativeData>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdministrativeData]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdministrativeData);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
