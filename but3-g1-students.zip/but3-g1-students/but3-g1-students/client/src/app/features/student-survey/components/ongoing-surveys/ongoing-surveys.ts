import { Component, computed, effect, inject, signal } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Observable, of, pipe, take } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SurveyModel } from '../../../../models/survey-model';
import { SurveyService } from '../../../../core/services/survey-service';
import { RouterLink } from '@angular/router';
import { SurveyTypePipe } from '../../../../shared/pipes/survey-type-pipe';
import { SurveyType } from '@server/db/generated/enums';
import { COLOR_MAP } from '../../../../shared/utils/color-map';
import { AuthService } from '../../../../core/auth-service';
import { UserModel } from '../../../../models/user-model';

@Component({
  selector: 'app-ongoing-surveys',
  imports: [RouterLink, LucideAngularModule, CommonModule, SurveyTypePipe],
  templateUrl: './ongoing-surveys.html',
  styleUrl: './ongoing-surveys.css',
})

export class OngoingSurveys {
  isCollapsed = false;
  private surveyService = inject(SurveyService);
  surveys = signal<SurveyModel[]>([]);
  private readonly authService = inject(AuthService);
  user = signal<UserModel | null>(null);

  constructor() {
    effect(() => {
      this.authService.currentUser$.subscribe(u => this.user.set(u));
      if (this.user()?.student?.id){
        this.surveyService.GetOngoingSurveysByStudentId(this.user()?.student?.id!).subscribe(foundSurveys => this.surveys.set(foundSurveys));
      }
    });
  }
  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  getSurveyColor(survey: SurveyModel): string {
    switch (survey.type) {
      case SurveyType.Mandatory:
        return 'red';
      case SurveyType.Optional:
        return 'green';
      default:
        return 'grey';
    }
  }

  getSurveyBgClass(survey: SurveyModel): string {
    const color = this.getSurveyColor(survey);
    return COLOR_MAP[color]?.bg ?? 'bg-grey';
  }

  getSurveyTextClass(survey: SurveyModel): string {
    const color = this.getSurveyColor(survey);
    return COLOR_MAP[color]?.text ?? 'text-grey';
  }


}
