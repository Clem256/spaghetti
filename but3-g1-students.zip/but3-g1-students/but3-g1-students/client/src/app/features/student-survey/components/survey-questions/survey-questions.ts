import { Component, inject, signal, effect } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { forkJoin, Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SurveyModel } from '../../../../models/survey-model';
import { ActivatedRoute, Router } from '@angular/router';
import { SurveyQuestionModel } from '../../../../models/survey-question-model';
import { SurveyQuestionOptions } from "../survey-question-options/survey-question-options";
import { QuestionService } from '../../../../core/services/question-service';
import { SurveyService } from '../../../../core/services/survey-service';
import { SurveyQuestionResponseModel } from '../../../../models/survey-question-response-model';
import { ResponseService } from '../../../../core/services/response/response-service';
import { SurveyQuestionResponseDto } from './dto/survey-questions-dto';

@Component({
  selector: 'app-survey-questions',
  imports: [LucideAngularModule, CommonModule, SurveyQuestionOptions],
  templateUrl: './survey-questions.html',
  styleUrl: './survey-questions.css',
})
export class SurveyQuestions {
  collapsedQuestions = signal<Record<string, boolean>>({});

  private router = inject(Router);
  private activatedRoute = inject(ActivatedRoute);
  private surveyService = inject(SurveyService);
  private questionService = inject(QuestionService);
  private responseService = inject(ResponseService);

  surveyId = signal<number | null>(null);
  readonly = signal(false);
  survey$!: Observable<SurveyModel>;
  surveyQuestions$!: Observable<SurveyQuestionModel[]>;
  allResponses = signal<Record<number, SurveyQuestionResponseDto>>({});

  constructor() {
    effect(() => {
      this.activatedRoute.paramMap.subscribe(params => {q
        const id = +params.get('id')!;
        this.surveyId.set(id);
      });
    });

    effect(() => {
      const id = this.surveyId();
      if (id !== null) {
        this.survey$ = this.surveyService.GetSurveyById(id);
        this.surveyQuestions$ = this.questionService.GetQuestionsBySurveyId(id);
        this.survey$.subscribe({
      next: survey => {
        this.readonly.set(new Date(survey.limit_date) < new Date())
      }
    });
      }
    });
  }

  answerSurvey(): void {
    const payloads = Object.values(this.allResponses());

    forkJoin(
      payloads.map(payload =>
        this.responseService.SaveResponse(payload)
      )
    ).subscribe({
      next: () => {
        this.router.navigate(['/student-survey']);
      }
    });
  }

  onQuestionResponsesChange(questionId: number, payload: SurveyQuestionResponseDto) {
  this.allResponses.update(current => ({
    ...current,
    [questionId]: payload
  }));
}

  submitSurvey() {
    const payloads = Object.values(this.allResponses());

    forkJoin(
      payloads.map(payload =>
        this.responseService.SaveResponse(payload)
      )
    ).subscribe({
      next: () => {
        this.router.navigate(['/student-survey']);
      }
    });
  }

  toggleQuestionCollapse(questionId: number): void {
    this.collapsedQuestions.update(collapsed => ({
      ...collapsed,
      [questionId]: !collapsed[questionId]
    }));
  }

  isQuestionCollapsed(questionId: number): boolean {
    return this.collapsedQuestions()[questionId] ?? false;
  }
}
