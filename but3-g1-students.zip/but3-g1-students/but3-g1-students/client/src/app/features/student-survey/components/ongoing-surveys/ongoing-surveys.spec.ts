import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OngoingSurveys } from './ongoing-surveys';

describe('OngoingSurveys', () => {
  let component: OngoingSurveys;
  let fixture: ComponentFixture<OngoingSurveys>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OngoingSurveys]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OngoingSurveys);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
