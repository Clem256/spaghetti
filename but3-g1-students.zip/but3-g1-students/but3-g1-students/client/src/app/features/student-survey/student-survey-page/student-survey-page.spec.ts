import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentSurvey } from './student-survey-page';

describe('StudentSurvey', () => {
  let component: StudentSurvey;
  let fixture: ComponentFixture<StudentSurvey>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentSurvey]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentSurvey);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
