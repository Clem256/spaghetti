import { Component, effect, inject, input, output, signal } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { take } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SurveyQuestionOptionModel } from '../../../../models/survey-question-option-model';
import { SurveyQuestionModel } from '../../../../models/survey-question-model';
import { SurveyQuestionResponseModel } from '../../../../models/survey-question-response-model';
import { OptionService } from '../../../../core/services/option-service';
import { ResponseService } from '../../../../core/services/response/response-service';
import { SurveyQuestionResponseDto } from '../survey-questions/dto/survey-questions-dto';
import { AuthService } from '../../../../core/auth-service';
import { UserModel } from '../../../../models/user-model';

@Component({
  selector: 'app-survey-question-options',
  imports: [LucideAngularModule, CommonModule],
  templateUrl: './survey-question-options.html',
  styleUrl: './survey-question-options.css',
})

export class SurveyQuestionOptions {

  public question = input<SurveyQuestionModel | null>();
  public readonly = input<boolean>();
  public isActive = signal<boolean>(false);
  options = signal<SurveyQuestionOptionModel[]>([]);
  responses = signal<SurveyQuestionResponseModel[]>([]);
  private responseService = inject(ResponseService);
  private optionService = inject(OptionService);
  selectedOptionId = signal<number | null>(null);
  selectedOptionIds = signal<number[]>([]);
  freeText = signal<string>('');
  responsesChange = output<SurveyQuestionResponseDto>();
  private readonly authService = inject(AuthService);
  user = signal<UserModel | null>(null);

  constructor() {
    effect(() => {
      this.authService.currentUser$.subscribe(u => this.user.set(u));
      const qst = this.question();
      const readonly = this.readonly();
      if (!qst) {
        this.options.set([]);
        this.responses.set([]);
        return;
      }

      this.optionService
        .GetOptionsByQuestionId(qst.id!)
        .pipe(take(1))
        .subscribe(opts => this.options.set(opts));

      this.responseService
        .GetResponsesByQuestionIdAndStudentId(qst.id!, this.user()?.student?.id!)
        .pipe(take(1))
        .subscribe(res => {
          this.responses.set(res);

          if (qst.type === 'SingleChoice') {
            this.selectedOptionId.set(res[0]?.optionId ?? null);
          }

          if (qst.type === 'MultiChoices') {
            this.selectedOptionIds.set(res.map(r => r.optionId!));
          }

          if (qst.type === 'Free') {
            this.freeText.set(this.responses()[0]?.content ?? '');
          }

        });
    });
  }

  selectOption(option: SurveyQuestionOptionModel) {
    const type = this.question()?.type;
    if (this.readonly()) {return;}

    if (type === 'SingleChoice') {
      this.selectedOptionId.set(option.id!);
    }

    if (type === 'MultiChoices') {
      const current = this.selectedOptionIds();

      if (current.includes(option.id!)) {
        this.selectedOptionIds.set(
          current.filter(id => id !== option.id)
        );
      } else {
        this.selectedOptionIds.set(
          [...current, option.id!]
        );
      }

    }
    this.emitResponses();
  }

  onFreeTextChange(value: string) {
    this.freeText.set(value);
    this.emitResponses();
  }


  emitResponses() {
    const qst = this.question();
    if (!qst) return;

    let payload: SurveyQuestionResponseDto = {
      question_id: qst.id!,
      student_id: this.user()?.student?.id!
    };

    if (qst.type === 'SingleChoice') {
      payload.option_id = this.selectedOptionId()!;
    }

    if (qst.type === 'MultiChoices') {
      payload.option_ids = this.selectedOptionIds();
    }

    if (qst.type === 'Free') {
      payload.content = this.freeText();
    }

    this.responsesChange.emit(payload);
  }

}
