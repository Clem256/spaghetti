import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentSurveyAnswer } from './student-survey-answer-page';

describe('StudentSurveyAnswer', () => {
  let component: StudentSurveyAnswer;
  let fixture: ComponentFixture<StudentSurveyAnswer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StudentSurveyAnswer]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudentSurveyAnswer);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
