import { Component } from '@angular/core';
import { OngoingSurveys } from '../components/ongoing-surveys/ongoing-surveys';
import { CompletedSurveys } from '../components/completed-surveys/completed-surveys';

@Component({
  selector: 'app-student-survey-page',
  imports: [OngoingSurveys, CompletedSurveys],
  templateUrl: './student-survey-page.html',
  styleUrl: './student-survey-page.css',
})
export class StudentSurvey {

}
