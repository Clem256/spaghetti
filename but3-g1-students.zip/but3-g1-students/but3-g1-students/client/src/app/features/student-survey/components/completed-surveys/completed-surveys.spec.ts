import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompletedSurveys } from './completed-surveys';

describe('CompletedSurveys', () => {
  let component: CompletedSurveys;
  let fixture: ComponentFixture<CompletedSurveys>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompletedSurveys]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompletedSurveys);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
