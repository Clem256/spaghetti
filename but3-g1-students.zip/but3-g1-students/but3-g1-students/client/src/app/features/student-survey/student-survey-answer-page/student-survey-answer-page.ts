import { Component } from '@angular/core';
import { SurveyQuestions } from '../components/survey-questions/survey-questions';

@Component({
  selector: 'app-student-survey-answer-page',
  imports: [SurveyQuestions],
  templateUrl: './student-survey-answer-page.html',
  styleUrl: './student-survey-answer-page.css',
})
export class StudentSurveyAnswer {

}
