import { Component, effect, inject, signal } from '@angular/core';
import { LucideAngularModule } from 'lucide-angular';
import { Observable, of, pipe, take } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SurveyModel } from '../../../../models/survey-model';
import { SurveyService } from '../../../../core/services/survey-service';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../../core/auth-service';
import { UserModel } from '../../../../models/user-model';

@Component({
  selector: 'app-completed-surveys',
  imports: [RouterLink, LucideAngularModule, CommonModule],
  templateUrl: './completed-surveys.html',
  styleUrl: './completed-surveys.css',
})

export class CompletedSurveys {
  isCollapsed = false;
  private surveyService = inject(SurveyService);
  surveys = signal<SurveyModel[]>([]);
  private readonly authService = inject(AuthService);
  user = signal<UserModel | null>(null);

  constructor() {
    effect(() => {
      this.authService.currentUser$.subscribe(u => this.user.set(u));
      if (this.user()?.student?.id){
        this.surveyService.GetCompletedSurveysByStudentId(this.user()?.student?.id!).subscribe(foundSurveys => this.surveys.set(foundSurveys));
      }
    });
  }
  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

  isExpired(limitDate: string | Date): boolean {
    return new Date(limitDate) < new Date();
  }

}
