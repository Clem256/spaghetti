import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyQuestionOptions } from './survey-question-options';

describe('SurveyQuestionOptions', () => {
  let component: SurveyQuestionOptions;
  let fixture: ComponentFixture<SurveyQuestionOptions>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SurveyQuestionOptions]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SurveyQuestionOptions);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
