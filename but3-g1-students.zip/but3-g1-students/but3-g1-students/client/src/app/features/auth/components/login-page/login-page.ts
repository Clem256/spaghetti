import { Component, inject, signal } from '@angular/core';
import { AuthService } from '../../../../core/auth-service';
import { Router } from '@angular/router';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-login-page',
  imports: [ReactiveFormsModule],
  templateUrl: './login-page.html',
  styleUrl: './login-page.css',
})
export class LoginPage {
  loginForm = new FormGroup({    
    identifier: new FormControl(''),    
    password: new FormControl(''),  
  });
  error = signal<string>('');
  private authService = inject(AuthService)
  private router = inject(Router);

  login(identifier: string, password: string) {
  this.authService.login(identifier, password).subscribe({
    next: (res: { response: { token: any; }; }) => {
      this.router.navigate(['/auth/callback'], {
        queryParams: { token: res.response.token }
      });
    },
    error: (err: { error: { error: { message: string; }; }; }) => {
      const message = err?.error?.error?.message || 'Erreur inconnue';
      this.error.set(message);
    }
  });
}

    onSubmit() {
      const { identifier, password } = this.loginForm.value;

      if (!identifier || !password) {
        this.error.set('Veuillez remplir tous les champs');
        return;
      }

      this.login(identifier, password);
    }
}
