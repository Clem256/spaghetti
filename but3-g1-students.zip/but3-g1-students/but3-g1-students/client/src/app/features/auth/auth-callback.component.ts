import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../core/auth-service';
import { UserType } from '@server/db/generated/enums';

@Component({
  selector: 'app-auth-callback',
  standalone: true,
  template: '<p>Connexion en cours...</p>'
})
export class AuthCallbackComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const token = params['token'];
      
      if (token) {
        this.authService.handleCallback(token).subscribe({
          next: () => {
            if(this.authService.getCurrentUser()?.type == UserType.Teacher) {
              this.router.navigate(['/teacher-my-students']);
              return;
            }
            if (this.authService.getCurrentUser()?.type == UserType.Student) {
              this.router.navigate(['/dashboard']);
              return;
            }
          },
          error: (error) => {
            console.error('Authentication error:', error);
            this.router.navigate(['/login']);
          }
        });
      } else {
        this.router.navigate(['/login']);
      }
    });
  }
}