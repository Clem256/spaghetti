import { Component, inject } from '@angular/core';
import { AuthService } from '../../core/auth-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
})

export class LoginComponent {
  private router = inject(Router);
  constructor(private authService: AuthService) {}

  loginWithGitLab(): void {
    this.authService.loginWithGitLab();
  }
  login(): void {
    this.router.navigate(['/login-page'])
  }
}