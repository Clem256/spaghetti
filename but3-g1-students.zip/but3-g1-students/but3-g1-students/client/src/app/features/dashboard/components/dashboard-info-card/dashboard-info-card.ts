import { Component, computed, input } from '@angular/core';
import { LucideAngularModule } from "lucide-angular";
import { COLOR_MAP } from '../../../../shared/utils/color-map';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-dashboard-info-card',
  imports: [LucideAngularModule, RouterLink],
  templateUrl: './dashboard-info-card.html',
  styleUrl: './dashboard-info-card.css',
})
export class DashboardInfoCard {

  readonly title = input<string>('');
  readonly value = input<number>(0);
  readonly icon = input.required<string>();
  readonly color = input.required<string>();
  readonly redirectLink = input<string | undefined>(undefined);
  
  readonly textColor = computed(
    () => COLOR_MAP[this.color()]?.text ?? 'text-black'
  );

  readonly backgroundColor = computed(
    () => COLOR_MAP[this.color()]?.bg ?? 'bg-white'
  );



}
