import { Component, computed, effect, inject, input, signal } from '@angular/core';
import { WelcomeSection } from './components/welcome-section/welcome-section';
import { DashboardInfoCard } from "./components/dashboard-info-card/dashboard-info-card";
import { CompetenciesCard } from "./components/competencies-card/competencies-card";
import { DashboardAlert } from "./components/dashboard-alert-card/dashboard-alert-card";
import { InfoCardModel } from '../../models/info-card-model';
import { SurveyService } from '../../core/services/survey-service';
import { Observable } from 'rxjs';
import { SurveyModel } from '../../models/survey-model';
import { SurveyType } from '@server/db/generated/enums';
import { AnnotationService } from '../../core/services/annotation/annotation-service';
import { AuthService } from '../../core/auth-service';
import { StudentService } from '../../core/services/student/student-service';

@Component({
  selector: 'app-dashboard',
  imports: [WelcomeSection, DashboardInfoCard, CompetenciesCard, DashboardAlert],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {

  private readonly surveyService = inject(SurveyService)
  private readonly annotationService = inject(AnnotationService)
  private readonly authService = inject(AuthService);
  private readonly studentService = inject(StudentService);

  user = this.authService.getCurrentUser();
  userId = this.user ? this.user.id : null;
  private mandatorySurveysCount = signal<number>(0);
  private optionalSurveysCount = signal<number>(0);
  private annotationsCount = signal<number>(0);
  private criticalSkillsCount = signal<number>(0);
  surveys$: Observable<SurveyModel[]> | undefined;

  infos = computed<InfoCardModel[]>(() => [
    {
      title: 'Enquêtes obligatoires',
      value: this.mandatorySurveysCount(),
      icon: 'file',
      color: 'red',
      redirectLink: `/student-survey`
    },
    {
      title: 'Enquêtes facultatives',
      value: this.optionalSurveysCount(),
      icon: 'file',
      color: 'green',
      redirectLink: `/student-survey`
    },
    {
      title: 'Annotations',
      value: this.annotationsCount(),
      icon: 'pencil',
      color: 'blue',
      redirectLink: `/profile/${this.userId}`
    },
    {
      title: 'Compétences critiques',
      value: this.criticalSkillsCount(),
      icon: 'settings',
      color: 'orange',
      redirectLink: `/student-file`
    },
  ]);

  constructor() {
    effect(() => {
      this.annotationService.getAnnotationCountByRecipientId(this.userId).subscribe(count => {
        this.annotationsCount.set(count);
      });

      if (this.user?.student?.id) {
        this.studentService.getCompetenciesResultsBySemester(this.user.student.id, 'Semestre 1').subscribe(results => {
          const semesterResults = results.find(result => result.type == 'SEMESTER');
          const criticalCount = semesterResults?.values.filter(value => value.value != null && value.value < 8).length ?? 0;
          this.criticalSkillsCount.set(criticalCount);
        });
      }

      this.surveys$ = this.surveyService.GetOngoingSurveysByStudentId(this.userId);
      this.surveys$.subscribe((surveys) => {
        this.mandatorySurveysCount.set(0);
        this.optionalSurveysCount.set(0);

        surveys.forEach((survey) => {
          if (survey.type == SurveyType.Mandatory) {
            this.mandatorySurveysCount.update(count => count + 1);
          } else if (survey.type == SurveyType.Optional) {
            this.optionalSurveysCount.update(count => count + 1);
          }
        });
      });
    });
  }
}
