import { Component, computed, effect, input } from '@angular/core';
import { COLOR_MAP } from '../../../../shared/utils/color-map';

@Component({
  selector: 'app-competence-badge',
  imports: [],
  templateUrl: './competence-badge.html',
  styleUrl: './competence-badge.css',
})
export class CompetenceBadge {
  code = input.required<string>();
  mark = input.required<number | null>();
  color: string = '';

  constructor() {
    effect(() => {
      const value = this.mark();
      if (value == null) {
        this.color = 'grey';
      } else if (value < 8) {
        this.color = 'red';
      } else if (value < 12) {
        this.color = 'orange';
      } else {
        this.color = 'green';
      }
    });
  }
  
  readonly textColor = computed(
    () => COLOR_MAP[this.color]?.text ?? 'text-black'
  );

  readonly backgroundColor = computed(
    () => COLOR_MAP[this.color]?.bg ?? 'bg-white'
  );

  readonly borderColor = computed(
    () => COLOR_MAP[this.color]?.border ?? 'border-black'
  );

}