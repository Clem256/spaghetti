import { Component, computed, inject, input, OnInit } from '@angular/core';
import { AuthService } from '../../../../core/auth-service';
import { Observable } from 'rxjs/internal/Observable';
import { UserModel } from '../../../../models/user-model';
import { AsyncPipe } from '@angular/common';
import { UserTypePipe } from '../../../../shared/pipes/usertype.pipe';

@Component({
  selector: 'app-welcome-section',
  imports: [AsyncPipe, UserTypePipe],
  templateUrl: './welcome-section.html',
  styleUrl: './welcome-section.css',
})
export class WelcomeSection {
  private readonly authService = inject(AuthService)
  user$: Observable<UserModel | null> = this.authService.currentUser$;


  ngOnInit(): void {
    this.user$.subscribe();
  }
}