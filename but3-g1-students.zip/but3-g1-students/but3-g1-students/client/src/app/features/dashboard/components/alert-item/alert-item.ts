import { Component, computed, input } from '@angular/core';
import { COLOR_MAP } from '../../../../shared/utils/color-map';
import { LucideAngularModule } from "lucide-angular";
import { AlertType } from '@server/db/generated/enums';

@Component({
  selector: 'app-alert-item',
  imports: [LucideAngularModule],
  templateUrl: './alert-item.html',
  styleUrl: './alert-item.css',
})
export class AlertItem {
    readonly message = input<string>('');
    readonly type = input<string>('');
    readonly redirectUrl = input<string | undefined>(undefined);
    
    readonly icon = computed(() => {
      switch (this.type().toLowerCase()) {
        case AlertType.Critical:
          return 'triangle-alert';
        case AlertType.Warning:
          return 'triangle-alert';
        case AlertType.Info:
          return 'circle-alert';
        default:
          return 'circle-alert';
      }
    });

    readonly color = computed(() => {
      switch (this.type().toLowerCase()) {
        case 'critical':
          return 'red';
        case 'warning':
          return 'orange';
        case 'info':
          return 'blue';
        default:
          return 'blue';
      }
    });

  readonly textColor = computed(
    () => COLOR_MAP[this.color()]?.text ?? 'text-black'
  );

  readonly backgroundColor = computed(
    () => COLOR_MAP[this.color()]?.bg ?? 'bg-white'
  );

  readonly borderColor = computed(
    () => COLOR_MAP[this.color()]?.border ?? 'border-black'
  );
}
