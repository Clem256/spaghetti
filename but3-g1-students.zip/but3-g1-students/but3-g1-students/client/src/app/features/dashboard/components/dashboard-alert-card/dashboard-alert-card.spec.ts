import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardAlert } from './dashboard-alert-card';

describe('DashboardAlert', () => {
  let component: DashboardAlert;
  let fixture: ComponentFixture<DashboardAlert>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DashboardAlert]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardAlert);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
