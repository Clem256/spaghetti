import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetenciesCard } from './competencies-card';

describe('CompetenciesCard', () => {
  let component: CompetenciesCard;
  let fixture: ComponentFixture<CompetenciesCard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompetenciesCard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetenciesCard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
