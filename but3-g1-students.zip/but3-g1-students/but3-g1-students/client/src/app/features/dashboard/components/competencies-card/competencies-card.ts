import { Component, inject } from '@angular/core';
import { LucideAngularModule } from "lucide-angular";
import { combineLatestWith, map, Observable } from 'rxjs';
import { CompetenceBadge } from "../competence-badge/competence-badge";
import { StudentService } from '../../../../core/services/student/student-service';
import { CompetencyService } from '../../../../core/services/competency/competency-service';
import { AuthService } from '../../../../core/auth-service';
import { CompetencyResultsModel } from '../../../../models/competency-results-model';
import { CompetencyModel } from '../../../../models/competency-model';
import { CompetencyAverage } from '../../../../models/competency-average';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-competencies-card',
  imports: [LucideAngularModule, CompetenceBadge, AsyncPipe],
  templateUrl: './competencies-card.html',
  styleUrl: './competencies-card.css',
})
export class CompetenciesCard {
  isCollapsed = false;

  private readonly studentService = inject(StudentService);
  private readonly competencyService = inject(CompetencyService);
  private readonly authService = inject(AuthService);

  private readonly user = this.authService.getCurrentUser();

  semester = "Semestre 1"; // TODO: rendre dynamique
  competencies$: Observable<CompetencyModel[]> = this.competencyService.getCompetenciesByStudentId(this.user?.student?.id ?? 0);
  competenciesResults$: Observable<CompetencyResultsModel[]> = this.studentService.getCompetenciesResultsBySemester(this.user?.student?.id ?? 0, this.semester);

  competencyCards$ = this.competencies$.pipe(
    combineLatestWith(this.competenciesResults$),
    map(([competencies, results]) => {
      const semesterResults = this.findSemesterResults(results);
      const marksByCompetencyId = new Map<number, number | null>();

      semesterResults?.values.forEach(value => {
        marksByCompetencyId.set(value.competencyId, this.roundMark(value.value));
      });

      return competencies.map(competency => ({
        competency,
        mark: marksByCompetencyId.get(competency.id) ?? null,
      }));
    })
  );

  private findSemesterResults(results: CompetencyResultsModel[]): CompetencyResultsModel | undefined {
    return (
      results.find(result => result.type == 'SEMESTER' && result.label == this.semester) ||
      results.find(result => result.type == 'SEMESTER')
    );
  }

  private roundMark(value: CompetencyAverage['value']): number | null {
    if (value == null) {
      return null;
    }

    return Math.round(value * 100) / 100;
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }

}
