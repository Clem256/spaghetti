import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardInfoCard } from './dashboard-info-card';

describe('DashboardCard', () => {
  let component: DashboardInfoCard;
  let fixture: ComponentFixture<DashboardInfoCard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DashboardInfoCard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DashboardInfoCard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
