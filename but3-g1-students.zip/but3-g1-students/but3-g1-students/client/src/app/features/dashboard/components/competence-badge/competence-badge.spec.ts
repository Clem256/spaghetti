import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompetenceBadge } from './competence-badge';

describe('CompetenceBadge', () => {
  let component: CompetenceBadge;
  let fixture: ComponentFixture<CompetenceBadge>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CompetenceBadge]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompetenceBadge);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
