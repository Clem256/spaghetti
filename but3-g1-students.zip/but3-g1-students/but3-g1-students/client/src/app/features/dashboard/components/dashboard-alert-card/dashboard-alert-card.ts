import { Component, inject, signal } from '@angular/core';
import { LucideAngularModule } from "lucide-angular";
import { AlertItem } from "../alert-item/alert-item";
import { AlertModel } from '../../../../models/alert-model';
import { AlertService } from '../../../../core/services/alert/alert-service';
import { Observable } from 'rxjs';
import { AsyncPipe } from '@angular/common';
import { AuthService } from '../../../../core/auth-service';

@Component({
  selector: 'app-dashboard-alert-card',
  imports: [LucideAngularModule, AlertItem, AsyncPipe],
  templateUrl: './dashboard-alert-card.html',
  styleUrl: './dashboard-alert-card.css',
})
export class DashboardAlert {
  isCollapsed = false;
  private readonly authService = inject(AuthService);
  private readonly alertsService = inject(AlertService);
  user = this.authService.getCurrentUser();
  userId = this.user ? this.user.id : null;
  alerts$: Observable<AlertModel[]> | undefined;

  ngOnInit(): void {
    this.alerts$ = this.alertsService.getAlertsByStudentId(this.userId);
  }

  toggleCollapse() {
    this.isCollapsed = !this.isCollapsed;
  }


}
