import { Component, effect, input, output, signal } from '@angular/core';
import { SurveyQuestionModel } from '../../../../models/survey-question-model';
import { SurveyModel } from '../../../../models/survey-model';

@Component({
  selector: 'app-survey-preview',
  imports: [],
  templateUrl: './survey-preview.html',
  styleUrl: './survey-preview.css',
})
export class SurveyPreview {
  questions = input<SurveyQuestionModel[]>([]);
  surveyTitle = output<string>();
  deleteQuestion = output<SurveyQuestionModel>();
  changeActiveQuestion = output<SurveyQuestionModel>();
  survey = input<SurveyModel>();



  constructor() {
    effect(() => {
    //   this.questions.set([
    //     {
    //     label:'ça va ?',
    //     type:'SingleChoice'
    //     },
    //     {
    //     label:'ça va ?',
    //     type:'SingleChoice'
    //     },
    //     {
    //     label:'ça va ?',
    //     type:'SingleChoice'
    //     },
    // ]);
    });
  }

  onTitleChange(value: string) {
    if (value == '' || value == ' '){
      return
    }

    this.surveyTitle.emit(value);
  }

  RemoveQuestion(question:SurveyQuestionModel){
    this.deleteQuestion.emit(question);
  }

  ModifyQuestion(question:SurveyQuestionModel){
    this.changeActiveQuestion.emit(question);
  }
}
