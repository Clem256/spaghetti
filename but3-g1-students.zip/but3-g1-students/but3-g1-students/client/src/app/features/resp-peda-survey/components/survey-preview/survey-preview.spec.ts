import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveyPreview } from './survey-preview';

describe('SurveyPreview', () => {
  let component: SurveyPreview;
  let fixture: ComponentFixture<SurveyPreview>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SurveyPreview]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SurveyPreview);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
