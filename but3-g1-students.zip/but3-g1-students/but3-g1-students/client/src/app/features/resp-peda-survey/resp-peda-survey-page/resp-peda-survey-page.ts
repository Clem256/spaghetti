import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SurveyQuestionModel } from '../../../models/survey-question-model';
import { SurveyModel } from '../../../models/survey-model';
import { LucideAngularModule } from "lucide-angular";

@Component({
  selector: 'app-resp-peda-survey-page',
  imports: [RouterLink, LucideAngularModule],
  templateUrl: './resp-peda-survey-page.html',
  styleUrl: './resp-peda-survey-page.css',
})
export class RespPedaSurvey {
  

}
