import { StudentModel } from "../../../models/student-model";

export interface GroupSearchModel {
    type: 'class' | 'promotion' | 'specialization' | 'department' | 'halfGroup'
    id: number
    label: string
    students?: StudentModel[];
}