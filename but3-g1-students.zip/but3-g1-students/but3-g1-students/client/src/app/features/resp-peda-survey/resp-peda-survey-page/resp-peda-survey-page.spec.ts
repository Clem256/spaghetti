import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RespPedaSurvey } from './resp-peda-survey-page';

describe('RespPedaSurvey', () => {
  let component: RespPedaSurvey;
  let fixture: ComponentFixture<RespPedaSurvey>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RespPedaSurvey]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RespPedaSurvey);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
