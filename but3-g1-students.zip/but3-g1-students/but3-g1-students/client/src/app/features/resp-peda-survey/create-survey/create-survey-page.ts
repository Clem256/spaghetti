import { Component, effect, inject, signal } from '@angular/core';
import { EditQuestion } from '../components/edit-question/edit-question';
import { SurveyPreview } from '../components/survey-preview/survey-preview';
import { SurveyQuestionModel } from '../../../models/survey-question-model';
import { SurveyModel } from '../../../models/survey-model';
import { SurveyService } from '../../../core/services/survey-service';
import { DatePipe } from '@angular/common';
import { StudentModel } from '../../../models/student-model';
import { GroupSearchModel } from '../dto/group-search-model';
import { Group } from 'lucide-angular';
import { Router } from '@angular/router';
import { SurveyType } from '@server/db/generated/enums';

@Component({
  selector: 'app-create-survey',
  imports: [EditQuestion, SurveyPreview, DatePipe],
  templateUrl: './create-survey-page.html',
  styleUrl: './create-survey-page.css',
})

export class CreateSurvey {
  activeQuestion = signal<SurveyQuestionModel | null>(null);
  survey = signal<SurveyModel>({name: '', limit_date: new Date(), type: SurveyType.Optional});
  questions = signal<SurveyQuestionModel[]>([]);
  private surveyService = inject(SurveyService);
  searchResults = signal<GroupSearchModel[]>([]);
  selectedGroups = signal<GroupSearchModel[]>([]);
  selectedStudents = signal<StudentModel[]>([]);
  isMandatory = signal<boolean>(false);
  searchQuery: string = '';
  private router = inject(Router);

  SaveQuestion(q: SurveyQuestionModel) {
    this.questions.update(list => {
      const i = list.findIndex(x => x.uid === q.uid);
      return i === -1 ? [...list, q] : list.map(x => x.uid === q.uid ? q : x);
    });
    this.activeQuestion.set(null);
  }

  AddQuestion(){
    this.activeQuestion.set({uid: crypto.randomUUID(), label: '', type: 'Free', options: []})
  }

  SwitchMandatory(){
    this.isMandatory.update(val => !val);

    this.survey.update(s => ({
      ...s,
      type: this.isMandatory() ? SurveyType.Mandatory : SurveyType.Optional
    }));
  }

  UpdateSurveyTitle(title: string){
    this.survey.update(s => ({ ...s, name: title }));
  }

  ChangeQuestion(question: SurveyQuestionModel){
    this.activeQuestion.set(question)
  }

  ModifyQuestion(question: SurveyQuestionModel){
    this.activeQuestion.set(question)
  }

  RemoveQuestion(question: SurveyQuestionModel){
    this.questions.update(list => list.filter(q => q !== question));
  }

  UpdateLimitDate(value: string) {
    this.survey.update(s => ({ ...s, limit_date: new Date(value) }));
  }

  OnSearch(query: string) {
    this.searchQuery = query;

    if (!query || query.length < 2) {
      this.searchResults.set([]);
      return;
    }

    this.surveyService.SearchSurveyGroups(query).subscribe(results => {
      // filtrer les groupes déjà sélectionnés
      this.searchResults.set(
        results.filter(r => 
          !this.selectedGroups().some(g => g.id === r.id && g.type === r.type && g.students === r.students)
        )
      );
    });
  }

  AddGroup(group: GroupSearchModel) {
    // ajouter le groupe s'il n'est pas déjà sélectionné
    if (!this.selectedGroups().some(g => g.id === group.id && g.type === group.type)) {
      this.selectedGroups.update(list => [...list, group]);
    }

    // fusionner les étudiants du groupe avec ceux déjà sélectionnés
    if (group.students?.length) {
      const mergedStudents = [
        ...this.selectedStudents(),
        ...group.students
      ].filter((student, index, self) =>
        index === self.findIndex(s => s.id === student.id)
      );
      this.selectedStudents.set(mergedStudents);
    }
  }

  RemoveGroup(group: GroupSearchModel) {
    // retirer le groupe
    this.selectedGroups.update(list => 
      list.filter(g => !(g.id === group.id && g.type === group.type))
    );

    // retirer les étudiants liés à ce groupe
    if (group.students?.length) {
      this.selectedStudents.update(students => 
        students.filter(s => !group.students!.some(gs => gs.id === s.id))
      );
    }
  }

  CreateSurvey() {
    const uniqueStudentIds = Array.from(new Set(this.selectedStudents().map(s => s.id)));

    if (uniqueStudentIds.length == 0) {
      alert('Aucun étudiant sélectionné');
      return;
    }

    if (!this.survey().name || this.survey().name.trim() == '') {
      alert('Le titre de l\'enquête est requis');
      return;
    }

    if (!this.questions() || this.questions().length == 0) {
      alert('Veuillez ajouter au moins une question');
      return;
    }

    if ( this.survey().limit_date < new Date()) {
      alert('La date limite doit être dans le futur');
      return;
    }

    const payload = {
      name: this.survey().name,
      type: this.survey().type,
      limit_date: this.survey().limit_date,

      questions: this.questions().map(q => {
        const base = {
          label: q.label,
          type: q.type,
        };

        if (q.type != 'Free') {
          return {
            ...base,
            options: q.options.map(o => ({ label: o.label })),
          };
        }

        return base;
      }),

      studentIds: uniqueStudentIds
    };


    this.surveyService.CreateSurvey(payload).subscribe({
      next: res => { 
        alert(`L'enquête "${res.name}" a été créée avec succès !`);
        this.router.navigate(['/resp-peda-survey']);
        
      },
      error: err => {
        console.error(err);
        alert(err);
      }
    });
  }

}