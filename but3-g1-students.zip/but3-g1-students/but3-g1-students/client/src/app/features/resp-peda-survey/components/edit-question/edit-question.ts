import { Component, effect, input, output, signal } from '@angular/core';
import { SurveyQuestionModel } from '../../../../models/survey-question-model';
import { SurveyQuestionOptionModel } from '../../../../models/survey-question-option-model';
import { QuestionType } from '@server/db/generated/enums';

@Component({
  selector: 'app-edit-question',
  imports: [],
  templateUrl: './edit-question.html',
  styleUrl: './edit-question.css',
})
export class EditQuestion {
  error = signal<string | null>(null);
  question = input<SurveyQuestionModel | null>();
  savedQuestion = output<SurveyQuestionModel | null>();
  changeQuestion = output<SurveyQuestionModel>();
  questions = input<SurveyQuestionModel[]>();

  options = signal<SurveyQuestionOptionModel[]>([]);

  constructor() {
    effect(() => {

      this.options.set(this.question()!.options || []);

    });
  }

  ChangeQuestionType(type:QuestionType){
    this.question()!.type = type;
  }

  RemoveOption(option:SurveyQuestionOptionModel){
    this.options.update(options =>
      options.filter(o => o !== option)
    );
  }

  AddOption(){
     this.options.update(options => [
      ...options,
      { uid: crypto.randomUUID(),
        label: '',
       }
    ]);
  }

  SaveQuestion(){
    if (!this.question()?.label) {
      this.error.set("L'intitulé de la question est obligatoire.");
      return;
    }

    if ((this.question()?.type !== 'Free' && (this.options().length < 2 || this.options().some(o => !o.label?.trim())))) {
      this.error.set("Ajoutez au moins deux options non vides.");
      return;
    }

    this.error.set(null);

    this.savedQuestion.emit({
      ...this.question()!,
      options: this.options()
    });
  }

  UpdateQuestionLabel(label:string){
    this.changeQuestion.emit({
      ...this.question()!,
      label: label
    });
  }

  UpdateOptionLabel(label: string, uid: string) {
    this.options.update(opts =>
      opts.map(o =>
        o.uid === uid ? { ...o, label } : o
      )
    );
  }
}

