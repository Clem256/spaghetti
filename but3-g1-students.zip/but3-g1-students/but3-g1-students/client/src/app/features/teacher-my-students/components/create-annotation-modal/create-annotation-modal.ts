import { Component, input, output } from '@angular/core';
import { StudentModel } from '../../../../models/student-model';

@Component({
  selector: 'app-create-annotation-modal',
  imports: [],
  templateUrl: './create-annotation-modal.html',
  styleUrl: './create-annotation-modal.css',
})
export class CreateAnnotationModal {

  student = input<StudentModel>();
  close = output<void>();
  save = output<string>();
  content: string = '';

  submit() {
    if (!this.content.trim()) return;

    this.save.emit(this.content);
    this.content = '';
    this.close.emit();
  }

  UpdateContent(content: string){
    this.content = content;
  }
}
