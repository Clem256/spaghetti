import { Component, effect, inject, input, signal } from '@angular/core';
import { StudentModel } from '../../../../models/student-model';
import { AnnotationModal } from '../annotation-modal/annotation-modal';
import { ClassService } from '../../../../core/services/class-service';
import { ClassModel } from '../../../../models/class-model';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-student-card',
  imports: [AnnotationModal, RouterLink],
  templateUrl: './student-card.html',
  styleUrl: './student-card.css',
})
export class StudentCard {
  private readonly classService = inject(ClassService);
  student = input<StudentModel>();
  name : string = '';
  studentClass = signal<ClassModel | null>(null);
  isModalOpen = false;

  constructor() {
     effect(() => {
      if (this.student()){
      this.name = this.student()?.user.last_name + ' ' + this.student()?.user.first_name
      this.classService.GetClassByStudentId(this.student()?.id!).subscribe(foundClass => this.studentClass.set(foundClass));
    }
    });
    

  }

  openAnnotations() {
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
  }
}
