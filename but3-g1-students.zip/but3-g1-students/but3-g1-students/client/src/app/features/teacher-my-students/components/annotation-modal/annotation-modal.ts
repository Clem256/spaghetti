import { Component, effect, EventEmitter, inject, input, output, signal } from '@angular/core';
import { StudentModel } from '../../../../models/student-model';
import { AnnotationItem } from '../../../student-profile/components/annotation-item/annotation-item';
import { LucideAngularModule } from "lucide-angular";
import { Observable } from 'rxjs';
import { AnnotationModel } from '../../../../models/annotation-model';
import { AnnotationService } from '../../../../core/services/annotation/annotation-service';
import { AsyncPipe } from '@angular/common';
import { CreateAnnotationModal } from '../create-annotation-modal/create-annotation-modal';
import { CreateAnnotationPayload } from '../../../../models/create-annotation-payload';

@Component({
  selector: 'app-annotation-modal',
  imports: [AnnotationItem, LucideAngularModule, CreateAnnotationModal],
  templateUrl: './annotation-modal.html',
  styleUrl: './annotation-modal.css',
})
export class AnnotationModal {
  isOpen = input<boolean>(false);
  student = input<StudentModel>();
  close = output<void>();
  isCreateModalOpen = false;
  annotations = signal<AnnotationModel[]>([]);
  private readonly annotationService = inject(AnnotationService);

  constructor() {
      effect(() => {
        this.refreshAnnotations();
      });
  }

  CreateAnnotation(content: string) {
    const payload: CreateAnnotationPayload = {
      author_id: 1,
      recipient_id: this.student()!.id,
      content: content,
    };

    this.annotationService.CreateAnnotation(payload).subscribe({
    next: () => {
      this.refreshAnnotations();
      this.closeCreateModal();
    },
    error: (err) => console.error(err)
  });
  }


  openCreateModal() {
  this.isCreateModalOpen = true;
  }

  closeCreateModal() {
    this.isCreateModalOpen = false;
  }

  refreshAnnotations() {
    this.annotationService.getAnnotationsByRecipientId(this.student()!.id)
      .subscribe(data => this.annotations.set(data));
  }

}
