import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeacherMyStudentsPage } from './teacher-my-students-page';

describe('TeacherMyStudentsPage', () => {
  let component: TeacherMyStudentsPage;
  let fixture: ComponentFixture<TeacherMyStudentsPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TeacherMyStudentsPage]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeacherMyStudentsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
