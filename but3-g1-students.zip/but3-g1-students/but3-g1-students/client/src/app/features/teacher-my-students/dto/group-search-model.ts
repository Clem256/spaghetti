import { StudentModel } from "../../../models/student-model";

export interface TeacherGroupSearchModel {
    type: 'class' | 'halfGroup'
    id: number
    label: string
    students?: StudentModel[];
}