import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { SurveyQuestionModel } from '../../../models/survey-question-model';
import { StudentModel } from '../../../models/student-model';
import { TeacherGroupSearchModel } from '../dto/group-search-model';
import { TeacherService } from '../../../core/services/teacher-service';
import { StudentCard } from '../components/student-card/student-card';

@Component({
  selector: 'app-teacher-my-students-page',
  imports: [StudentCard],
  templateUrl: './teacher-my-students-page.html',
  styleUrl: './teacher-my-students-page.css',
})
export class TeacherMyStudentsPage {
  private readonly teacherService = inject(TeacherService);
  activeQuestion = signal<SurveyQuestionModel | null>(null);
  searchResults = signal<TeacherGroupSearchModel[]>([]);
  selectedGroup = signal<TeacherGroupSearchModel | null>(null);
  selectedStudents = signal<StudentModel[]>([]);
  searchQuery: string = '';
  private router = inject(Router);


  OnSearch(query: string) {
    this.searchQuery = query;
    console.log(query)
    if (!query || query.length < 2) {
      this.searchResults.set([]);
      return;
    }

    this.teacherService.SearchTeacherGroups(query).subscribe(results => {
      // filtrer les groupes déjà sélectionnés
      if (this.selectedGroup())
      {
        this.searchResults.set(
          results.filter(r => 
            !(this.selectedGroup()!.id === r.id) && !(this.selectedGroup()!.type === r.type) && !(this.selectedGroup()!.students === r.students)
          )
        );
      }
      else
      {
        this.searchResults.set(results);
      }
    });
  }

  AddGroup(group: TeacherGroupSearchModel) {
    
    this.selectedGroup.set(group);

    // fusionner les étudiants du groupe avec ceux déjà sélectionnés
    if (group.students?.length) {
      const mergedStudents = [
        ...this.selectedStudents(),
        ...group.students
      ].filter((student, index, self) =>
        index === self.findIndex(s => s.id === student.id)
      );
      this.selectedStudents.set(mergedStudents);
    }
  }

}
