import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAnnotationModal } from './create-annotation-modal';

describe('CreateAnnotationModal', () => {
  let component: CreateAnnotationModal;
  let fixture: ComponentFixture<CreateAnnotationModal>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreateAnnotationModal]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreateAnnotationModal);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
