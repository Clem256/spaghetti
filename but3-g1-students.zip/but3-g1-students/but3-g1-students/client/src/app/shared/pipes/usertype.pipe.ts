import { Pipe, PipeTransform } from '@angular/core';
import { UserType } from '@server/db/generated/enums';
import { USER_TYPE_MAP } from '../utils/user-type-map';

@Pipe({
  name: 'userType',
  standalone: true
})
export class UserTypePipe implements PipeTransform {
  transform(type: UserType | undefined): string {
    return type ? USER_TYPE_MAP[type] || 'Utilisateur' : 'Utilisateur';
  }
}