import { Pipe, PipeTransform } from '@angular/core';
import { SurveyType } from '@server/db/generated/enums';
import { SURVEY_TYPE_MAP } from '../utils/survey-type-map';

@Pipe({
  name: 'surveyType'
})
export class SurveyTypePipe implements PipeTransform {

  transform(type: SurveyType): string {
    return SURVEY_TYPE_MAP[type] || 'Inconnu';
  }

}
