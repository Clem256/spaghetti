import { Component, input, inject, signal, effect } from '@angular/core';
import { LucideAngularModule } from "lucide-angular";
import { AuthService } from '../../../core/auth-service';
import { TitleCasePipe } from '@angular/common';
import { UserModel } from '../../../models/user-model';
import { UserTypePipe } from '../../pipes/usertype.pipe';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [LucideAngularModule, TitleCasePipe, UserTypePipe, RouterLink],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {
  private readonly authService = inject(AuthService);

  title = input<string>('Suivi du Cursus Étudiant');
  user = signal<UserModel | null>(null);

  constructor() {
    effect(() => {
      this.authService.currentUser$.subscribe(u => this.user.set(u));
    });
  }

  logout(): void {
    this.authService.logout();
  }
}