import { Component, inject } from '@angular/core';
import { SidebarItem } from "../sidebar-item/sidebar-item";
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from '../../../core/auth-service';
import { UserType } from '@server/db/generated/enums';

@Component({
  selector: 'app-sidebar',
  imports: [SidebarItem],
  templateUrl: './sidebar.html',
})
export class Sidebar {
  activeRoute: string = '';
  private readonly authService = inject(AuthService);
  user = this.authService.getCurrentUser();
  isStudent = this.user?.type == UserType.Student;

  constructor(private router: Router) {
    this.activeRoute = this.router.url;

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.activeRoute = event.urlAfterRedirects;
      });
  }
}
