import { Component, input, Type } from '@angular/core';
import { House, LucideAngularModule } from 'lucide-angular';
import { RouterLink, RouterLinkActive, ɵEmptyOutletComponent } from "@angular/router";
import { NgComponentOutlet } from '@angular/common';

@Component({
  selector: 'app-sidebar-item',
  imports: [
    LucideAngularModule, RouterLinkActive, RouterLink
],
  templateUrl: './sidebar-item.html',
})
export class SidebarItem {
  readonly title = input.required<string>();
  readonly icon = input.required<string>();
  readonly route = input.required<string>();
}
