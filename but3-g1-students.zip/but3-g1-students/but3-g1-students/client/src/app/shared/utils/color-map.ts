export const COLOR_MAP: Record<string, { text: string; bg: string; border: string }> = {
  red: { text: 'text-red', bg: 'bg-light-red', border: 'border-red' },
  green: { text: 'text-green', bg: 'bg-light-green', border: 'border-green' },
  blue: { text: 'text-blue', bg: 'bg-light-blue', border: 'border-blue' },
  orange: { text: 'text-orange', bg: 'bg-light-orange', border: 'border-orange' },
  yellow: { text: 'text-yellow', bg: 'bg-light-yellow', border: 'border-yellow' },
  purple: { text: 'text-purple', bg: 'bg-light-purple', border: 'border-purple' },
  grey: { text: 'text-grey', bg: 'bg-light-grey', border: 'border-grey' },
};