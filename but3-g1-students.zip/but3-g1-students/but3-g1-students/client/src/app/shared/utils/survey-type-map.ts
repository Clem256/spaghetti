import { SurveyType } from "@server/db/generated/enums";

export const SURVEY_TYPE_MAP: Record<SurveyType, string> = {
    [SurveyType.Mandatory]: 'Obligatoire',
    [SurveyType.Optional]: 'Facultative',
}