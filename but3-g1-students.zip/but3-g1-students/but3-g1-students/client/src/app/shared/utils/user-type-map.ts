import { UserType } from "@server/db/generated/enums";

export const USER_TYPE_MAP: Record<UserType, string> = {
    [UserType.Student]: 'Étudiant',
    [UserType.Teacher]: 'Enseignant',
}