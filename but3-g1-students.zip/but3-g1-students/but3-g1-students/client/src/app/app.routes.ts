import { Routes } from '@angular/router';
import { StudentFilePage } from './features/student-file/student-file-page/student-file-page';
import { Dashboard } from './features/dashboard/dashboard';
import { StudentSurvey } from './features/student-survey/student-survey-page/student-survey-page';
import { StudentSurveyAnswer } from './features/student-survey/student-survey-answer-page/student-survey-answer-page';
import { LoginComponent } from './features/auth/login.component';
import { Layout } from './shared/components/layout/layout/layout';
import { authGuard, roleGuard } from './core/guards/auth.guard';
import { UserType } from '@server/db/generated/enums';
import { StudentProfile } from './features/student-profile/student-profile/student-profile';
import { RespPedaSurvey } from './features/resp-peda-survey/resp-peda-survey-page/resp-peda-survey-page';
import { CreateSurvey } from './features/resp-peda-survey/create-survey/create-survey-page';
import { TeacherMyStudentsPage } from './features/teacher-my-students/teacher-my-students-page/teacher-my-students-page';
import { LoginPage } from './features/auth/components/login-page/login-page';

export const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent,
        title: 'Connexion'
    },
    {
        path: 'login-page',
        component: LoginPage,
        title: 'Connexion'
    },
    {
        path: 'auth/callback',
        loadComponent: () => import('./features/auth/auth-callback.component').then(m => m.AuthCallbackComponent),
    },
    
    {
        path: '',
        component: Layout,
        canActivate: [authGuard],
        children: [
            {
                path: 'dashboard',
                component: Dashboard,
                title: 'Tableau de Bord',
                canActivate: [roleGuard([UserType.Student, UserType.Teacher])]
            },
            {
                path: 'profile/:id',
                component: StudentProfile,
                title: 'Profil Étudiant',
                canActivate: [roleGuard([UserType.Student, UserType.Teacher])]
            },
            {
                path: 'student-file',
                component: StudentFilePage,
                title: 'Dossier Étudiant',
                canActivate: [roleGuard([UserType.Student])]
            },
            {
                path: 'student-survey',
                component: StudentSurvey,
                title: 'Enquêtes Étudiant',
                canActivate: [roleGuard([UserType.Student])]
            },
            {
                path: 'student-survey-answer/:id',
                component: StudentSurveyAnswer,
                title: 'Enquêtes Étudiant',
                canActivate: [roleGuard([UserType.Student])]
            },
            {
                path: 'resp-peda-survey',
                component: RespPedaSurvey,
                title: 'Enquêtes Responsable Pédagogique',
                canActivate: [roleGuard([UserType.Teacher])]
            },
            {
                path: 'create-survey-page/:id',
                component: CreateSurvey,
                title: 'Création d\'enquête',
                canActivate: [roleGuard([UserType.Teacher])]
            },
            {
                path: 'teacher-my-students',
                component: TeacherMyStudentsPage,
                title: 'Mes étudiants',
                canActivate: [roleGuard([UserType.Teacher])]
            },
            {
                path: '**',
                redirectTo: 'dashboard',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '**',
        redirectTo: '/dashboard'
    }
];