import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { map, Observable } from 'rxjs';
import { AlertModel } from '../../../models/alert-model';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class AlertService {

  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getAlerts(): Observable<AlertModel[]> {
    return this.http.get<{ alerts: AlertModel[] }>(`${this.apiUrl}/alerts`).pipe(
      map(response => response.alerts.map(a => ({
        ...a,
        created_at: new Date(a.created_at),
        updated_at: new Date(a.updated_at)
      })))
    );
  }

  getAlertsByStudentId(userId: number | null): Observable<AlertModel[]> {
    const url = `${this.apiUrl}/alerts/student/${userId}`;
    return this.http.get<{ alerts: AlertModel[] }>(url).pipe(
      map(response => response.alerts.map(a => ({
        ...a,
        created_at: new Date(a.created_at),
        updated_at: new Date(a.updated_at)
      })))
    );
  }

}
