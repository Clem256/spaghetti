import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyQuestionOptionModel } from '../../models/survey-question-option-model';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class OptionService {
  private apiUrl = environment.apiUrl;


  constructor(private http: HttpClient) { }

  GetOptionsByQuestionId(id: number | null): Observable<SurveyQuestionOptionModel[]> {
    return this.http.get<SurveyQuestionOptionModel[]>(
      `${this.apiUrl}/survey/question/options/` + id
    );
  }
}

