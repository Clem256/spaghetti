import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { UserModel } from '../../../models/user-model';
import { StudentModel } from '../../../models/student-model';
import { EvaluationPeriodDetailsModel } from '../../../models/evaluation-period-details-model';
import { CompetencyResultsModel } from '../../../models/competency-results-model';
import { AbsenceStatsModel } from '../../../models/absence-stats-model';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getEvaluationPeriodResultsById(studentId: number | undefined): Observable<EvaluationPeriodDetailsModel[]> {
    return this.http.get<EvaluationPeriodDetailsModel[]>(
      `${this.apiUrl}/students/${studentId}/evaluation-period-results`
    );
  }

  getCompetenciesResultsById(studentId: number | undefined): Observable<CompetencyResultsModel[]> {
    return this.http.get<CompetencyResultsModel[]>(
      `${this.apiUrl}/students/${studentId}/competencies-results`
    );
  }
  
  getCompetenciesResultsBySemester(studentId: number, semester: string): Observable<CompetencyResultsModel[]> {
    return this.http.get<CompetencyResultsModel[]>(
      `${this.apiUrl}/students/${studentId}/competencies-results?semester=${semester}`
    );
  }

  getAbsencesResultsById(studentId: number | undefined): Observable<AbsenceStatsModel[]> {
    return this.http.get<AbsenceStatsModel[]>(
      `${this.apiUrl}/students/${studentId}/absences-results`
    );
  }

}