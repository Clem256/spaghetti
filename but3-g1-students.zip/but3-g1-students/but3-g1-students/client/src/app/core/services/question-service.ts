import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyQuestionModel } from '../../models/survey-question-model';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class QuestionService {
  private apiUrl = environment.apiUrl;


  constructor(private http: HttpClient) { }

  GetQuestionsBySurveyId(id: number | null): Observable<SurveyQuestionModel[]> {
    return this.http.get<SurveyQuestionModel[]>(
      `${this.apiUrl}/survey/questions/` + id
    );
  }
}

