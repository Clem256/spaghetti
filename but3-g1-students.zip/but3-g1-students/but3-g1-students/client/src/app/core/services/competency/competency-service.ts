import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { CompetencyModel } from '../../../models/competency-model';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class CompetencyService {

  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getCompetencies(): Observable<CompetencyModel[]> {
      return this.http.get<CompetencyModel[]>(
        `${this.apiUrl}/competencies`
      );
    }

  getCompetenciesByStudentId(studentID: number | undefined): Observable<CompetencyModel[]> {
    const url = `${this.apiUrl}/competencies/student/${studentID}`;
    return this.http.get<{ competencies: any[] }>(url).pipe(
      map(response => response.competencies.map(c => ({
        ...c,
        created_at: new Date(c.created_at),
        updated_at: new Date(c.updated_at)
      })))
    );
  }  
  
}
