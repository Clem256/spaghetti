import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyQuestionResponseModel } from '../../../models/survey-question-response-model';
import { SurveyQuestionResponseDto } from '../../../features/student-survey/components/survey-questions/dto/survey-questions-dto';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class ResponseService {
  private apiUrl = environment.apiUrl;


  constructor(private http: HttpClient) { }

  GetResponsesByQuestionIdAndStudentId(idQuestion: number | null, idStudent: number | null): Observable<SurveyQuestionResponseModel[]> {
    return this.http.get<SurveyQuestionResponseModel[]>(
      `${this.apiUrl}/survey/question/` + idQuestion + '/responses/student/' + idStudent
    );
  }

  AddResponse(response: SurveyQuestionResponseModel): Observable<SurveyQuestionResponseModel> {
    const body = {
      response: {
        question_id: response.questionId,
        option_id: response.optionId,
        content: response.content,
        student_id: response.studentId
      }
    };

    return this.http.post<SurveyQuestionResponseModel>(
      `${this.apiUrl}/survey/quesion/response`,
      body
    );
  }

  SaveResponse(payload: SurveyQuestionResponseDto) {
    return this.http.post(`${this.apiUrl}/survey/question/response`, payload);
  }



}

