import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyModel } from '../../models/survey-model';
import { CreateSurveyPayload } from '../../models/create-survey-payload';
import { GroupSearchModel } from '../../features/resp-peda-survey/dto/group-search-model';
import { TeacherGroupSearchModel } from '../../features/teacher-my-students/dto/group-search-model';
import { ClassModel } from '../../models/class-model';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class ClassService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  GetClassByStudentId(id:number): Observable<ClassModel> {
    return this.http.get<ClassModel>(`${this.apiUrl}/class/student`, {
      params: { student_id: id }
    });
  }
}

