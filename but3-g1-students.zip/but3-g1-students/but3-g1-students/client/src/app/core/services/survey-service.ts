import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyModel } from '../../models/survey-model';
import { CreateSurveyPayload } from '../../models/create-survey-payload';
import { GroupSearchModel } from '../../features/resp-peda-survey/dto/group-search-model';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class SurveyService {
  private apiUrl = environment.apiUrl;


  constructor(private http: HttpClient) { }

  GetSurveys(): Observable<SurveyModel[]> {
    return this.http.get<SurveyModel[]>(
      `${this.apiUrl}/surveys`
    );
  }

  GetSurveyById(id:number | null): Observable<SurveyModel> {
    return this.http.get<SurveyModel>(
      `${this.apiUrl}/survey/` + id
    );
  }

  GetSurveysByStudentId(id:number | null): Observable<SurveyModel[]> {
    return this.http.get<SurveyModel[]>(
      `${this.apiUrl}/surveys/student/` + id
    );
  }

  GetOngoingSurveysByStudentId(id:number | null): Observable<SurveyModel[]> {
    return this.http.get<SurveyModel[]>(
      `${this.apiUrl}/surveys/ongoing/student/` + id
    );
  }

  GetCompletedSurveysByStudentId(id:number | null): Observable<SurveyModel[]> {
    return this.http.get<SurveyModel[]>(
      `${this.apiUrl}/surveys/completed/student/` + id
    );
  }

  CreateSurvey(payload: CreateSurveyPayload): Observable<SurveyModel> {
    return this.http.post<SurveyModel>(
      `${this.apiUrl}/survey`,
      payload
    );
  }

  SearchSurveyGroups(query: string): Observable<GroupSearchModel[]> {
    return this.http.get<GroupSearchModel[]>(`${this.apiUrl}/surveys/groups/search`, {
      params: { search: query, semester: 5 }
    });
  }
}

