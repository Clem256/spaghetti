// import { Injectable, signal } from '@angular/core';
// import { BehaviorSubject, Observable } from 'rxjs';

// export interface MockUser {
//   id: number;
//   first_name: string;
//   last_name: string;
//   school_email: string;
//   avatar_url?: string;
//   type: 'Student' | 'Teacher' | 'Admin';
// }

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   private currentUser = signal<MockUser | null>(null);
//   private isAuthenticated = signal<boolean>(false);

//   private mockUsers: MockUser[] = [
//     {
//       id: 1,
//       first_name: 'Jean',
//       last_name: 'Dupont',
//       school_email: 'jean.dupont@etu.univ-lyon1.fr',
//       avatar_url: 'https://i.pinimg.com/736x/0f/02/50/0f0250386869946d7d4d7f1d9a65a230.jpg',
//       type: 'Student'
//     },
//     {
//       id: 2,
//       first_name: 'Alice',
//       last_name: 'Berger',
//       school_email: 'alice.berger@etu.univ-lyon1.fr',
//       type: 'Student'
//     },
//     {
//       id: 3,
//       first_name: 'Rayan',
//       last_name: 'Cerfia',
//       school_email: 'rayan.cerfia@etu.univ-lyon1.fr',
//       type: 'Teacher'
//     }
//   ];

//   constructor() {
//     this.loadUserFromSession();
//   }

//   login(email: string, password: string): Observable<MockUser | null> {
//     return new Observable(observer => {
//       const user = this.mockUsers.find(u => u.school_email == email);
      
//       if (user && password == 'password') {
//         this.currentUser.set(user);
//         this.isAuthenticated.set(true);
//         sessionStorage.setItem('mockUser', JSON.stringify(user));
//         observer.next(user);
//       } else {
//         observer.next(null);
//       }
//       observer.complete();
//     });
//   }

//   logout(): void {
//     this.currentUser.set(null);
//     this.isAuthenticated.set(false);
//     sessionStorage.removeItem('mockUser');
//   }

//   getCurrentUser = this.currentUser.asReadonly();
//   getIsAuthenticated = this.isAuthenticated.asReadonly();

//   getUsername(): string {
//     const user = this.currentUser();
//     return user ? `${user.first_name} ${user.last_name}` : '';
//   }

//   getUserRole(): string {
//     const user = this.currentUser();
//     return user ? user.type : '';
//   }

//   isStudent(): boolean {
//     return this.currentUser()?.type == 'Student';
//   }

//   isTeacher(): boolean {
//     return this.currentUser()?.type == 'Teacher';
//   }

//   private loadUserFromSession(): void {
//     const storedUser = sessionStorage.getItem('mockUser');
//     if (storedUser) {
//       const user = JSON.parse(storedUser);
//       this.currentUser.set(user);
//       this.isAuthenticated.set(true);
//     }
//   }
// }