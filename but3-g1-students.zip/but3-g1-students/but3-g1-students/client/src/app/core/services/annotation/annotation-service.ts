import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AnnotationModel } from '../../../models/annotation-model';
import { map, Observable } from 'rxjs';
import { CreateAnnotationModal } from '../../../features/teacher-my-students/components/create-annotation-modal/create-annotation-modal';
import { CreateAnnotationPayload } from '../../../models/create-annotation-payload';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class AnnotationService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  getAllAnnotations() {
    return this.http.get<AnnotationModel[]>(`${this.apiUrl}/annotations`).pipe(
      map(annotation => annotation.map(a => ({
        ...a,
        created_at: new Date(a.created_at),
        updated_at: new Date(a.updated_at)
      })))
    );
  }

  getAnnotationsByStudentCode(studentCode: string) {
    return this.http.get<AnnotationModel[]>(`${this.apiUrl}/annotations/student/${studentCode}`).pipe(
      map(annotation => annotation.map(a => ({
        ...a,
        created_at: new Date(a.created_at),
        updated_at: new Date(a.updated_at)
      })))
    );
  }

  getAnnotationsByRecipientId(recipientId: number | null) {
    return this.http.get<AnnotationModel[]>(`${this.apiUrl}/annotations/${recipientId}`).pipe(
      map(annotation => annotation.map(a => ({
        ...a,
        created_at: new Date(a.created_at),
        updated_at: new Date(a.updated_at)
      })))
    );
  }

  getAnnotationCountByRecipientId(recipientId: number | null) {
    return this.http.get<number>(`${this.apiUrl}/annotations/count/${recipientId}`);
  }

  CreateAnnotation(payload: CreateAnnotationPayload): Observable<AnnotationModel> {
    console.log(payload)
    return this.http.post<AnnotationModel>(
      `${this.apiUrl}`,
      payload
    );
  }
}
