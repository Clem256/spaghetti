import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SurveyModel } from '../../models/survey-model';
import { CreateSurveyPayload } from '../../models/create-survey-payload';
import { GroupSearchModel } from '../../features/resp-peda-survey/dto/group-search-model';
import { TeacherGroupSearchModel } from '../../features/teacher-my-students/dto/group-search-model';
import { environment } from '../../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})

export class TeacherService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  SearchTeacherGroups(query: string): Observable<TeacherGroupSearchModel[]> {
    return this.http.get<TeacherGroupSearchModel[]>(`${this.apiUrl}/teacher/groups/search`, {
      params: { search: query, semester: 5 }
    });
  }
}

