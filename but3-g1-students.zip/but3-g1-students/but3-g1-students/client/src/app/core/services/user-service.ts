// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';
// import { TeacherGroupSearchModel } from '../../features/teacher-my-students/dto/group-search-model';
// import { UserModel } from '../../models/user-model';

// @Injectable({
//   providedIn: 'root'
// })

// export class UserService {

//   constructor(private http: HttpClient) { }

//   GetUserById(id: number): Observable<UserModel> {
//     const user = this.http.get<UserModel>('http://localhost:3000/api/users/' + id);
    
//     return user 
//   }
// }

