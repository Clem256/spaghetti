import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { UserModel } from '../../../models/user-model';
import { StudentModel } from '../../../models/student-model';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class UserService {

  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getUserById(userId: number): Observable<UserModel> {
    const url = `${this.apiUrl}/users/${userId}`;
    return this.http.get<UserModel>(url).pipe(
      map(response => {
        const u = response;
        return {
          id: u.id,
          first_name: u.first_name,
          last_name: u.last_name,
          personal_email: u.personal_email,
          school_email: u.school_email,
          username: u.username,
          avatar_url: u.avatar_url,
          student: u.student as StudentModel,
          created_at: u.created_at ? new Date(u.created_at) : null,
          updated_at: u.updated_at ? new Date(u.updated_at) : null,
        } as UserModel;
      })
    );
  }  
}
