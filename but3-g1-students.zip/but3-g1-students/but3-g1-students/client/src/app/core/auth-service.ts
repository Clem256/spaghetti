import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { UserModel } from '../models/user-model';
import { environment } from '../../environments/environment.development';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl;
  private currentUserSubject = new BehaviorSubject<UserModel | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    const token = this.getToken();
    if (token) {
      this.loadCurrentUser().subscribe({
        error: (err) => {
          console.error('Failed to load user:', err);
          this.logout();
        }
      });
    }
  }


  loginWithGitLab(): void {
    window.location.href = `${this.apiUrl}/auth/gitlab`;
  }

  login(identifier: string, password: string): any {
    const body = { identifier, password };

    return this.http.post<any>(`${this.apiUrl}/auth/login`, body);
  }

  handleCallback(token: string): Observable<UserModel> {
    this.setToken(token);
    return this.loadCurrentUser().pipe(
      map((response) => response.user)
    );
  }


  loadCurrentUser(): Observable<{ user: UserModel }> {
    return this.http.get<{ user: UserModel }>(`${this.apiUrl}/auth/me`).pipe(
      tap((response) => {
        this.currentUserSubject.next(response.user);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('token');
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }


  setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }


  getCurrentUser(): UserModel | null {
    return this.currentUserSubject.value;
  }
}
