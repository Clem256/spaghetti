export interface EvaluationPeriodDetailsModel {
    name: string,
    year: number,
    order: number,

    teachingUnits: {
        id: number;
        label: string;
        order: number;
    }[];

    rows: {
        id: number,
        label: string;
        order: number;
        value: number | null;
        coefficients: {
            teachingUnitId: number;
            value: number | null;
        }[];
    }[];
}
