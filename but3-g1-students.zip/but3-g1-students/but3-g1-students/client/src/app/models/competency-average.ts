export interface CompetencyAverage {
    competencyId: number,
    value: number | null
}