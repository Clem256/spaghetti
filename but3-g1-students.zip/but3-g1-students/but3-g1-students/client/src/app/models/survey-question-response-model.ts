export interface SurveyQuestionResponseModel {
    id?: number;
    content?: string;
    questionId: number;
    optionId?: number;
    studentId: number;
}