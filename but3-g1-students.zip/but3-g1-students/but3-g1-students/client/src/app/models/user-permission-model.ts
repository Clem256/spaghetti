export interface UserPermissionModel {
    // TODO
}
