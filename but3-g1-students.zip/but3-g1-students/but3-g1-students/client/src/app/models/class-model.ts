export interface ClassModel {
    id?: number;
    name: string;
    create_date: Date;
    update_date: Date;
    specialization_id: number;
    promotion_id: number;
}
