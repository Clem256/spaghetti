export interface InfoCardModel {
    title: string
    value: number
    icon: string
    color: string
    redirectLink?: string | undefined
}