import { QuestionType } from "@server/db/generated/enums";
import { SurveyQuestionOptionModel } from "./survey-question-option-model";

export interface SurveyQuestionModel {
    id?: number;
    uid: string;
    label: string;
    type: QuestionType;
    options: SurveyQuestionOptionModel[];
}