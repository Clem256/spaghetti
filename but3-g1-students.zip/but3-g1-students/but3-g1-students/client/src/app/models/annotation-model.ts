export interface AnnotationModel {
    id: number;
    author_id: number;
    recipient_id: number;
    content: string;
    created_at: Date;
    updated_at: Date;
}