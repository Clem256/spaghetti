export interface CreateAnnotationPayload {
  author_id: number;
  recipient_id: number;
  content: string;
}
