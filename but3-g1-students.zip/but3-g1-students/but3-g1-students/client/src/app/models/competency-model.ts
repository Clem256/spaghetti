export interface CompetencyModel {
    id: number,
    name: string,
    code: string,
    description?: string,
    created_at?: string,
    updated_at?: string,
}
