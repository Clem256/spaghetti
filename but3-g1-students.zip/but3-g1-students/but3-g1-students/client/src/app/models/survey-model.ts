import { SurveyType } from "@server/db/generated/enums";

export interface SurveyModel {
    id?: number;
    name: string;
    limit_date: Date;
    type: SurveyType;
}
