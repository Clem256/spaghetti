export interface InternshipApprenticeshipModel {
    company: string;
    academicTutor: string;
    professionalTutor: string;
    startDate: string;
    endDate: string;
}
