export interface TeacherModel {
    // TODO
}
