export interface UserRoleModel {
    // TODO
}
