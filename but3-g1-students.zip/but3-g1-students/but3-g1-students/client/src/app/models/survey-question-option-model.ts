export interface SurveyQuestionOptionModel {
    id?: number;
    uid: string;
    label: string;
}