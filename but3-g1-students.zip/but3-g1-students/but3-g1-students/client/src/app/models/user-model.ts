import { UserType } from "@server/db/generated/enums";
import { AnnotationModel } from "./annotation-model";
import { StudentModel } from "./student-model";
import { TeacherModel } from "./teacher-model";
import { UserRoleModel } from "./user-role-model";
import { UserPermissionModel } from "./user-permission-model";

export interface UserModel {
    id: number;
    first_name: string;
    last_name: string;
    username: string;
    gitlab_id?: number;
    personal_email?: string;
    school_email: string;
    password: string;
    created_at: Date;
    updated_at: Date;
    annotations: AnnotationModel[];
    written_annotations: AnnotationModel[];
    type: UserType;
    student?: StudentModel;
    teacher?: TeacherModel;
    userRole: UserRoleModel[];
    userPermission: UserPermissionModel[]
    avatar_url?: string;
}