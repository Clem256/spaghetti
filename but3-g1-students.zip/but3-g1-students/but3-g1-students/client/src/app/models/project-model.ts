export interface ProjectModel {
    name: string;
    role: string;
    createdAt: string;
    private: boolean;
    link: string | null;
}