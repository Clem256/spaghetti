export interface JobModel {
    company: string;
    post: string;
    contract: 'CDI' | 'CDD' | 'Intérim' | 'Alternance' | 'Stage' | 'Apprentissage' | 'Professionnalisation';
    startDate: string;
    endDate: string | null;
}