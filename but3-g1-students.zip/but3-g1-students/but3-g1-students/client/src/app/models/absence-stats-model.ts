export interface AbsenceStatsModel {
    type: 'SEMESTER' | 'AGGREGATE',
    label: string,
    year: number,
    semester?: number,
    totalHours: number;
    absenceHours: number;
    absenceCount: number;
    unjustifiedAbsenceCount: number;
    absenceRate: number;
}
