import { QuestionType, SurveyType } from '@server/db/generated/enums';

export interface CreateSurveyPayload {
  name: string;
  type: SurveyType;
  limit_date: Date;

  student_ids?: number[];

  questions: {
    label: string;
    type: QuestionType;
    options?: {
      label: string;
    }[];
  }[];
}
