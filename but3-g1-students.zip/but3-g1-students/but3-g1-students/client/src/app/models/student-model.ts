import { UserModel } from "./user-model";

export interface StudentModel {
  id: number;
  high_school?: string;
  diploma?: string;
  is_representative: boolean;
  student_code: string
  user_id: number;
  user: UserModel
}
