import { AlertType } from '@server/db/generated/enums';

export interface AlertModel {
    id: number;
    message: string;
    url?: string;
    type: AlertType;
    created_at: Date;
    updated_at: Date;
    student_id?: number;
}