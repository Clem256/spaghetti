import { CompetencyAverage } from "./competency-average";

export interface CompetencyResultsModel {
  type: 'SEMESTER' | 'AGGREGATE',
  label: string,
  year: number,
  semester?: number,

  values: CompetencyAverage[]
}